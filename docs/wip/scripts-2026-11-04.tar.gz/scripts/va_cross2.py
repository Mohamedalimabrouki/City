"""Every crossing of the river settlements of a world: kind, length, how far each end lies from a street. Run from a tree without the filter."""
import sys

import numpy as np
import shapely

sys.path.insert(0, '.')
from citygen.city import plan_city
from citygen.config import load_config
from citygen.world import generate_world

quick = sys.argv[1] == 'quick'
w = generate_world(load_config(quick=quick))
hist = []
for s in w.settlements:
    p = plan_city(w, s)
    if not p.crossings:
        continue
    lines = shapely.union_all([st.line for st in p.streets])
    rows = []
    for c in p.crossings:
        d = [round(float(shapely.distance(shapely.points(q), lines)), 1) for q in (c.line.coords[0], c.line.coords[-1])]
        rows.append((c.kind, round(c.line.length, 1), d))
        hist.append((max(d), s.kind))
    if quick or s.name in sys.argv[2:]:
        print(s.name, s.kind, rows)
h = np.array([x for x, _ in hist])
print('crossings', len(h), 'ends: under 1 m', int((h < 1).sum()), '1-8', int(((h >= 1) & (h < 8)).sum()), '8-14', int(((h >= 8) & (h < 14)).sum()), '14-18', int(((h >= 14) & (h < 18)).sum()), '18-30', int(((h >= 18) & (h < 30)).sum()), 'over 30', int((h >= 30).sum()))
