import sys, collections
sys.path.insert(0, ".")
from citygen.config import load_config
from citygen.world import generate_world
w = generate_world(load_config())
n = w.style["names"]
adj = set(n["descriptors"][:6]) | set(n["descriptors_f"][:6])
words = set(n["descriptors"]) | set(n["descriptors_f"])
rows = [(s.kind, s.name, s.name_ar) for s in w.settlements]
print(w.name, w.name_ar, "|", len(rows))
with_desc = [r for r in rows if len(r[1].split()) == 3 and r[1].split()[-1] in words]
fem = [r for r in with_desc if r[1].split()[-1] in set(n["descriptors_f"][:6])]
print("with a describing word", len(with_desc), "feminine adjective", len(fem))
for r in with_desc: print("  ", *r)
# 64 km world: everything else, a sample
print("--- first 16 others")
others = [r for r in rows if r not in with_desc]
for r in others[:16]: print("  ", *r)
# Arabic collisions
skeleton = lambda t: "".join(c for c in t if c not in "اوي ")
seen = collections.defaultdict(list)
for s in w.settlements: seen[skeleton(s.name_ar)].append(s.name)
print("alike without vowels:", [v for v in seen.values() if len(v) > 1])
same = collections.Counter(s.name_ar for s in w.settlements)
print("same Arabic spelling:", [k for k, v in same.items() if v > 1])
# more feminine samples over seeds
out = []
for seed in range(1, 8):
    v = generate_world(load_config(overrides={"world": {"seed": seed}}))
    out += [(s.name, s.name_ar) for s in v.settlements if len(s.name.split()) == 3 and s.name.split()[-1] in set(n["descriptors_f"][:6])]
print("feminine, other seeds:", len(out))
for r in out[:24]: print("  ", *r)
