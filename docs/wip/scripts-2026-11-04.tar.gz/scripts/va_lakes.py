import sys, numpy as np, shapely
sys.path.insert(0,'.')
from citygen.config import load_config
from citygen.world import generate_world
seed=int(sys.argv[1]); size=sys.argv[2] if len(sys.argv)>2 else 'full'
w=generate_world(load_config(overrides={"world":{"seed":seed}}))
c=w.carve; t=w.terrain
rows=[]
for s,lake in zip(c.shores, w.lakes):
    if s.salt: continue
    poly=s.polygon
    b=poly.buffer(600).boundary
    pts=np.array([b.interpolate(f,normalized=True).coords[0] for f in np.linspace(0,1,120)])
    h=np.asarray(t.height(pts[:,0],pts[:,1]))
    mouths=[(r.id,len(r.coords),'in') for r in w.rivers if r.mouth==lake.id] if hasattr(w.rivers[0],'mouth') else []
    rows.append((round(float(h.max()-s.level),1),round(float(np.median(h)-s.level),1),round(poly.area/1e6,2),round(s.level,1),[int(v) for v in poly.centroid.coords[0]],lake.id,len(mouths)))
for r in sorted(rows,reverse=True)[:12]: print(r)
