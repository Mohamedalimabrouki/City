"""Lead's own audit of the water network: run from a checkout. --option makes every wet hollow a lake."""
import inspect, sys, collections
import numpy as np
sys.path.insert(0, ".")
from shapely.geometry import LineString, Point, Polygon
from shapely.ops import unary_union
import citygen.hydro as hy
from citygen.config import load_config
from citygen.terrain import classify, BIOME_NAMES

if "--option" in sys.argv:
    src = inspect.getsource(hy._basins)
    old = "            continue                    # too little water to fill it: a damp hollow that drains\n"
    assert old in src
    src = src.replace(old, "            wet = size\n")
    exec(src, hy.__dict__)
from citygen.world import generate_world

def seglen(xy):
    return np.hypot(*np.diff(xy, axis=0).T)

def audit(quick, seed=None):
    cfg = load_config(quick=quick)
    if seed is not None:
        cfg["world"]["seed"] = seed
    w = generate_world(cfg)
    t = w.terrain
    lakes = {k.id: k for k in w.lakes}
    polys = {k.id: Polygon(k.polygon).buffer(0) for k in w.lakes}
    rivers = {r.id: r for r in w.rivers}
    print(f"--- quick={quick} seed={w.seed}: {len(w.rivers)} rivers, {sum(not k.salt for k in w.lakes)} fresh, {sum(k.salt for k in w.lakes)} salt")
    total = deep10 = deep20 = 0.0
    worst = 0.0
    rises = 0
    float_max = 0.0
    trench = []   # river into a lake with its bed under the lake's level
    stretches = []
    for r in w.rivers:
        xy, z = r.coords, r.profile
        g = t.height(xy[:, 0], xy[:, 1])
        L = seglen(xy)
        d = g - z
        mid = (d[:-1] + d[1:]) / 2
        total += L.sum(); deep10 += L[mid > 10].sum(); deep20 += L[mid > 20].sum()
        worst = max(worst, d.max())
        if (np.diff(z) > 1e-9).any():
            rises += 1
        on_lake = np.array([any(p.contains(Point(a, b)) for p in polys.values()) for a, b in xy]) if False else None
        float_max = max(float_max, (z - g).max())
        if r.mouth in ("lake", "basin"):
            k = lakes[r.into]
            gap = k.level - z[-1]
            below = z < k.level
            s = np.concatenate([[0], np.cumsum(L)])
            # how far upstream the bed lies under the lake's level with ground above it
            dry = below & (g > k.level)
            km = L[(dry[:-1] & dry[1:])].sum() / 1000
            trench.append((r.id, r.mouth, r.into, round(float(gap), 1), round(float(km), 2), round(r.flow, 1)))
        # runs of depth over 10 m
        i = 0
        while i < len(mid):
            if mid[i] > 10:
                j = i
                while j + 1 < len(mid) and mid[j + 1] > 10:
                    j += 1
                stretches.append((float(L[i:j + 1].sum()), float(mid[i:j + 1].max()), r.id, xy[(i + j) // 2], r.seasonal, r.mouth, r.flow))
                i = j + 1
            else:
                i += 1
    print(f"river {total/1000:.0f} km; over 10 m under ground {deep10/1000:.1f} km; over 20 m {deep20/1000:.1f} km; worst {worst:.1f} m; rising rivers {rises}; float max {float_max:.2f} m")
    fresh = [x for x in trench if x[1] == "lake"]
    salt = [x for x in trench if x[1] == "basin"]
    for name, rows in (("fresh", fresh), ("salt", salt)):
        rows2 = sorted(rows, key=lambda x: -x[3])
        n = sum(x[3] > 0.5 for x in rows)
        print(f"into {name} lakes: {len(rows)} rivers, {n} with the bed over 0.5 m under the level; worst: {rows2[:6]}")
    junc = 0.0
    for r in w.rivers:
        if r.mouth == "river":
            m = rivers[r.into]
            line = LineString(m.coords)
            s = line.project(Point(r.coords[-1]))
            along = np.concatenate([[0], np.cumsum(seglen(m.coords))])
            mz = np.interp(s, along, m.profile)
            junc = max(junc, abs(mz - r.profile[-1]), line.distance(Point(r.coords[-1])))
    print(f"junction gap worst {junc:.3f}")
    stretches.sort(key=lambda s: -s[0] * s[1])
    biomes = collections.Counter()
    for ln, dep, rid, p, seas, mouth, fl in stretches:
        H = t.height(np.array([p[0]]), np.array([p[1]]))
        m = t.moisture(np.array([p[0]]), np.array([p[1]]), H)
        biomes[("seasonal" if seas else "perennial")] += ln / 1000
    print("deep km by river type:", {k: round(v, 1) for k, v in biomes.items()})
    for ln, dep, rid, p, seas, mouth, fl in stretches[:10]:
        print(f"  river {rid} ({'oued' if seas else 'river'}, flow {fl:.0f}, mouth {mouth}): {ln/1000:.1f} km deep up to {dep:.0f} m near ({p[0]/1000:.1f}, {p[1]/1000:.1f}) km")
    wet = unary_union([polys[k.id] for k in w.lakes])
    touch = [s.name for s in w.settlements if Point(s.x, s.y).buffer(s.radius).intersects(wet)]
    roads = sum(LineString(r.coords).intersects(wet) for r in w.roads)
    print(f"settlements touching a lake {len(touch)}: {touch}; roads crossing a lake {roads} of {len(w.roads)}")
    near = 0
    return w

audit(False)
audit(True)
