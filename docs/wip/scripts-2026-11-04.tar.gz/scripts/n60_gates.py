import sys, collections
sys.path.insert(0, ".")
import numpy as np, shapely
from citygen.config import load_config
from citygen.world import generate_world
from citygen.city import plan_city
from citygen.city.dressing import Dresser, building_highs
from citygen.city.ground import Ground
from citygen.city.openings import villa_lots
from citygen.kit import make_kit
world = generate_world(load_config(quick=True))
for s in world.settlements:
    if s.kind != "town": continue
    town = plan_city(world, s)
    ks = [k for k, b in enumerate(town.buildings) if b.kind == "villa"]
    print(s.id, s.name, s.population, "buildings", len(town.buildings), "villas", len(ks), "maisons?", collections.Counter(d.kind for d in town.districts))
    if not ks: continue
    ks = ks[::3]
    ground = Ground(world, [town])
    kit = make_kit(world.seed, world.cfg, world.style)
    dresser = Dresser(world, town, kit, ground)
    highs = building_highs(ground, [town.buildings[k] for k in ks])
    lots = villa_lots(town, ks)
    width = world.style["dressing"]["paths"]["width"]
    gates = n = 0; none = 0
    for k, high in zip(ks, highs):
        paths = []
        dresser.building(k, float(high), paths)
        garden, hedge = dresser.garden(k, paths)
        lot = town.parcels[lots[k]].polygon
        ways = [shapely.LineString(p).buffer(width / 2, cap_style="flat") for p in paths]
        n += 1
        g = any(w.intersects(lot.exterior) for w in ways)
        gates += g
        none += not ways
    print(" sample", n, "gates", gates, "no path", none)
