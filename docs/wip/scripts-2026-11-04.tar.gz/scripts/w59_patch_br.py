import sys
p=sys.argv[1]+"/citygen/hydro.py"; s=open(p).read()
s=s.replace("""    rivers = _rivers(chains, flat, flow, catch, sea.ravel(), salt, lake_id, c, n, rc)
""","""    bed = np.where(lake_id >= 0, flat, H.ravel())
    if rc.get("wet_fill"):
        pass
    rivers = _rivers(chains, bed, flow, catch, sea.ravel(), salt, lake_id, c, n, rc)
""")
open(p,"w").write(s)
