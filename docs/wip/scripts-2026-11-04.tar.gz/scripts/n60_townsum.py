import json, sys, collections
for tag in ("old", "new"):
    rows = json.load(open(f"{sys.argv[1]}/town_{tag}.json"))
    print("=====", tag, len(rows))
    for lay in ("villa", "maison"):
        g = [r for r in rows if r["layout"] == lay]
        ok = sum(not r["kinds"] for r in g)
        print(lay, f"{ok}/{len(g)} {100 * ok / len(g):.1f}%", "median area", sorted(r["area"] for r in g)[len(g) // 2], "floors", dict(collections.Counter(r["floors"] for r in g)))
        bands = [(0, 60), (60, 80), (80, 100), (100, 130), (130, 170), (170, 1e9)]
        print("   by footprint m2:", "  ".join(f"{a}-{b if b < 1e8 else ''}: {sum(not r['kinds'] for r in g if a <= r['area'] < b)}/{sum(a <= r['area'] < b for r in g)}" for a, b in bands))
        fl = collections.Counter()
        for r in g:
            for k in r["kinds"]:
                fl[k[:58]] += 1
        print("   houses by fault:", fl.most_common(9))
    other = [r for r in rows if r["layout"] not in ("villa", "maison")]
    print("   other layouts", collections.Counter((r["want"], r["layout"]) for r in other))
