"""Do the dars that fail the survey stand near a river? args: build folder, survey text. Run from a tree."""
import re
import sys
from pathlib import Path

import numpy as np
import shapely
from shapely.geometry import LineString

sys.path.insert(0, '.')
from citygen.interior.context import city_plan, layout_of, load_build

ctx = load_build(Path(sys.argv[1]), log=lambda m: None)
plan, style = city_plan(ctx), ctx.world.style
text = open(sys.argv[2]).read()
m = re.search(r'dar failing: \[([^\]]*)\]', text)
fail = [int(v) for v in m.group(1).split(',')] if m else []
lines = [LineString(r.coords) for r in ctx.world.rivers]
river = shapely.union_all(lines) if lines else None
dar = [k for k, b in enumerate(plan.buildings) if b.kind == 'house' and layout_of(plan, b, style) == 'dar']
d = {k: plan.buildings[k].footprint.distance(river) for k in dar}
all_d = np.array([d[k] for k in dar])
fd = np.array([d[k] for k in fail if k in d])
print('dars', len(dar), 'failing listed', len(fail), 'in dars', len(fd))
print('distance to a river, m: all dars p10, p50, p90', np.percentile(all_d, [10, 50, 90]).round(0), ' failing', np.percentile(fd, [10, 50, 90]).round(0) if len(fd) else None)
print('within 100 m of a river: all', int((all_d < 100).sum()), ' failing', int((fd < 100).sum()))
print('capital crossings', len(getattr(plan, 'crossings', [])), 'medina center', [int(v) for v in plan.medina.centroid.coords[0]])
