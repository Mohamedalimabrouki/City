import sys
sys.path.insert(0, ".")
import numpy as np
from scipy import ndimage
from shapely.geometry import Polygon, Point
from citygen.config import load_config
from citygen import hydro
sys.path.insert(0, "tests")
import test_hydro as th
cfg = load_config(quick=True); rc = cfg["rivers"]
real = hydro._water
def old_water(h, m, wet, spill):
    heights = np.sort(h[m])
    if wet >= len(heights):
        return m, spill
    level = float(heights[wet - 1])
    return m & (h <= level), level
for at in (14300, 14400, 14500, 14600, 14700, 14800, 15000, 15200, 15300, 15400):
  for ridge in (15, 20, 25, 29, 30, 35, 40, 50):
    land = th._Valley(0.02, ridge=float(ridge), at=float(at))
    hydro._water = real
    r1, l1 = hydro.drainage(land, cfg); g1 = hydro._routing(land, rc)
    X, Y = np.meshgrid(g1.c, g1.c); H = land.height(X, Y)
    hollow = (X - 15000.0) ** 2 + (Y - 10000.0) ** 2 < 1000.0 ** 2
    cnt = ndimage.label(hollow & (H <= l1[0].level))[1] if l1 else 0
    new_ok = len(l1) == 1 and all(th._ends_in(r, l1[0], 150.0) for r in r1 if r.mouth == "basin") and any(r.mouth == "basin" for r in r1)
    hydro._water = old_water
    r0, l0 = hydro.drainage(land, cfg)
    old_ok = len(l0) == 1 and all(th._ends_in(r, l0[0], 150.0) for r in r0 if r.mouth == "basin")
    hydro._water = real
    if len(l1) == 1 and cnt == 2:
        print("at", at, "ridge", ridge, "new: lakes", len(l1), "pockets under level", cnt, "new ok", new_ok, "| old: lakes", len(l0), "old ok", old_ok, "lake cells", int((g1.lake_id == 0).sum()), "pocket sizes", np.bincount(ndimage.label(hollow & (H <= l1[0].level))[0].ravel())[1:].tolist())
