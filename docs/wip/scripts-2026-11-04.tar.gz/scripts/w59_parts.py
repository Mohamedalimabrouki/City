import sys, collections, ast
sys.path.insert(0, ".")
import numpy as np
from shapely.ops import unary_union
from shapely.geometry import LineString, Point
from citygen.config import load_config
from citygen.world import generate_world
from citygen.city import plan_city
from citygen.export.streets import street_graph
w = generate_world(load_config())
names = ["Ledes el Bahri", "Ain Chalza", "Ain Khatane", "Gamar", "Hozir", "Zasa", "Nodja ez Zitoun", "Bir Ghafarel", "Ksar el Djabrar", "Sota"]
for s in w.settlements:
    if s.name not in names:
        continue
    plan = plan_city(w, s)
    nodes, edges = street_graph(plan.streets, 0.05)
    parent = list(range(len(nodes)))
    def root(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]; a = parent[a]
        return a
    for _k, _l, a, b in edges:
        parent[root(a)] = root(b)
    groups = collections.defaultdict(list)
    for k, line, a, b in edges:
        groups[root(a)].append((k, line))
    big = max(groups.values(), key=lambda g: sum(l.length for _k, l in g))
    bigu = unary_union([l for _k, l in big])
    for g in groups.values():
        if g is big:
            continue
        u = unary_union([l for _k, l in g])
        kinds = collections.Counter(plan.streets[k].kind for k, _l in g)
        wid = max(plan.streets[k].width for k, _l in g)
        d = u.distance(bigu)
        # how far, measured by the ribbons
        print(s.name, s.kind, "streets", len(plan.streets), "side part: length", round(u.length, 1), "kinds", dict(kinds), "gap to the rest", round(d, 2), "m; biggest width", wid, "buildings near", sum(1 for b in plan.buildings if u.distance(Point(b.footprint.centroid.x, b.footprint.centroid.y)) < 30) if hasattr(plan.buildings[0], "footprint") else "?")
