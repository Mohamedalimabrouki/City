"""The street graph of every settlement of a world: the largest connected part's share of the street length."""
import sys, time, collections
sys.path.insert(0, ".")
import multiprocessing as mp
from citygen.config import load_config
from citygen.world import generate_world
from citygen.city import plan_city
from citygen.export.streets import street_graph

WORLD = None
QUICK = sys.argv[1] == "quick"

def parts(nodes, edges):
    parent = list(range(len(nodes)))
    def root(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a
    for _k, _line, a, b in edges:
        parent[root(a)] = root(b)
    out = collections.Counter()
    for _k, line, a, _b in edges:
        out[root(a)] += line.length
    return out

def one(i):
    global WORLD
    if WORLD is None:
        WORLD = generate_world(load_config(quick=QUICK))
    s = WORLD.settlements[i]
    t = time.perf_counter(); plan = plan_city(WORLD, s); t1 = time.perf_counter()
    nodes, edges = street_graph(plan.streets, float(WORLD.cfg["street_graph"]["grid"])); t2 = time.perf_counter()
    p = parts(nodes, edges)
    total = sum(p.values()) or 1.0
    return (i, s.name, s.kind, len(plan.streets), len(nodes), len(edges), len(p), max(p.values(), default=0.0) / total, total, t1 - t, t2 - t1)

if __name__ == "__main__":
    QUICK = sys.argv[1] == "quick"
    n = len(generate_world(load_config(quick=QUICK)).settlements)
    with mp.get_context("fork").Pool(int(sys.argv[2])) as pool:
        rows = []
        for r in pool.imap_unordered(one, range(n)):
            rows.append(r); print(r, flush=True)
    rows.sort()
    worst = min(r[7] for r in rows if r[3])
    print("settlements", len(rows), "with streets", sum(1 for r in rows if r[3]), "worst share", round(worst, 5), "one part:", sum(1 for r in rows if r[6] == 1), "under 99.5%:", [(r[1], r[3], r[6], round(r[7], 4)) for r in rows if r[7] < 0.995 and r[3]])
