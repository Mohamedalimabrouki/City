import sys,json,math; sys.path.insert(0,'.'); sys.path.insert(0,'tools')
import numpy as np, collections
from citygen.interior.context import city_plan, load_build
from citygen.interior.outside import Outside
ctx=load_build('output/bodjantouna-42',log=lambda m:None); plan=city_plan(ctx,None)
idx=json.load(open('output/bodjantouna-42/tiles/index.json'))
print({k:v for k,v in idx.items() if k not in('tiles','cities')}.keys()); print(idx['tiles'][0])
print('tile_size',idx.get('tile_size'))
full={(t['i'],t['j']) for t in idx['tiles'] if not t.get('lod')}
print(len(idx['tiles']),len(full))
res=[]
d=ctx.dresser(plan)
for k,b in enumerate(plan.buildings):
    if plan.districts[b.district].kind!='colonial' or b.kind not in('house','apartments'): continue
    o=Outside(ctx,plan,k)
    n=collections.Counter(p.piece for p in o.placements if 'balcon' in p.piece or 'window_door' in p.piece)
    if sum(n.values())>=6 and o.tile in full:
        c=b.footprint.centroid
        res.append((sum(v for a,v in n.items() if 'window_door' in a),k,o.tile,round(c.x),round(c.y),round(o.high,1),int(b.floors),round(o.fh,2),dict(n)))
res.sort(reverse=True)
for r in res[:12]: print(r)
