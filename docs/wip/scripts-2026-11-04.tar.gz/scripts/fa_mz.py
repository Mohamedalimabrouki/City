import sys; sys.path.insert(0,'.')
from citygen.interior.context import city_plan, load_build
ctx=load_build('output/megine/bodjantouna-42',log=lambda m:None)
for x,y in ((5324,22472),(5316,22454),(5345,22440)): print(x,y,float(ctx.ground.surface(x,y)))
