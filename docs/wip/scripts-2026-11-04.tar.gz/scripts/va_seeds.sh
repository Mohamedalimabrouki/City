#!/bin/zsh
# Interior rates on more worlds, base against new, to tell a fresh deal from a real change. One argument: the seed.
PY=/Users/mohamedalimabrouki/Desktop/City/.venv/bin/python
s=$1
cd /tmp/claude-501/va_base_src
$PY -m citygen build --quick --seed $s --out /tmp/claude-501/va_base_out/q$s 2>&1 | tail -1 | cut -c1-90
$PY tools/interior_survey.py --folder /tmp/claude-501/va_base_out/q$s/* --groups dar,compact,small > /tmp/claude-501/va_tmp/surv_b$s.txt 2>&1
cd /tmp/claude-501/va_tree6
$PY -m citygen build --quick --seed $s --out /tmp/claude-501/va_out/q$s 2>&1 | tail -1 | cut -c1-90
$PY tools/interior_survey.py --folder /tmp/claude-501/va_out/q$s/* --groups dar,compact,small > /tmp/claude-501/va_tmp/surv_n$s.txt 2>&1
