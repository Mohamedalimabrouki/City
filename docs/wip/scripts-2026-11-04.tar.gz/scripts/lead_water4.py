"""Salt lakes: size against what reaches them, and the map's look."""
import sys
import numpy as np
sys.path.insert(0, ".")
from shapely.geometry import Polygon
import citygen.hydro as hy
from citygen.config import load_config
from citygen.world import generate_world
cfg = load_config(quick=False)
w = generate_world(cfg)
g = hy._routing(w.terrain, cfg["rivers"])
step = g.c[1] - g.c[0]
ends = {}
for r in w.rivers:
    if r.mouth in ("lake", "basin") and r.into is not None:
        ends[r.into] = ends.get(r.into, 0) + 1
salt = [k for k in w.lakes if k.salt]
area = {k.id: Polygon(k.polygon).area / 1e6 for k in w.lakes}
flow = {}
for k in salt:
    cells = np.flatnonzero(g.lake_id == k.id)
    flow[k.id] = float(g.flow[cells].max())
none = [k.id for k in salt if k.id not in ends]
print(f"salt lakes {len(salt)}; with no river ending in them {len(none)}; drawn area total {sum(area[k.id] for k in salt):.1f} km2")
for lo, hi in ((0, .5), (.5, 1), (1, 2), (2, 5), (5, 100)):
    row = [k for k in salt if lo <= area[k.id] < hi]
    nr = sum(k.id in none for k in row)
    print(f"  {lo}-{hi} km2: {len(row)} lakes, {nr} without a river, inflow median {np.median([flow[k.id] for k in row]) if row else 0:.1f}")
print("areas of those without a river:", sorted(round(area[i], 2) for i in none))
# bed over ground off lakes
worst = 0.0
for r in w.rivers:
    xy, z = r.coords, r.profile
    gr = w.terrain.height(xy[:, 0], xy[:, 1])
    i, j = np.clip(np.floor(xy / step).astype(int), 0, g.n - 1).T
    on = g.lake_id[j * g.n + i] >= 0
    if (~on).any():
        worst = max(worst, float((z - gr)[~on].max()))
print("bed over ground off lakes", round(worst, 3))
