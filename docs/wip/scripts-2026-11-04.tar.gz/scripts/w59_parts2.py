import sys, collections, pickle
sys.path.insert(0, ".")
import numpy as np, shapely
from shapely.ops import unary_union
from shapely.geometry import LineString, Point
from citygen.config import load_config
from citygen.world import generate_world
from citygen.city import plan_city
from citygen.export.streets import street_graph
w = generate_world(load_config())
names = ["Sota", "Zouchir", "Bazar el Djedid", "Ksar el Djabrar", "Ain Khatane", "Gamar"]
for s in w.settlements:
    if s.name not in names:
        continue
    plan = plan_city(w, s)
    st = plan.streets
    nodes, edges = street_graph(st, 0.05)
    parent = list(range(len(nodes)))
    def root(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]; a = parent[a]
        return a
    for _k, _l, a, b in edges:
        parent[root(a)] = root(b)
    groups = collections.defaultdict(set)
    for k, line, a, b in edges:
        groups[root(a)].add(k)
    big = max(groups.values(), key=lambda g: sum(st[k].line.length for k in g))
    ribbons = {k: st[k].line.buffer(st[k].width / 2, cap_style="flat") for k in range(len(st))}
    bigu = unary_union([ribbons[k] for k in big])
    for g in groups.values():
        if g is big:
            continue
        best = min(((ribbons[k].distance(bigu), k) for k in g))
        k = best[1]
        # the street of the main part nearest to that ribbon, and how the side street's ends relate to it
        near = min(big, key=lambda h: ribbons[h].distance(ribbons[k]))
        ends = [Point(st[k].line.coords[0]), Point(st[k].line.coords[-1])]
        print(s.name, "| side part", sorted(st[i].kind for i in g), "| ribbon gap", round(best[0], 2), "| side street", st[k].kind, st[k].width, "main street", st[near].kind, st[near].width, "| its ends to that center line", [round(e.distance(st[near].line), 2) for e in ends], "| center gap", round(st[k].line.distance(st[near].line), 2))
