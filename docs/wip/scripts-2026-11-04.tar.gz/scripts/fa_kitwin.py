import sys; sys.path.insert(0,'.')
import numpy as np
from citygen.config import load_config, load_style
from citygen.kit import make_kit
import inspect
print(inspect.signature(load_config), inspect.signature(load_style))
cfg=load_config(None) if 0 else None
