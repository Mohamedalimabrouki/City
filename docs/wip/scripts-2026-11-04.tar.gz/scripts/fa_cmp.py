import json,sys,collections
a=json.load(open(sys.argv[1]));b=json.load(open(sys.argv[2]))
strip=lambda n:n[:-4] if n.endswith('_lit') else n
res=collections.Counter();ex=[]
for k in a:
    da,bk,pa=a[k];_,_,pb=b[k]
    if pa==pb: res[(da,'identical')]+=1; continue
    res[(da,'changed')]+=1
    A={tuple(p[1:4]):p for p in pa if not p[0].endswith('_pane_lit') and not p[0].startswith('balcon')}
    B={tuple(p[1:4]):p for p in pb if not p[0].endswith('_pane_lit') and not p[0].startswith('balcon')}
    for c,p in A.items():
        if c not in B:
            if p[0]!='window_stair' and p[0]!='window_stair_lit': res[(da,'gone',strip(p[0]).split('/')[-1][:16])]+=1; ex.append((k,p))
            else: res[(da,'stair moved')]+=1
        elif strip(p[0])!=strip(B[c][0]):
            res[(da,'swap', 'door-window' if B[c][0].startswith('window_door') else strip(B[c][0]))]+=1
    for c,p in B.items():
        if c not in A: res[(da,'new',strip(p[0]).split('/')[-1][:14])]+=1
for x,y in sorted(res.items(),key=str): print(y,x)
print(ex[:8])
