import sys, collections
sys.path.insert(0, "."); sys.path.insert(0, "tools")
import shapely
from shapely.ops import unary_union
from citygen.city import plan_city
from citygen.config import load_config
from citygen.export.streets import street_graph
from citygen.world import generate_world
w = generate_world(load_config())
for name in sys.argv[1:]:
    s = w.find(name)
    plan = plan_city(w, s)
    nodes, edges = street_graph(plan.streets, float(w.cfg["street_graph"]["grid"]))
    parent = list(range(len(nodes)))
    def root(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]; a = parent[a]
        return a
    for _k, _l, a, b in edges:
        parent[root(a)] = root(b)
    parts = collections.defaultdict(list)
    for k, line, a, _b in edges:
        parts[root(a)].append((k, line))
    big = max(parts.values(), key=lambda p: sum(l.length for _, l in p))
    for p in parts.values():
        if p is big: continue
        kinds = collections.Counter(plan.streets[k].kind for k, _ in p)
        L = sum(l.length for _, l in p)
        a = unary_union([l for _, l in p]); b = unary_union([l for _, l in big])
        print(f"{name} ({s.kind}, pop {s.population}, radius {s.radius:.0f}): apart {dict(kinds)} {L:.0f} m, gap to the rest {a.distance(b):.1f} m, widths {sorted({plan.streets[k].width for k, _ in p})}")
