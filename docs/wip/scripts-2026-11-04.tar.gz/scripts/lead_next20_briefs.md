# Next twenty fast helpers (lead, 3 November, about 20:58 UTC): about 4 minutes each
Common: work only in your folder /tmp/claude-501/<name> (`cd` there first; a detached worktree already on the right commit). `main` = branch `claude/procedural-city-generator-xop72h`. Python `/Users/mohamedalimabrouki/Desktop/City/.venv/bin/python`. Never the em dash character. Do not touch WORKLOG, ROADMAP, HANDOFF or SPEC. Fix and test tasks change only what their section says; review and check tasks change no code. Notes in `docs/wip/<name>.md` (plain short English; findings as file:line, severity, one-line fix). Within 4 minutes of starting: commit (message `WIP <name>`, last line `Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>`) and `git push origin HEAD:refs/heads/wip/<name>` with github.com in the Bash call's allowed_domains. Write what you have even if a part is left, and say what is left. Report in one line.

## fix-side-54 (from wip/merge-prep)
review-mp-furnish (`/tmp/claude-501/review-mp-furnish/docs/wip/review-mp-furnish.md`) found that the "side" place mode at `citygen/interior/furnish.py:944` adds `+ e * (D / 2)` to a slide that already returns centres. Drop that term, add a small test that a 2.0 m sedda fits a 2.3 m back wall, run `pytest -q -k "furn or household"`, and if time is left say how the quick capital's warned-room share changes.

## fix-55 (from wip/furn-55)
From `/tmp/claude-501/shot-55/docs/wip/shot-55.md` and `/tmp/claude-501/review-55/docs/wip/review-55.md`, in `citygen/interior/kit_life.py` only: give vase_flowers stems so the heads sit on the vase neck, close the fruit_bowl's bottom (its outline must start and end on the axis), and bring pot_jasmine's hidden flowers out of the bush. `pytest -q -k "kit or home"`.

## fix-glow (from wip/furn-55)
The `_on` lights use `lamp_glow`, an exact copy of `lamp_glass`, and the viewer lights only `glass_lit` (`tools/viewer/index.html:1064`). Make `lamp_glow` really emissive in the palette (as `glass_lit` is) and light it in the viewer and the glTF export the same way; add a test that `lamp_glow` is emissive and differs from `lamp_glass`. `pytest -q -k "kit or home or export"`.

## fix-goods (from wip/shot-goods)
From `docs/wip/shot-goods.md`: the goods are too short (the top half of each shelf bay is an empty dark gap) and every row repeats one pattern. Fill the bay height and vary the rows (own random stream, no new draws on old ones). Re-render with the scratchpad's `hg_render.py` into `docs/wip/fix-goods.png`; two honest lines in `docs/wip/fix-goods.md`. `pytest -q -k "kit or shop or goods"`.

## test-scrap-hall (from wip/merge-prep)
review-mp-flats (`/tmp/claude-501/review-mp-flats/docs/wip/review-mp-flats.md`) found that the scrap-hall test still passes without the 0.8 m check. Make the test fail on a copy without that check and pass on the real code. Tests only.

## test-cache-warm (from wip/merge-prep)
From `/tmp/claude-501/review-mp-speed/docs/wip/review-mp-speed.md`: add a test that plans the same homes from empty caches and again with warm caches and compares the rooms.json bytes; under 2 s, or mark it slow. Tests only.

## fix-dar-is (from wip/merge-prep)
review-mp-speed says the `is not` filters at `citygen/interior/dar.py:598` and `601` could drop two equal pieces, since the caches now share one object for equal inputs. Check whether it can happen, and whether it does in the quick capital; if it can, filter by position instead of identity, with a test. The output must stay byte-identical unless the bug really fires (then say where).

## test-villa-369 (from wip/villas-o)
From `/tmp/claude-501/review-villas/docs/wip/review-villas.md`: nothing locks in villa 369 now passing. Add a `slow` test that plans villa 369 of the quick capital and checks it passes rooms.check. Tests only.

## test-villa-ties (from wip/villas-o)
review-villas: the stair-box search compares float area scores, so a near tie could pick another box on another machine. Count the villas and maisons of the quick capital whose best two boxes tie within 1e-9; if any, give the rounding change (file:line). Change no code.

## rev-fix-hide, rev-fix-textile, rev-fix-brass, rev-fix87, rev-fix59
Code review of the branch's own last commit (`git show --stat HEAD`, `git diff HEAD~1..HEAD`): correctness, geometry for the kit ones (normals, UVs, one-sided faces, triangle budgets), determinism, numbers in toml, tests that can fail.

## check-hide, check-textile, check-brass, check-87, check-59
Run the full `.venv/bin/python -m pytest -q` and `.venv/bin/python -m citygen build --quick` here; report pass or fail, with the failing names.
