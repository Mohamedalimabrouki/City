"""Dump (seed, size) -> capital and cities: x, y for many seeds, to compare old and new code."""
import json, sys
sys.path.insert(0, ".")
from citygen.config import load_config
from citygen.world import generate_world
out = {}
for seed in list(range(1, 41)) + [2026]:
    for size in (20, 64):
        w = generate_world(load_config(overrides={"world": {"seed": seed, "size_km": size}}))
        out[f"{seed}/{size}"] = [[s.kind, round(s.x, 3), round(s.y, 3), s.population] for s in w.settlements]
json.dump(out, open(sys.argv[1], "w"))
