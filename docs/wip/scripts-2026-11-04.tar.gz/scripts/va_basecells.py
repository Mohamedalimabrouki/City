import json, sys
sys.path.insert(0,'.')
from citygen.config import load_config
from citygen.world import generate_world
from citygen.city import CityContext
from citygen.city.layout import land_near, city_boundary
for quick in (True, False):
    for seed in (42, 7, 3):
        size='quick' if quick else 'full'
        w=generate_world(load_config(quick=quick, overrides={"world":{"seed":seed}}))
        rows=[]
        for s in w.settlements:
            row={"name":s.generated or s.name,"kind":s.kind,"x":s.x,"y":s.y,"cell":s.cell,"radius":s.radius}
            if s.kind in ('capital','city'):
                ctx=CityContext(w,s); land=land_near(w.terrain,s.x,s.y,s.radius*1.35)
                row["land"]=round(city_boundary(ctx,land).area)
            rows.append(row)
        json.dump(rows,open(f'/tmp/claude-501/va_tmp/base_{seed}_{size}.json','w'))
        print(size,seed,len(rows))
