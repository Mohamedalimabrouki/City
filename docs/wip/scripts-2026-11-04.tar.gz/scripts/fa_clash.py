import sys,json; sys.path.insert(0,'.')
import numpy as np, shapely, collections
from citygen.city.openings import piece_boxes
from citygen.city.dressing import building_highs
from citygen.interior.context import city_plan, load_build
ctx=load_build('output/bodjantouna-42',log=lambda m:None); plan=city_plan(ctx,None); d=ctx.dresser(plan); kit=ctx.kit
c=collections.Counter(); ex=[]
allrails=[]
for k,b in enumerate(plan.buildings):
    if plan.districts[b.district].kind!='colonial' or b.kind not in('house','apartments'): continue
    ps=d.building(k,float(building_highs(ctx.ground,[b])[0]))
    rails=[p for p in ps if p.piece.startswith(('balcony_iron','balconnet'))]
    if not rails: continue
    polys,z0,z1=piece_boxes(kit,rails,0.0)
    for p,g,a,bb in zip(rails,polys,z0,z1):
        c['rails']+=1
        g=g.buffer(-0.06,join_style='mitre')
        hit=[j for j in d.fp_tree.query(g) if plan.buildings[j].footprint.intersection(g).area>0.01]
        if hit:
            c['in a building '+('own' if k in hit else 'other')+' '+p.piece]+=1
            if len(ex)<8: ex.append((k,p.piece,round(p.x,1),round(p.y,1),[ (j,round(plan.buildings[j].footprint.intersection(g).area,3)) for j in hit]))
        allrails.append((k,g,a,bb))
tree=shapely.STRtree([r[1] for r in allrails])
for i,(k,g,a,bb) in enumerate(allrails):
    for j in tree.query(g):
        if j>i and abs(allrails[j][2]-a)<1.0 and allrails[j][1].intersection(g).area>0.01:
            c['rail overlaps rail']+=1
print(c); print(ex)
