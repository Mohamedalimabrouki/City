import sys, math, collections
sys.path.insert(0, "."); sys.path.insert(0, "tests")
import numpy as np, shapely
from citygen.config import load_config
from citygen.world import generate_world
from citygen.city import plan_city
from citygen.city.ground import Ground, STREET_LIFT
world = generate_world(load_config(quick=True))
plan = plan_city(world, world.capital())
ground = Ground(world, [plan])
curb = float(world.style["streets"]["curb_height"])
for w in plan.walks:
    if w.kind != "sidewalk" or w.street != 281: continue
    p = w.polygon.representative_point()
    print(w.polygon.geom_type, "area", w.polygon.area, "valid", w.polygon.is_valid, "rep", p.wkt, "contains", w.polygon.contains(p))
    print(" coords", np.round(np.asarray(w.polygon.exterior.coords), 3).tolist() if w.polygon.geom_type == "Polygon" else "multi")
    print(" walk_tree hit", len(ground.walk_tree.query(p, predicate="intersects")) if ground.walk_tree is not None else None,
          " apron hit", len(ground.apron_tree.query(p, predicate="intersects")) if ground.apron_tree is not None else None)
    print(" surface", ground.surface(p.x, p.y), "height", ground.height(p.x, p.y), "lift", ground.lift(p.x, p.y))
    print(" other attributes", {k: getattr(w, k) for k in vars(w) if k != "polygon"})
