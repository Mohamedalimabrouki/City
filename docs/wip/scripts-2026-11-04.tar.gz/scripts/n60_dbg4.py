import sys, math, collections
sys.path.insert(0, "."); sys.path.insert(0, "tests")
import numpy as np, shapely
from citygen.config import load_config
from citygen.world import generate_world
from citygen.city import plan_city
from citygen.mesh.tile import TileContext, build_tile
import test_citygen as T
world = generate_world(load_config(quick=True))
plan = plan_city(world, world.capital())
tc = TileContext(world, [plan])
s = world.capital()
print("capital", s.x, s.y, "tile size", tc.size)
xs = sorted({int(p.x // tc.size) for p in [shapely.Point(6676.9, 12075.2)]})
i, j = int(6676.9 // tc.size), int(12075.2 // tc.size)
mb, placements = build_tile(tc, i, j)
kit = tc.kit
dresser = tc.cities[0][4]
items = dresser.seafront().items()
tables = [p for p in placements if p.piece == "cafe_set"]
print("tile", i, j, "tables", len(tables))
people = [p for p in placements if kit.pieces[p.piece].category == "person"]
poses = {"person_" + k: v["pose"] for k, v in world.style["dressing"]["people"]["pieces"].items()}
for p in people:
    if poses[p.piece] == "sit": continue
    for t in tables:
        b = T._plan_box(kit, t)
        if T._plan_box(kit, p).intersects(b):
            print(p.piece, round(p.x, 2), round(p.y, 2), "table", round(t.x, 2), round(t.y, 2), "dist", round(math.hypot(p.x - t.x, p.y - t.y), 2), "overlap", round(T._plan_box(kit, p).intersection(b).area, 4),
                  "person box area", round(T._plan_box(kit, p).area, 3), "table box", round(b.area, 2))
            print("  person bounds", kit.pieces[p.piece].bounds, "table bounds", kit.pieces["cafe_set"].bounds)
