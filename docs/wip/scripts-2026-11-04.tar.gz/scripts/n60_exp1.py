"""Experiment: towns and villages on their own streams: do the roads into the capital change? (no repo change)"""
import sys, json, time
sys.path.insert(0, ".")
import numpy as np
import citygen.world as W
from citygen.config import load_config
from citygen.rng import stream
from shapely.geometry import LineString

src = open("citygen/world.py", encoding="utf-8").read()
new = src.replace('''        score = base + rng.uniform(0.0, 0.1 if kind == "capital" else 0.7, size=H.shape)''',
'''        if kind in ("town", "village"):
            rng = stream(seed, "settlements", kind)
        score = base + rng.uniform(0.0, 0.1 if kind == "capital" else 0.7, size=H.shape)''')
assert new != src
import types
M = types.ModuleType("citygen.world_exp"); M.__package__ = "citygen"
sys.modules["citygen.world_exp"] = M
exec(compile(new, "world_exp", "exec"), M.__dict__)

def boundary_roads(world, plan_boundary):
    out = []
    for r in world.roads:
        l = LineString(r.coords)
        if l.intersects(plan_boundary):
            out.append((r.kind, r.ends, np.round(r.coords, 1).tolist()))
    return out

for quick in (True, False):
    cfg = load_config(quick=quick)
    a, b = W.generate_world(cfg), M.generate_world(cfg)
    same = lambda k: sum(1 for s, t in zip(a.settlements, b.settlements) if s.kind == k and t.kind == k and (s.x, s.y, s.population) == (t.x, t.y, t.population))
    print("quick" if quick else "64km", {k: (same(k), sum(s.kind == k for s in a.settlements)) for k in W.KINDS})
    from citygen.city import plan_city
    from citygen.city.layout import city_boundary, land_near
    from citygen.city import CityContext
    ctx = CityContext(a, a.capital())
    land = land_near(a.terrain, ctx.s.x, ctx.s.y, ctx.s.radius * 1.35)
    bd = city_boundary(ctx, land)
    ra, rb = boundary_roads(a, bd), boundary_roads(b, bd)
    print(" roads crossing capital boundary before", len(ra), "after", len(rb))
    for r in ra: print("  before", r[0], r[1], len(r[2]), r[2][0], r[2][-1])
    for r in rb: print("  after ", r[0], r[1], len(r[2]), r[2][0], r[2][-1])
