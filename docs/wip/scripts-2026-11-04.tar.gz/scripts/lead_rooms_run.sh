#!/bin/bash
cd "/private/tmp/claude-501/-Users-mohamedalimabrouki-Desktop/3a588b2b-bf2f-4191-acd4-5b1ae750c3f3/scratchpad"
P=/Users/mohamedalimabrouki/Desktop/City/.venv/bin/python
B=/Users/mohamedalimabrouki/Desktop/City/output/bodjantouna-42
G=dar,compact,small,koubba,colonial,slab,shop
$P lead_rooms.py --root /tmp/claude-501/lead-before --folder $B --groups $G --out lr_cap_before.json --workers 4 > lr_cap_before.txt 2>&1 &
$P lead_rooms.py --root /tmp/claude-501/lead-after --folder $B --groups $G --out lr_cap_after.json --workers 4 > lr_cap_after.txt 2>&1 &
wait
$P lead_rooms.py --root /tmp/claude-501/lead-before --folder $B --city "Ain Chilel" --groups villa,maison --out lr_ain_before.json --workers 4 > lr_ain_before.txt 2>&1 &
$P lead_rooms.py --root /tmp/claude-501/lead-after --folder $B --city "Ain Chilel" --groups villa,maison --out lr_ain_after.json --workers 4 > lr_ain_after.txt 2>&1 &
wait
python3 -I lead_rooms_sum.py lr_cap_before.json lr_cap_after.json
python3 -I lead_rooms_sum.py lr_ain_before.json lr_ain_after.json
