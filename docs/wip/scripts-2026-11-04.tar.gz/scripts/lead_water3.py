import sys
import numpy as np
sys.path.insert(0, ".")
import citygen.hydro as hy
from citygen.config import load_config
from citygen.world import generate_world
cfg = load_config(quick=False)
w = generate_world(cfg)
g = hy._routing(w.terrain, cfg["rivers"])
step = g.c[1] - g.c[0]
worst_off = worst_on = 0.0
for r in w.rivers:
    xy, z = r.coords, r.profile
    gr = w.terrain.height(xy[:, 0], xy[:, 1])
    i, j = np.clip(np.floor(xy / step).astype(int), 0, g.n - 1).T
    on = g.lake_id[j * g.n + i] >= 0
    d = z - gr
    # a tributary's last vertex sits on the main bed: count it too
    worst_off = max(worst_off, d[~on].max() if (~on).any() else 0.0)
    worst_on = max(worst_on, d[on].max() if on.any() else 0.0)
print("bed over ground, off lake cells", round(float(worst_off), 3), "on lake cells", round(float(worst_on), 2))
