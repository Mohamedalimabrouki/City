import sys, math
sys.path.insert(0, ".")
import numpy as np, shapely
from shapely.geometry import Point, LineString
from citygen.config import load_config
from citygen.world import generate_world
from citygen.city import plan_city
from citygen.export.streets import road_links, street_graph
world = generate_world(load_config(quick=True))
plan = plan_city(world, world.capital())
nodes, edges = street_graph(plan.streets, float(world.cfg["street_graph"]["grid"]))
for link in road_links(world, plan, nodes):
    p = Point(link["x"], link["y"])
    print(link, "node to edge", round(Point(nodes[link["node"]]).distance(plan.boundary.exterior), 2))
    r = world.roads[link["road"]]
    print("   road", r.kind, r.ends, r.width)
    near = sorted((plan.streets[k].line.distance(p), plan.streets[k].kind, k, round(plan.streets[k].width, 1)) for k in range(len(plan.streets)))[:4]
    print("   nearest streets", [(round(a, 2), b, c, d) for a, b, c, d in near])
    conn = [(k, s.kind, np.round(np.asarray(s.line.coords), 1).tolist()) for k, s in enumerate(plan.streets) if s.kind == "connector"]
    print("   connectors", conn)
st = plan.station
print("station", st is not None, st.tracks.length if st is not None else None)
