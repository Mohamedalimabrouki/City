"""How rivers sit in the fine terrain: cross-sections, cuts, lake shores."""
import sys, numpy as np, shapely
from shapely.geometry import LineString, Point, Polygon
sys.path.insert(0, '.')
from citygen.config import load_config
from citygen.hydro import drainage
from citygen.terrain import Terrain
for quick, seed in ((False, 42), (False, 7), (True, 42)):
    cfg = load_config(quick=quick, overrides={"world": {"seed": seed}})
    t = Terrain(seed, cfg)
    rivers, lakes = drainage(t, cfg)
    print('=== quick' if quick else '=== full', seed, len(rivers), 'rivers', len(lakes), 'lakes', 'km', round(sum(LineString(r.coords).length for r in rivers)/1000))
    all_cut = []; lat = {o: [] for o in (5, 10, 20, 40, 80)}; lat_min=[]
    seg = []
    for r in rivers:
        p = r.coords
        d = np.gradient(p, axis=0); n = np.stack([-d[:,1], d[:,0]],1); n /= np.maximum(np.hypot(*n.T),1e-9)[:,None]
        g = t.height(p[:,0], p[:,1])
        cut = g - r.profile
        all_cut.append(cut)
        seg.append(np.hypot(*np.diff(p,axis=0).T))
        lows = []
        for o in lat:
            l = t.height(p[:,0]+n[:,0]*o, p[:,1]+n[:,1]*o); rr = t.height(p[:,0]-n[:,0]*o, p[:,1]-n[:,1]*o)
            low = np.minimum(l, rr)
            lat[o].append(g - low)      # >0: the side is lower than the center line
            lows.append(low)
        lat_min.append(g - np.min(lows, axis=0))
    c = np.concatenate(all_cut); s = np.concatenate(seg)
    print(' point spacing m: mean', round(s.mean(),1), 'max', round(s.max(),1))
    print(' cut (ground - profile): mean', round(c.mean(),2), 'p50', round(np.median(c),2), 'p90', round(np.percentile(c,90),2), 'p99', round(np.percentile(c,99),2), 'max', round(c.max(),2), ' share>2m', round((c>2).mean(),3), ' >5m', round((c>5).mean(),3), ' >10m', round((c>10).mean(),3), ' <0', round((c<-0.01).mean(),3))
    for o, v in lat.items():
        v = np.concatenate(v); print(f' side at {o} m lower than center: p50 {np.median(v):.2f} p90 {np.percentile(v,90):.2f} p99 {np.percentile(v,99):.2f} max {v.max():.2f}')
    v = np.concatenate(lat_min); print(f' lowest of sides up to 80 m lower than center: p50 {np.median(v):.2f} p90 {np.percentile(v,90):.2f} p99 {np.percentile(v,99):.2f}')
    # how much lower is the lowest ground within 150 m than the center line (the real thalweg)
    # lakes: fine terrain against the level around the polygon
    for k in lakes[:6]:
        P = Polygon(k.polygon); 
        ring = np.asarray(P.exterior.segmentize(8.0).coords)
        z = t.height(ring[:,0], ring[:,1]) - k.level
        o = P.buffer(30).exterior; o = np.asarray(o.segmentize(8.0).coords); zo = t.height(o[:,0], o[:,1]) - k.level
        i = P.buffer(-30); 
        zi = None
        if not i.is_empty:
            i = shapely.get_coordinates(i.boundary.segmentize(8.0)); zi = t.height(i[:,0], i[:,1]) - k.level
        print(f' lake {k.id} {"salt" if k.salt else "fresh"} area {P.area/1e6:.2f} ring pts {len(k.polygon)}: ring z-level min {z.min():.1f} p50 {np.median(z):.2f} max {z.max():.1f}; +30m ring min {zo.min():.1f} share<0 {(zo<0).mean():.2f}; -30m ring max {zi.max() if zi is not None else 0:.1f}')
    # dips under the receiving level near a mouth
    worst = []
    for r in rivers:
        e = r
        while e.mouth == 'river': e = rivers[e.into]
        if e.mouth in ('lake','basin'):
            L = lakes[e.into].level
            g = t.height(r.coords[:,0], r.coords[:,1])
            P = Polygon(lakes[e.into].polygon)
            dry = ~shapely.contains_xy(P, r.coords[:,0], r.coords[:,1])
            under = (g < L) & dry
            if under.any():
                worst.append((r.id, r.mouth, round(L,1), round(float((L-g[under]).max()),2), int(under.sum()), round(float(LineString(r.coords[under]).length) if under.sum()>1 else 0), round(P.distance(Point(r.coords[under][0])),0)))
    worst.sort(key=lambda a:-a[3])
    print(' rivers with ground under their lake level off the polygon:', len(worst), worst[:12])
