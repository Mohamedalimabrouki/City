"""Lake rings: how far below the level the fine ground lies at a distance from the polygon; river counts by mouth."""
import sys, numpy as np, shapely, collections
from shapely.geometry import LineString, Point, Polygon
sys.path.insert(0, '.')
from citygen.config import load_config
from citygen.hydro import drainage
from citygen.terrain import Terrain, classify, BIOME_NAMES
for quick, seed in ((False, 42), (False, 7), (False, 3), (True, 42), (True, 7), (True, 3)):
    cfg = load_config(quick=quick, overrides={"world": {"seed": seed}})
    t = Terrain(seed, cfg)
    rivers, lakes = drainage(t, cfg)
    print('===', 'quick' if quick else 'full', seed, len(rivers), 'rivers', len(lakes), 'lakes', sum(k.salt for k in lakes), 'salt; seasonal', sum(r.seasonal for r in rivers))
    # rivers reaching a basin: how many perennial, with what length
    reach = {}
    def end(r):
        while r.mouth == 'river': r = rivers[r.into]
        return r.mouth
    ends = collections.Counter((end(r), r.seasonal) for r in rivers)
    print(' ends (mouth of the network, seasonal):', sorted(ends.items()))
    km = collections.Counter()
    for r in rivers: km[(end(r), r.seasonal)] += LineString(r.coords).length/1000
    print(' km:', sorted((k, round(v)) for k, v in km.items()))
    for dist in (20, 30, 45, 60, 90):
        worst = []; allv = []
        for k in lakes:
            P = Polygon(k.polygon)
            o = np.asarray(P.buffer(dist).exterior.segmentize(8.0).coords)
            z = t.height(o[:, 0], o[:, 1]) - k.level
            allv.append(z); worst.append((round(float(z.min()), 2), k.id, 'salt' if k.salt else 'fresh'))
        worst.sort()
        v = np.concatenate(allv)
        print(f' +{dist} m ring: share under level {(v < 0).mean():.3f}, under -1m {(v < -1).mean():.4f}, under -2m {(v < -2).mean():.4f}, worst {worst[:5]}')
