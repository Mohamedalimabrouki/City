p = "docs/SPEC.md"
s = open(p, encoding="utf-8").read()
def sub(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a)
    s = s.replace(a, b)
sub('''graph of the city's streets, written with `plan.json`. `nodes`: `id`, `x`, `y`, `z` (the drawn street
top there, `Ground.surface`), `degree` (1 = dead end; 2 only where two different streets meet end to
end, for example a connector joining a boulevard). `edges`: `id`, `street` (index in `plan.json`
`streets`), `kind`, `width` (curb to curb, sidewalks included), `sidewalks` ([left, right]: the widest
sidewalk on each side of the street as the paint measures it, `city/parking.walk_widths`; 0 where there
is none; left is left of the edge's direction), `surface` (palette material), `length` (meters, of
''', '''graph of the city's streets, written with `plan.json`. `nodes`: `id`, `x`, `y`, `z` (the drawn street
top there, `Ground.surface`; a street's end that the grid leaves a few cm past its ribbon takes that
ribbon's top), `degree` (1 = dead end; 2 only where two different streets meet end to end, for example
a connector joining a boulevard, or at the start of a closed street). `edges`: `id`, `street` (index in
`plan.json` `streets`), `kind`, `width` (the whole street ribbon, sidewalks included: the carriageway
is `width` minus both sidewalks), `sidewalks` ([left, right]: the widest sidewalk on each side of the
street, measured with `city/parking.walk_widths` like the paint does, but for every street kind; 0
where there is none; left is left of the edge's direction), `surface` (palette material), `length` (meters, of
''')
sub('''line on a 5 cm grid (`[streets] graph_grid` in defaults.toml; `shapely.set_precision`, then `unary_union(grid_size=...)`): plain `unary_union`
''', '''line on a 5 cm grid (`[street_graph] grid` in defaults.toml; `shapely.set_precision`, then `unary_union(grid_size=...)`): plain `unary_union`
''')
sub('''the surface of the street its mouth opens on (prompt 20.2): its edge starts with a stub from the nearest
point of that street's center line, which also becomes a vertex of that street, so both snap to one
node; the impasse's `length` includes the stub.''', '''the surface of the street its mouth opens on (prompt 20.2): its edge starts with a stub from the nearest
point of that street's center line, which also becomes a vertex of that street (even for a mouth on the
line itself, with no stub), so both snap to one node; the impasse's `length` includes the stub.''')
sub('''| `cities/<name>/plan.json` | `citygen-city/1`: districts, streets, buildings,''', '''| `cities/<name>/plan.json` | `citygen-city/1`: districts (`history` since prompt 81), streets, buildings,''')
sub('''| `gazetteer.md` | readable guide for stories |
''', '''| `gazetteer.md` | readable guide for stories; each planned city lists its district histories (prompt 81) |
''')
sub('''- `Road(id, kind, width, coords, ends)`; kinds `national`, `regional`, `local`.
''', '''- `Road(id, kind, width, coords, ends)`; kinds `national`, `regional`, `local`.
- `District.history` (prompt 81, `citygen/city/history.py`, `[history]` in the style): two to four sentences for
  stories, built last in `plan_city` from the finished plan, so nothing else moves: an origin, up to `facts` (2)
  facts the map holds (gates, kasbah, boulevard landmarks, station, a neighborhood mosque, souks, a cemetery's
  shrines, quays and lighthouse, the harbor's trade, the households' top trades; drawn by `fact_weights`) and a
  "today" sentence when fewer than `min_sentences` (3) came. Eras come from `[lore] eras`, never before the
  city's founding, worded by `era_in` and `era_since`. All words live in `[history]`, none in the code. Each
  choice has its own stream, `ctx.rng("history", district id, what)` (`origin`, `facts`, `today`, `fact.<key>`
  for a list template), so editing one list changes no other sentence. A landmark belongs to the district it
  lies in, else to the first within `inside_m` (1 m: a gate on the wall line). In a world file,
  `[canon.histories."<city>"] "<district>" = "..."` replaces a text; unlike `[canon.names]`, which is keyed by
  settlement id, it is keyed by names (prompt 84 settles one keying), and a district the city does not have
  gives a warning.
''')
open(p, "w", encoding="utf-8").write(s)
