import sys,json,math; sys.path.insert(0,'.')
import numpy as np, collections
from citygen.interior.context import city_plan, load_build
from citygen.interior.outside import Outside
ctx=load_build('output/bodjantouna-42',log=lambda m:None); plan=city_plan(ctx,None)
for k in map(int,sys.argv[1:]):
    b=plan.buildings[k]; o=Outside(ctx,plan,k); kit=o.kit
    by=collections.defaultdict(collections.Counter)
    for p in o.placements:
        if 'balcon' in p.piece or 'window' in p.piece:
            by[(round(p.yaw,2))][p.piece.replace('_lit','')]+=1
    w=ctx.dresser(plan).walls(b)
    print('b',k,'high',o.high,'fh',o.fh,'floors',b.floors, b.kind)
    for i in np.argsort(-w.length)[:6]:
        c=(w.a[i]+w.b[i])/2; print(' wall',i,'len',round(w.length[i],1),'c',c.round(1),'n',w.n[i].round(3),'street',w.street[i], 'ground', round(float(ctx.ground.surface(c[0]+w.n[i][0]*5,c[1]+w.n[i][1]*5)),2))
    for y,c in by.items(): print(' yaw',y,dict(c))
