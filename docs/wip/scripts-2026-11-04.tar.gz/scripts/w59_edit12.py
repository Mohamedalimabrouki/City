def edit(p, pairs):
    s = open(p, encoding="utf-8").read()
    for a, b in pairs:
        assert s.count(a) == 1, (s.count(a), a)
        s = s.replace(a, b)
    open(p, "w", encoding="utf-8").write(s)
edit("citygen/hydro.py", [
('''drains, even on filled flats. Filled basins deep and wide enough are lakes; in steppe and
desert they are always closed (salt) basins where rivers end. Flow is the catchment area
weighted by moisture; rivers follow the cells where it passes `[rivers] min_flow`.
''', '''drains, even on filled flats. Filled basins deep and wide enough are lakes; in steppe and
desert they are always closed (salt) basins where rivers end, and a hollow left inside one
counts as a basin in its turn. Flow is the catchment area weighted by moisture; rivers follow
the cells where it passes `[rivers] min_flow`.
'''),
('''    bottom, at the lowest level that covers `wet` cells or at the spill. Its cells are 4-connected, so its shore
    is one ring; the hollows of the basin it does not reach stay out, and their water runs on from there."""
''', '''    bottom, at the lowest level that covers `wet` cells or at the spill. Its cells are 4-connected, so its shore
    is one ring; the hollows of the basin it does not reach stay out, for the next round of `_routing`."""
'''),
('''    The highest beds that never rise, never lie above the ground and take every tributary in: valleys can
    only be cut into the ground, never lifted out of it. So where a river crosses a hollow it goes down to the
    floor and cuts through the rim, and its main river stays below it from their junction on. Over a lake
    the bed is `flat`: the lake's level (a fresh lake's outlet starts there), a salt lake's floor."""
''', '''    The highest beds that never rise, never lie above the ground and take every tributary in: valleys can
    only be cut into the ground, never lifted out of it. So where a river crosses a pit too small for a lake it
    goes down to the floor and cuts through the rim, and its main river stays below it from their junction on.
    Over a lake the bed is `flat`: the lake's level (a fresh lake's outlet starts there), a salt lake's floor."""
'''),
])
edit("docs/wip/world-59.md", [
('''**River network, seed 42:** MOUTHS
''', '''**River network, seed 42:** 148 rivers: 54 end in a salt lake, 42 join a river, 31 end in a fresh lake, 18 at the sea, 3 at the
border; 13 are oueds. Sources: median 301 m (10% 71 m, 90% 545 m). Rivers reach 11.8 m wide, oueds 1.8 m.
'''),
('''Now: 206 passed, 16 slow deselected, 62 s. SLOW2
''', '''Now: 206 passed, 16 slow deselected, 62 s. `-m slow`: 15 passed, 1 xfailed,
182 s (the xfail is the old colonial one of prompt 47, `tests/test_citygen.py:4228`).
'''),
('''`test_streets_json_two_processes`, `test_world_json_two_processes`. HASHSEEDS
''', '''`test_streets_json_two_processes`, `test_world_json_two_processes`. Stronger, by hand: whole quick builds under
PYTHONHASHSEED 1 and 2: 0 of 283 parts differ.
'''),
('''No tile, no other plan part, no city map changed. COMPAREA
''', '''No tile, no other plan part, no city map changed. The quick world has no pocket over the thresholds and no wet basin, so
your two changes leave all 283 parts byte-identical to 77cfe16 (`compare w59_a`: 0 changed); they show on the 64 km world.
'''),
('''**Street survey:** quick world STREETQ. 64 km world:''', '''**Street survey:** quick world 12 of 12 in one part. 64 km world:'''),
('''- Checks: tests WLTESTS; build --quick 7.1 s,''', '''- Checks: tests 206 passed, slow 15 passed + the old xfail; build --quick 7.1 s,'''),
])
