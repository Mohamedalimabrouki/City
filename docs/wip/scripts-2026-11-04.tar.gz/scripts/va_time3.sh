#!/bin/zsh
# Times on an idle machine, main against the merge: terrain tiles twice, then the capital, one build at a time.
SP=/private/tmp/claude-501/-Users-mohamedalimabrouki-Desktop/3a588b2b-bf2f-4191-acd4-5b1ae750c3f3/scratchpad
PY=/Users/mohamedalimabrouki/Desktop/City/.venv/bin/python
for round in 1 2; do
  for t in va_main va_tree7; do
    cd /tmp/claude-501/$t
    echo "=== tiles $t round $round"
    $PY $SP/va_time2.py 2>&1 | tail -2
  done
done
for t in va_main va_tree7; do
  cd /tmp/claude-501/$t
  echo "=== capital $t"
  /usr/bin/time -p $PY -m citygen build --area capital --out /tmp/claude-501/va_time_$t --force 2>&1 | tail -4
done
for t in va_main va_tree7; do
  cd /tmp/claude-501/$t
  echo "=== quick $t"
  /usr/bin/time -p $PY -m citygen build --quick --force --out /tmp/claude-501/va_timeq_$t 2>&1 | tail -4
  /usr/bin/time -p $PY -m citygen build --quick --force --out /tmp/claude-501/va_timeq_$t 2>&1 | tail -4
done
echo "=== done"
