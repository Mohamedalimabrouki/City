"""The small part of a settlement's street graph: where it lies, and whether the shortest way to the rest crosses the river. args: seed, quick|full, name. Run from a tree."""
import sys

import shapely
from shapely.geometry import LineString
from shapely.ops import nearest_points

sys.path.insert(0, '.')
from citygen.city import plan_city, river
from citygen.config import load_config
from citygen.export.streets import street_graph
from citygen.world import generate_world

seed, quick, name = int(sys.argv[1]), sys.argv[2] == 'quick', sys.argv[3]
w = generate_world(load_config(quick=quick, overrides={"world": {"seed": seed}}))
s = next(s for s in w.settlements if s.name == name)
p = plan_city(w, s)
nodes, edges = street_graph(p.streets, float(w.cfg["street_graph"]["grid"]))
parent = list(range(len(nodes)))


def root(a):
    while parent[a] != a:
        parent[a] = parent[parent[a]]
        a = parent[a]
    return a


for _k, _l, a, b in edges:
    parent[root(a)] = root(b)
parts = {}
for k, line, a, _b in edges:
    parts.setdefault(root(a), []).append((p.streets[k].kind, line))
ranked = sorted(parts.values(), key=lambda v: -sum(line.length for _k, line in v))
main = shapely.MultiLineString([line for _k, line in ranked[0]])
water = river.corridor(w, s)
print('crossings', [(c.kind, round(c.line.length)) for c in p.crossings], 'station', p.station is not None)
for part in ranked[1:]:
    g = shapely.MultiLineString([line for _k, line in part])
    a, b = nearest_points(g, main)
    way = LineString([a, b])
    kinds = {}
    for k, line in part:
        kinds[k] = kinds.get(k, 0) + 1
    print('part', round(g.length), 'm', kinds, 'bounds', [int(v) for v in g.bounds], 'gap', round(way.length, 1), 'gap crosses the river', water is not None and way.intersects(water))
gs = [shapely.MultiLineString([line for _k, line in part]) for part in ranked]
last = gs[-1]
for k, g in enumerate(gs[:-1]):
    a, b = nearest_points(last, g)
    way = LineString([a, b])
    print('smallest part to part', k, 'length', round(g.length), 'gap', round(way.length, 1), 'crosses the river', water is not None and way.intersects(water))
