import sys
p=sys.argv[1]+"/citygen/hydro.py"; s=open(p).read()
a='''    smooth = {rid: (xy, w, _bed(xy, z, g, terrain)) for rid, (xy, w, z) in smooth.items()}
    rivers = []
    for rid, _, _, fl, seas, _, mouth, into in out:
        xy, w, z = smooth[rid]
'''
b='''    beds = _beds(out, smooth, g, terrain)
    smooth = {rid: (xy, w, beds[rid]) for rid, (xy, w, z) in smooth.items()}
    rivers = []
    for rid, _, _, fl, seas, _, mouth, into in out:
        xy, w, z = smooth[rid]
'''
assert a in s; s=s.replace(a,b)
a='''def _bed(xy, z, g: _Routing, terrain) -> np.ndarray:'''
b='''def _beds(out, smooth, g: _Routing, terrain) -> dict:
    cell = g.c[1] - g.c[0]
    joins, beds = {}, {}
    for r in reversed(out):             # ids run from the biggest river: every tributary before its main river
        rid, mouth, into = r[0], r[6], r[7]
        xy, _, z = smooth[rid]
        i, j = np.clip(np.floor(xy / cell).astype(np.int64), 0, g.n - 1).T
        low = np.where(g.lake_id[j * g.n + i] >= 0, z, terrain.height(xy[:, 0], xy[:, 1]))
        along = np.concatenate([[0.0], np.cumsum(np.hypot(*np.diff(xy, axis=0).T))])
        for s, height in joins.get(rid, []):
            k = min(int(np.searchsorted(along, s)), len(low) - 1)
            low[k] = min(low[k], height)
        beds[rid] = np.minimum.accumulate(low)
        if mouth == "river" and into is not None:
            main = LineString(smooth[into][0])
            joins.setdefault(into, []).append((main.project(Point(xy[-1])), float(beds[rid][-1])))
    return beds


def _bed(xy, z, g: _Routing, terrain) -> np.ndarray:'''
assert a in s; s=s.replace(a,b)
open(p,"w").write(s)
