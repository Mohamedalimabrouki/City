import sys; sys.path.insert(0,'.')
import json,math
from citygen.interior.context import city_plan, load_build
from citygen.interior.layout import plan_interior
from citygen.interior.outside import Outside
ctx=load_build("output/bodjantouna-42",log=lambda m:None); plan=city_plan(ctx,None); style=ctx.world.style
k=int(sys.argv[1]); o=Outside(ctx,plan,k); it=plan_interior(o,style)
print(it.layout,it.floors,it.fh,it.high)
for op in it.openings:
    if op.kind=='balcony':
        r=it.rooms[op.rooms[0]] if op.rooms[0]>=0 else None
        print(op.id,op.piece,round(op.x,2),round(op.y,2),'yaw',round(op.yaw,3),'z',round(op.z0,2),round(op.z1,2),'w',round(op.width,2),'floor',op.floor,'room',r and (r.type,round(r.polygon.area,1),round(r.polygon.centroid.x,1),round(r.polygon.centroid.y,1),round(r.z,2)))
