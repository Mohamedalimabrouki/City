import sys, numpy as np, shapely
from shapely.geometry import LineString, Polygon
sys.path.insert(0,'.')
from citygen.config import load_config
from citygen.world import generate_world
for seed in (42,7,3):
    w=generate_world(load_config(overrides={"world":{"seed":seed}})); c=w.carve
    deep=[]; km={2:0,5:0,10:0}
    for r in w.rivers:
        g=w.terrain.height(*r.coords.T); d=g-r.surface
        deep.append((round(float(d.max()),1),r.id,r.seasonal))
        seg=np.hypot(*np.diff(r.coords,axis=0).T); dm=0.5*(d[1:]+d[:-1])
        for k in km: km[k]+=seg[dm>k].sum()/1000
    deep.sort(reverse=True)
    raised=[]
    for sh in c.shores:
        ring=np.asarray(sh.zone.exterior.segmentize(16.0).coords)
        h0=np.asarray(w.terrain.height(ring[:,0],ring[:,1])); h=c.fill(ring[:,0],ring[:,1],h0)
        raised.append((h-h0))
    raised=np.concatenate(raised)
    print(seed,'deepest',deep[:3],'km over',{k:round(v,1) for k,v in km.items()},'rivers km',round(sum(LineString(r.coords).length for r in w.rivers)/1000),'rim raised: share',round(float((raised>0.01).mean()),3),'mean of raised',round(float(raised[raised>0.01].mean()),2),'max',round(float(raised.max()),2),'levee segs',len(c.levees),'of',len(c.table),'max levee rise',round(float((c.levees[:,4]-(c.levees[:,4]-c.levees[:,7]*c.levee_slope)).max()),2) if len(c.levees) else '')
