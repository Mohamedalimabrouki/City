"""Rooms that need daylight and have none: what walls could they get a window on? usage fa_dark.py every"""
import sys,collections,json; sys.path.insert(0,'.')
import numpy as np, shapely
from shapely.geometry import LineString
from shapely.geometry.polygon import orient
from citygen.interior.context import city_plan, load_build, layout_of
from citygen.interior.layout import plan_interior
from citygen.interior.outside import Outside
from citygen.city import plan_city
from citygen.interior.context import BuildContext
ctx=load_build('output/bodjantouna-42',log=lambda m:None)
city=sys.argv[3] if len(sys.argv)>3 else None
if city:
    st=next(s for s in ctx.world.settlements if s.name==city)
    if not any(p.settlement is st for p in ctx.plans): ctx=BuildContext(ctx.world,[plan_city(ctx.world,st)],st)
plan=city_plan(ctx,city); style=ctx.world.style
every=int(sys.argv[1]); groups=sys.argv[2].split(',')
d=ctx.dresser(plan)
NEED=("chambre","cuisine","salon","salle_a_manger")
LIGHT=("window","balcony","court_window","court_door")
tot=collections.Counter(); kinds=collections.Counter(); bylen=collections.Counter(); ex=collections.defaultdict(list)
n=collections.Counter()
for k,b in enumerate(plan.buildings):
    if b.kind not in("house","domed","apartments","villa"): continue
    lay=layout_of(plan,b,style)
    if lay not in groups: continue
    n[lay]+=1
    if n[lay]%every: continue
    it=plan_interior(Outside(ctx,plan,k),style)
    w=d.walls(b,k)
    segs=[]
    for i in range(len(w.a)):
        kind='street' if w.street[i]>=0 else 'open' if w.open[i] else 'closed'
        if kind=='closed':
            m=(w.a[i]+w.b[i])/2+w.n[i]*0.05
            from shapely.geometry import Point
            near=[plan.buildings[j].footprint.distance(Point(*m)) for j in d.fp_tree.query(Point(*m).buffer(4)) if j!=k]
            g=min(near) if near else 9
            kind='closed<.6' if g<.6 else 'closed<1.5' if g<1.5 else 'closed>=1.5'
        elif kind=='open':
            fl,_=None,None
            kind='open-gable' if b.kind=='apartments' and w.length[i]<0.6*__import__('citygen.city.geo',fromlist=['frame']).frame(b.footprint)[2] else 'open-long'
        segs.append((LineString([w.a[i],w.b[i]]),kind,i))
    for h in orient(b.footprint,1.0).interiors:
        r=np.asarray(h.coords)[:,:2]
        for a,c in zip(r[:-1],r[1:]): segs.append((LineString([a,c]),'court',-1))
    tree=[s[0] for s in segs]
    lit=collections.Counter()
    for o in it.openings:
        if o.kind in LIGHT:
            for r in o.rooms:
                if r>=0: lit[r]+=1
    for r in it.rooms:
        if r.type not in NEED: continue
        tot[(lay,r.type,'all')]+=1
        if lit[r.id]: continue
        tot[(lay,r.type,'dark')]+=1
        pad=r.polygon.buffer(0.65,join_style='mitre')
        best={}
        for s,kind,i in segs:
            L=s.intersection(pad).length
            if L>0.5: best[kind]=max(best.get(kind,0),L)
        if not best: key='no wall'
        else:
            kk=max(best,key=lambda q:(best[q]>=1.8,{'street':3,'court':2,'open-long':2.5,'open-gable':2.4,'closed<.6':0,'closed<1.5':1,'closed>=1.5':1.5}[q],best[q]))
            key=f"{kk} {'>=1.8' if best[kk]>=1.8 else '<1.8'}"
        kinds[(lay,r.type,key,'floor0' if r.floor==0 else 'upper')]+=1
        if len(ex[key])<6: ex[key].append((k,r.floor,r.type))
for a,b_ in sorted(tot.items()): print(a,b_)
for a,b_ in sorted(kinds.items(),key=lambda x:(x[0][0],-x[1])): print(b_,a)
print(dict(ex))
