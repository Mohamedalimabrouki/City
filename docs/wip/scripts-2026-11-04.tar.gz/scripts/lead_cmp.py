"""Compare two lead_hash.py results: per group the passes, identical plans, won, lost and changed.

    python lead_cmp.py BEFORE.json AFTER.json [--show g,g]
"""
import argparse
import json
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("before")
    ap.add_argument("after")
    ap.add_argument("--show", default="", help="groups whose changed buildings to list")
    a = ap.parse_args()
    b0, b1 = (json.loads(Path(p).read_text()) for p in (a.before, a.after))
    show = set(g for g in a.show.split(",") if g)
    groups = sorted({r["g"] for r in (*b0.values(), *b1.values())})
    for g in groups:
        ks = sorted({k for k, r in b0.items() if r["g"] == g} | {k for k, r in b1.items() if r["g"] == g}, key=int)
        same = won = lost = changed = 0
        moved = []
        for k in ks:
            r0, r1 = b0.get(k, {}), b1.get(k, {})
            if r0.get("h") == r1.get("h") and r0.get("g") == r1.get("g"):
                same += 1
                continue
            changed += 1
            moved.append(k)
            won += bool(r1.get("ok")) and not r0.get("ok")
            lost += bool(r0.get("ok")) and not r1.get("ok")
        p0 = sum(bool(r.get("ok")) for r in b0.values() if r["g"] == g)
        p1 = sum(bool(r.get("ok")) for r in b1.values() if r["g"] == g)
        c0 = max((r.get("cpu", 0) for r in b0.values() if r["g"] == g), default=0)
        c1 = max((r.get("cpu", 0) for r in b1.values() if r["g"] == g), default=0)
        print(f"{g:9s} pass {p0:4d} -> {p1:4d} | identical {same:4d}, changed {changed:4d} "
              f"(won {won}, lost {lost}) | slowest CPU {c0:.2f} -> {c1:.2f} s")
        if g in show and moved:
            print(f"   changed: {moved[:40]}")


if __name__ == "__main__":
    main()
