def edit(p, pairs):
    s = open(p, encoding="utf-8").read()
    for a, b in pairs:
        assert s.count(a) == 1, (s.count(a), a)
        s = s.replace(a, b)
    open(p, "w", encoding="utf-8").write(s)
edit("citygen/hydro.py", [
('''    A lake spreads until evaporation from its surface (`lake_area_per_flow` km2 per km2 of
    inflow) takes all the water that reaches it: a basin of wet country that fills up spills
    over and its river goes on, one that does not fill just drains. In steppe and desert every
    basin keeps its water (endorheic), in a lake of at least `lake_min_area`."""
''', '''    Water cannot drain out of a hollow, so a basin of wet country is a lake up to its spill and
    its river goes on from there. In steppe and desert every basin keeps its water (endorheic):
    its lake spreads until evaporation from its surface (`lake_area_per_flow` km2 per km2 of
    inflow) takes all the water that reaches it, in `lake_min_area` at the least."""
'''),
('''        wet = math.ceil(float(rc["lake_area_per_flow"]) * inflow[k] * 1e6 / (cell * cell))
        is_salt = int(biome[bottom[k]]) in (STEPPE, DESERT)
        if is_salt:
            wet = max(wet, math.ceil(min_cells))
        elif wet < size:
            continue                    # too little water to fill it: a damp hollow that drains
        out.append((int(ids[k]), wet, is_salt))
''', '''        is_salt = int(biome[bottom[k]]) in (STEPPE, DESERT)
        balance = math.ceil(float(rc["lake_area_per_flow"]) * inflow[k] * 1e6 / (cell * cell))
        wet = max(balance, math.ceil(min_cells)) if is_salt else int(size)
        out.append((int(ids[k]), wet, is_salt))
'''),
])
edit("citygen/defaults.toml", [
('''lake_area_per_flow = 0.04 # square kilometers of lake surface that evaporate the water of 1 km2 of catchment
''', '''lake_area_per_flow = 0.04 # salt lakes only: square kilometers of surface that evaporate the water of 1 km2 of catchment
'''),
])
edit("citygen/city/history.py", [
('''from shapely.geometry import Point

def histories(ctx, plan) -> None:
''', '''from shapely.geometry import Point


def histories(ctx, plan) -> None:
'''),
])
