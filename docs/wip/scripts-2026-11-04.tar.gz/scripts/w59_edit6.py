def edit(p, pairs):
    s = open(p, encoding="utf-8").read()
    for a, b in pairs:
        assert s.count(a) == 1, (s.count(a), a)
        s = s.replace(a, b)
    open(p, "w", encoding="utf-8").write(s)
edit("tools/street_survey.py", [
('''    world = WORLD.setdefault(quick, None) or WORLD.__setitem__(quick, generate_world(load_config(quick=quick))) \\
        or WORLD[quick]
    s = world.settlements[i]
''', '''    if quick not in WORLD:
        WORLD[quick] = generate_world(load_config(quick=quick))
    world = WORLD[quick]
    s = world.settlements[i]
'''),
])
edit("tests/test_citygen.py", [
('''@pytest.mark.slow  # two processes plan the quick capital, about 20 s
def test_streets_json_two_processes(tmp_path):
''', '''@pytest.mark.slow  # plans every settlement of the quick world, about 10 s
def test_street_graph_of_every_settlement_holds_together(world):
    from citygen.export.streets import street_graph
    grid = float(world.cfg["street_graph"]["grid"])
    for s in world.settlements:
        nodes, edges = street_graph(plan_city(world, s).streets, grid)
        parts = _graph_parts(nodes, [(a, b, line.length) for _k, line, a, b in edges])
        if parts:                                  # a hamlet can have no street at all
            assert max(parts.values()) >= 0.995 * sum(parts.values()), s.name


@pytest.mark.slow  # two processes plan the quick capital, about 20 s
def test_streets_json_two_processes(tmp_path):
'''),
])
