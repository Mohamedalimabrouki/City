from PIL import Image, ImageDraw
SP='/private/tmp/claude-501/-Users-mohamedalimabrouki-Desktop/3a588b2b-bf2f-4191-acd4-5b1ae750c3f3/scratchpad'
for n in ('street','night'):
    a=Image.open(f'{SP}/fa_s_{n}_b.png').convert('RGB');b=Image.open(f'{SP}/fa_s_{n}_a.png').convert('RGB')
    s=Image.new('RGB',(a.width*2+10,a.height),(255,255,255));s.paste(a,(0,0));s.paste(b,(a.width+10,0))
    d=ImageDraw.Draw(s);d.text((8,8),'before',fill=(255,255,0));d.text((a.width+18,8),'after',fill=(255,255,0))
    s.save(f'/tmp/claude-501/facades/docs/wip/facades-{n}.png',optimize=True)
