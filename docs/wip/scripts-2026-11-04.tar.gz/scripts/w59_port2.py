"""Second part of the hydro edits (the bed of the whole network, the true shore), on top of w59_port.py."""
import sys
p = sys.argv[1]
s = open(p).read()
def sub(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a)
    s = s.replace(a, b)

# the bed: no heights along the chains any more, the ground under the smoothed lines
sub('''        xy = np.column_stack([c[cells % n], c[cells // n]])
        z = np.minimum.accumulate(filled[cells])
        f = flow[cells].copy()
''', '''        xy = np.column_stack([c[cells % n], c[cells // n]])
        f = flow[cells].copy()
''')
sub('''        out.append([new_id[k], xy, w, float(f[-1]), bool(seasonal), z, mouth, into])
    smooth = {r[0]: _smooth(r[1], r[2], r[5]) for r in out}
    smooth = {rid: (xy, w, _bed(xy, z, g, terrain)) for rid, (xy, w, z) in smooth.items()}
    rivers = []
    for rid, _, _, fl, seas, _, mouth, into in out:
        xy, w, z = smooth[rid]
        if mouth == "river" and into is not None:
            xy, z = _snap(xy, z, smooth[into][0], smooth[into][2])
        rivers.append(River(rid, xy, w, fl, seas, z, mouth, into))
    return rivers
''', '''        out.append((new_id[k], xy, w, float(f[-1]), bool(seasonal), mouth, into))
    lines = {r[0]: _smooth(r[1], r[2]) for r in out}
    beds = _beds(out, lines, g, terrain)
    rivers = []
    for rid, _, _, fl, seas, mouth, into in out:
        xy, w = lines[rid]
        z = beds[rid]
        if mouth == "river" and into is not None:
            xy, z = _snap(xy, z, lines[into][0], beds[into])
        rivers.append(River(rid, xy, w, fl, seas, z, mouth, into))
    return rivers
''')
sub('''    filled, flow, catch, sea, salt, lake_id, c, n = g.flat, g.flow, g.catch, g.sea, g.salt, g.lake_id, g.c, g.n
''', '''    flow, catch, sea, salt, lake_id, c, n = g.flow, g.catch, g.sea, g.salt, g.lake_id, g.c, g.n
''')
sub('''def _smooth(xy, w, z, rounds: int = 2) -> tuple:
    """Rounded D8 staircase: a moving average, then Chaikin corner cutting; the ends stay put.

    Every new value is an average of neighbors, so a profile that never rises stays so."""
    if len(xy) < 3:
        return xy, w, z
    a = np.column_stack([xy, w, z])
''', '''def _smooth(xy, w, rounds: int = 2) -> tuple:
    """Rounded D8 staircase: a moving average, then Chaikin corner cutting; the ends stay put."""
    if len(xy) < 3:
        return xy, w
    a = np.column_stack([xy, w])
''')
sub('''    return a[:, :2], a[:, 2], np.minimum.accumulate(a[:, 3])
''', '''    return a[:, :2], a[:, 2]
''')
i, j = s.index("def _bed(xy, z, g: _Routing, terrain)"), s.index("def _snap(xy, z, main_xy, main_z)")
s = s[:i] + '''def _beds(out, lines, g: _Routing, terrain) -> dict:
    """{river id: bed height along its smoothed line}, tributaries first (ids run from the biggest river down).

    The highest beds that never rise, never lie above the ground and take every tributary in: valleys can
    only be cut into the ground, never lifted out of it. So where a river crosses a hollow it goes down to the
    floor and cuts through the rim, and its main river stays below it from their junction on. Over a lake
    the bed is `flat`: the lake's level (a fresh lake's outlet starts there), a salt lake's floor."""
    step = g.c[1] - g.c[0]
    joins, beds = {}, {}
    for rid, _, _, _, _, mouth, into in reversed(out):
        xy = lines[rid][0]
        i, j = np.clip(np.floor(xy / step).astype(np.int64), 0, g.n - 1).T
        cells = j * g.n + i
        z = np.where(g.lake_id[cells] >= 0, g.flat[cells], terrain.height(xy[:, 0], xy[:, 1]))
        for at, low in joins.get(rid, []):
            z[at] = min(z[at], low)
        beds[rid] = np.minimum.accumulate(z)
        if mouth == "river" and into is not None:
            main = lines[into][0]
            at = np.searchsorted(_along(main), LineString(main).project(Point(xy[-1])))
            joins.setdefault(into, []).append((max(int(at) - 1, 0), float(beds[rid][-1])))
    return beds


def _along(xy) -> np.ndarray:
    return np.concatenate([[0.0], np.cumsum(np.hypot(*np.diff(xy, axis=0).T))])


''' + s[j:]
sub('''    """A tributary ends on its main river's smoothed line, on the main bed there; if the point before
    already lies lower it stays at that height, as a bed never rises."""
    line = LineString(main_xy)
    s = line.project(Point(xy[-1]))
    p = line.interpolate(s)
    seg = np.concatenate([[0.0], np.cumsum(np.hypot(*np.diff(main_xy, axis=0).T))])
    zm = float(np.interp(s, seg, main_z))
    xy = xy.copy()
    xy[-1] = (p.x, p.y)
    z = z.copy()
    z[-1] = min(zm, z[-2]) if len(z) > 1 else zm
    return xy, z
''', '''    """A tributary ends on its main river's smoothed line, on the main bed there (`_beds` keeps that bed
    no higher than the tributary's, so its profile still never rises)."""
    line = LineString(main_xy)
    s = line.project(Point(xy[-1]))
    p = line.interpolate(s)
    xy = xy.copy()
    xy[-1] = (p.x, p.y)
    z = z.copy()
    z[-1] = float(np.interp(s, _along(main_xy), main_z))
    return xy, z
''')

# the true shore
sub('''    f = np.where(mask, H, level + 50.0)
    f = np.pad(f, 1, constant_values=level + 50.0)
''', '''    f = np.where(mask, H, np.maximum(H, level + 1.0))   # other hollows under the level stay out
    f = np.pad(f, 1, constant_values=level + 50.0)
''')
open(p, "w").write(s)
