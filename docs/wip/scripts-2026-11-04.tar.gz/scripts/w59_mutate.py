import subprocess, sys, shutil
PY = sys.executable
F = "citygen/hydro.py"
good = open(F).read()
M = {
 "rule (a) off: dry basins with little water drain": ('''        if is_salt:
            wet = max(wet, math.ceil(min_cells))
        elif wet < size:
            continue                    # too little water to fill it: a damp hollow that drains
''', '''        if wet < min_cells or (not is_salt and wet < size):
            continue
'''),
 "rule (b) off: every pocket under the level is water": ('''        parts, _ = ndimage.label(m & (h <= level))
        return parts == parts[bottom]
''', '''        return m & (h <= level)
'''),
 "8-connected lake (a corner joins two parts)": ('''        parts, _ = ndimage.label(m & (h <= level))
''', '''        parts, _ = ndimage.label(m & (h <= level), np.ones((3, 3), dtype=bool))
'''),
 "bed = the flood's filled height (the prompt's words)": ('''        z = np.where(g.lake_id[cells] >= 0, g.flat[cells], terrain.height(xy[:, 0], xy[:, 1]))
''', '''        z = g.flat[cells]
'''),
 "no tributary reaches its main bed": ('''        for at, low in joins.get(rid, []):
            z[at] = min(z[at], low)
''', ''),
 "tributary keeps its own end (no snap of the height)": ('''    z[-1] = float(np.interp(s, _along(main_xy), main_z))
''', ''),
 "shore half a cell inside (no true contour)": ('''    f = np.where(mask, H, np.maximum(H, level + 1.0))   # other hollows under the level stay out
''', '''    f = np.where(mask, H, level + 50.0)
'''),
 "receivers out of order (salt re-flood skipped)": ('''            recv[gi[dry_cells]] = gi[sub_r[dry_cells]]
''', ''),
}
try:
    for name, (a, b) in M.items():
        assert good.count(a) == 1, a
        open(F, "w").write(good.replace(a, b))
        r = subprocess.run([PY, "-m", "pytest", "-q", "-x", "--no-header", "-p", "no:cacheprovider", "tests/test_hydro.py", "--tb=no", "-q"], capture_output=True, text=True)
        r2 = subprocess.run([PY, "-m", "pytest", "-q", "--no-header", "-p", "no:cacheprovider", "tests/test_hydro.py", "--tb=no"], capture_output=True, text=True)
        failed = [l.split("::")[1].split(" ")[0] for l in r2.stdout.splitlines() if l.startswith("FAILED")]
        print(f"{name}: {len(failed)} failed: {failed[:6]}")
finally:
    open(F, "w").write(good)
