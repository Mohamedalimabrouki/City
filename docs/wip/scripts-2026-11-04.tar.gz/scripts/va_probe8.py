import sys, numpy as np, shapely
from shapely.geometry import LineString, Point, Polygon
sys.path.insert(0,'.')
from citygen.config import load_config
from citygen.world import generate_world
from citygen.hydro import channel
w=generate_world(load_config()); c=w.carve
best=[]
for r in w.rivers:
    g=w.terrain.height(*r.coords.T); d=g-r.surface
    i=int(np.argmax(d)); best.append((round(float(d[i]),1),r.id,np.round(r.coords[i]).tolist(),r.seasonal,round(float(r.surface[i]),1), r.mouth))
best.sort(reverse=True); print('deepest',best[:6])
print('cut km >5m', round(sum(((w.terrain.height(*r.coords.T)-r.surface)>5).sum()*10 for r in w.rivers)/1000,1),'>10m',round(sum(((w.terrain.height(*r.coords.T)-r.surface)>10).sum()*10 for r in w.rivers)/1000,1), '>2m', round(sum(((w.terrain.height(*r.coords.T)-r.surface)>2).sum()*10 for r in w.rivers)/1000,1))
oued=sorted([r for r in w.rivers if r.seasonal],key=lambda r:-r.flow)[:5]
for r in oued:
    n=len(r.coords); print('oued',r.id,round(r.flow,1),r.mouth,r.into,np.round(r.coords[[n//2,-1]]).tolist(),'z',round(float(r.surface[n//2]),1),round(float(r.surface[-1]),1),'w',round(float(r.widths[n//2]),1))
j=[r for r in w.rivers if r.mouth=='river' and not r.seasonal and not w.rivers[r.into].seasonal]
j.sort(key=lambda r:-min(r.flow,w.rivers[r.into].flow))
for r in j[:4]:
    print('junction',r.id,'into',r.into,np.round(r.coords[-1]).tolist(),'z',round(float(r.surface[-1]),1),'widths',round(float(r.widths[-1]),1))
m=[r for r in w.rivers if r.mouth=='lake' and not r.seasonal]; m.sort(key=lambda r:-r.flow)
for r in m[:3]: print('lake mouth',r.id,r.into,round(w.lakes[r.into].level,1),np.round(r.coords[-1]).tolist())
s=[r for r in w.rivers if r.mouth=='sea']; s.sort(key=lambda r:-r.flow)
for r in s[:3]: print('sea mouth',r.id,np.round(r.coords[-1]).tolist(), round(float(r.widths[-1]),1))
