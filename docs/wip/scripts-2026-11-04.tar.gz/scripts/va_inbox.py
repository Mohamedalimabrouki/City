import sys, numpy as np
sys.path.insert(0,'.')
from citygen.config import load_config
from citygen.world import generate_world
from shapely.geometry import box, LineString
w=generate_world(load_config(overrides={"world":{"seed":42}}))
b=box(*[float(v)*1000 for v in sys.argv[1].split(',')])
for r in w.rivers:
    l=LineString(r.coords).intersection(b)
    if not l.is_empty: print('river',r.id,r.seasonal,round(l.length),[int(v) for v in l.bounds], 'order',getattr(r,'order',None))
for rd in w.roads:
    l=LineString(rd.coords if hasattr(rd,'coords') else rd['coords']).intersection(b)
    if not l.is_empty: print('road',getattr(rd,'kind',''),round(l.length),[int(v) for v in l.bounds])
for s in w.settlements:
    if b.buffer(800).contains(__import__('shapely').Point(s.x,s.y)): print('settlement',s.name,s.kind,int(s.x),int(s.y))
