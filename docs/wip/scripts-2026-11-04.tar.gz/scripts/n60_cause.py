"""Is the change of the capital's plan caused by the roads alone? New code, new world, the OLD world's roads."""
import json, sys
from dataclasses import replace
sys.path.insert(0, ".")
import numpy as np
from citygen.city import plan_city
from citygen.config import load_config
from citygen.export.lore import plan_json
from citygen.world import Road, generate_world
base = sys.argv[1]
old_world = json.load(open(base + "/world.json"))
old_plan = json.load(open(base + "/cities/goumosbane/plan.json"))
world = generate_world(load_config(quick=True))
import pickle
roads = [Road(*r) for r in pickle.load(open(sys.argv[2], "rb"))]
plan = plan_city(replace(world, roads=roads), world.capital())
new = json.loads(json.dumps(plan_json(plan), separators=(",", ":")))

def strip(o):
    if isinstance(o, dict):
        return {k: strip(v) for k, v in o.items() if k != "name_ar" and "seconds" not in k}
    if isinstance(o, list):
        return [strip(v) for v in o]
    return o
a, b = strip(old_plan), strip(new)
print("parts of plan.json:", len(a), len(b), sorted(set(a) ^ set(b)))
for k in sorted(a):
    if a[k] != b.get(k):
        n = len(a[k]) if hasattr(a[k], "__len__") else 1
        if isinstance(a[k], list):
            d = sum(x != y for x, y in zip(a[k], b[k]))
            print(f"  {k}: differs in {d} of {n} entries", [(x, y) for x, y in zip(a[k], b[k]) if x != y][:2] if k not in ("buildings",) else "")
        else:
            print(f"  {k}: differs:", {q: (a[k][q], b[k].get(q)) for q in a[k] if a[k][q] != b[k].get(q)} if isinstance(a[k], dict) else "")
print("identical parts:", sum(a[k] == b.get(k) for k in a), "of", len(a))
