"""Lead's timing tool: CPU seconds to plan given buildings, with the code of --root (one process, warm).

    python lead_time.py --root CODE --folder BUILD [--city NAME] --ids 923,332 [--runs 2]
"""
import argparse
import sys
import time
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--folder", required=True)
    ap.add_argument("--city")
    ap.add_argument("--ids", required=True)
    ap.add_argument("--runs", type=int, default=2)
    a = ap.parse_args()
    sys.path.insert(0, str(Path(a.root).resolve()))
    from citygen.city import plan_city
    from citygen.interior import rooms as R
    from citygen.interior.context import BuildContext, city_plan, load_build
    from citygen.interior.layout import plan_interior
    from citygen.interior.outside import Outside
    ctx = load_build(Path(a.folder), log=lambda m: None)
    if a.city:
        s = next(s for s in ctx.world.settlements if s.name.lower() == a.city.lower())
        if not any(p.settlement is s for p in ctx.plans):
            ctx = BuildContext(ctx.world, [plan_city(ctx.world, s)], s)
    plan = city_plan(ctx, a.city)
    for k in (int(x) for x in a.ids.split(",")):
        plan_interior(Outside(ctx, plan, k), ctx.world.style)          # warm the caches once
        cpu = []
        for _ in range(a.runs):
            t = time.process_time()
            it = plan_interior(Outside(ctx, plan, k), ctx.world.style)
            cpu.append(time.process_time() - t)
        print(f"No. {k}: {' / '.join(f'{c:.2f}' for c in cpu)} s CPU, {'passes' if not R.check(it) else 'fails'}")


if __name__ == "__main__":
    main()
