import sys, itertools
sys.path.insert(0, ".")
import shapely
from shapely.geometry import LineString, Point
from citygen.city.model import Street
import citygen.export.streets as S
found = 0
for ax, ay, bx, by in itertools.product((0.01, 0.02, 0.024), (0.01, 0.02, 0.024), (90.01, 90.03, 90.024), (37.01, 37.03, 37.024)):
    host_line = LineString([(ax, ay), (bx, by)])
    for n in range(40, 3960, 7):
        t = n / 4000.0
        p = host_line.interpolate(t, normalized=True)
        q = host_line.interpolate(host_line.project(p))
        if p.distance(q) != 0.0:
            continue
        lane = LineString([(p.x, p.y), (p.x - 8.0, p.y + 20.0)])
        streets = [Street("street", 8.0, host_line), Street("impasse", 3.0, lane)]
        snapped = [shapely.set_precision(s.line, 0.05) for s in streets]
        union = shapely.unary_union(snapped, grid_size=0.05)
        pieces = len(getattr(union, "geoms", [union]))
        nodes, edges = S.street_graph(streets, 0.05)
        if pieces == 2:
            found += 1
            if found <= 4:
                print((ax, ay, bx, by), "n", n, repr(p.x), repr(p.y), "plain pieces", pieces, "graph nodes", len(nodes), "edges", len(edges))
print("found", found)
