#!/bin/zsh
# Slab rates on more worlds, main against the merge. One argument: the seed.
PY=/Users/mohamedalimabrouki/Desktop/City/.venv/bin/python
s=$1
for t in va_main va_tree7; do
  cd /tmp/claude-501/$t
  $PY -m citygen build --quick --seed $s --out /tmp/claude-501/va_s_$t/q$s 2>&1 | tail -1 | cut -c1-90
  $PY tools/interior_survey.py --folder /tmp/claude-501/va_s_$t/q$s/* --groups slab > /tmp/claude-501/va_tmp/surv_slab_${t}_$s.txt 2>&1
done
