import sys
sys.path.insert(0, sys.argv[1])
import numpy as np, shapely
from shapely.geometry import Polygon, Point, LineString
from citygen.config import load_config
from citygen.world import generate_world
for quick in (True, False):
    w = generate_world(load_config(quick=quick))
    polys = [(k, Polygon(k.polygon)) for k in w.lakes]
    touch = []
    for s in w.settlements:
        disc = Point(s.x, s.y).buffer(s.radius)
        for k, p in polys:
            if disc.intersects(p):
                touch.append((s.name, s.kind, "salt" if k.salt else "fresh", round(p.distance(Point(s.x, s.y)), 0), round(s.radius), round(disc.intersection(p).area / 1e6, 2)))
    roads = 0
    for r in w.roads:
        line = LineString(r.coords)
        roads += any(line.intersects(p) for k, p in polys)
    print("quick" if quick else "64km", "settlements", len(w.settlements), "touching a lake:", len({t[0] for t in touch}), "roads crossing a lake:", roads, "of", len(w.roads))
    for t in sorted(touch, key=lambda t: {"capital":0,"city":1,"town":2,"village":3}[t[1]]): print("   ", t)
    src = np.array([w.terrain.height(r.coords[0,0], r.coords[0,1]) for r in w.rivers if r.mouth != "lake" or True])
    print("   river sources: height m median", round(float(np.median(src))), "p10", round(float(np.percentile(src,10))), "p90", round(float(np.percentile(src,90))), "; widths: rivers mouth width max", round(max(float(r.widths[-1]) for r in w.rivers if not r.seasonal),1), "oueds max", round(max([float(r.widths.max()) for r in w.rivers if r.seasonal] or [0]),1), "; seasonal", sum(r.seasonal for r in w.rivers), "of", len(w.rivers))
