"""Dump the gazetteer of a world (settlement list) as JSON. Usage: n60_gaz.py OUT [--quick]"""
import json, sys
sys.path.insert(0, ".")
from citygen.config import load_config
from citygen.world import generate_world
out = sys.argv[1]
quick = "--quick" in sys.argv
w = generate_world(load_config(quick=quick))
rows = [{"id": s.id, "name": str(s.name), "name_ar": getattr(s, "name_ar", ""), "kind": s.kind, "x": round(s.x, 3), "y": round(s.y, 3),
         "population": s.population, "radius": round(s.radius, 3), "elevation": round(s.elevation, 3), "coastal": s.coastal, "biome": s.biome,
         "known_for": s.known_for, "founded": s.founded} for s in w.settlements]
json.dump({"country": str(w.name), "roads": len(w.roads), "settlements": rows}, open(out, "w"), ensure_ascii=False, indent=0)
print(str(w.name), len(rows), "settlements", len(w.roads), "roads")
