"""Villas and maisons of the villa town: pass rate by footprint size, fault kinds by house."""
import sys, json, collections
sys.path.insert(0, ".")
from citygen.config import load_config
from citygen.world import generate_world
from citygen.city import plan_city
from citygen.interior import rooms as R
from citygen.interior.context import BuildContext, layout_of
from citygen.interior.layout import plan_interior
from citygen.interior.outside import Outside
world = generate_world(load_config(quick=True))
towns = sorted((s for s in world.settlements if s.kind == "town"), key=lambda s: -s.population)
plan = plan_city(world, towns[0])
ctx = BuildContext(world, [plan], plan.settlement)
out = []
for k, b in enumerate(plan.buildings):
    if b.kind not in ("house", "domed", "apartments", "villa"):
        continue
    lay = layout_of(plan, b, world.style)
    if lay not in ("villa", "maison"):
        continue
    i = plan_interior(Outside(ctx, plan, k), world.style)
    bad = R.check(i)
    kinds = sorted({" ".join(w for w in p.split() if not any(c.isdigit() for c in w)) for p in bad})
    out.append(dict(k=k, layout=i.layout, want=lay, area=round(b.footprint.area, 1), floors=int(b.floors), ring=len(b.footprint.exterior.coords), holes=len(b.footprint.interiors), kinds=kinds))
json.dump(out, open(sys.argv[1], "w"))
print(len(out))
