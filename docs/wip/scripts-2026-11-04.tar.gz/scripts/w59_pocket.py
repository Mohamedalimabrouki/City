import sys
sys.path.insert(0, sys.argv[1])
import numpy as np
from scipy import ndimage
from citygen.config import load_config
from citygen import hydro
import importlib.util
spec = importlib.util.spec_from_file_location("th", sys.argv[1] + "/test_hydro.py"); th = importlib.util.module_from_spec(spec); spec.loader.exec_module(th)
cfg = load_config(quick=True); rc = cfg["rivers"]
for at in (14400, 14500, 14600, 14700, 14800):
  for ridge in (20, 30, 40, 50, 60):
    land = th._Valley(0.02, ridge=float(ridge), at=float(at))
    rivers, lakes = hydro.drainage(land, cfg)
    g = hydro._routing(land, rc)
    X, Y = np.meshgrid(g.c, g.c); H = land.height(X, Y)
    hollow = (X - 15000.0) ** 2 + (Y - 10000.0) ** 2 < 1000.0 ** 2
    if lakes:
        lv = [round(k.level, 1) for k in lakes]
        p, c = ndimage.label(hollow & (H <= lakes[0].level))
        print(at, ridge, "lakes", len(lakes), "levels", lv, "pockets", c, "cells", np.bincount(p.ravel())[1:], "lake cells", np.bincount(g.lake_id[g.lake_id>=0]), "rivers", [(r.mouth, round(r.flow,1)) for r in rivers])
