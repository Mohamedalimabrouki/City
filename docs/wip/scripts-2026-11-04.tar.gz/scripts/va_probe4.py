import sys, numpy as np, shapely, collections
from shapely.geometry import LineString, Point, Polygon
sys.path.insert(0,'.')
from citygen.config import load_config
from citygen.hydro import channel, along
from citygen.world import generate_world
seed=int(sys.argv[1]) if len(sys.argv)>1 else 42; w=generate_world(load_config(overrides={"world":{"seed":seed}})); c=w.carve; rc=w.cfg["rivers"]
lakes=[Polygon(k.polygon).buffer(0) for k in w.lakes]
for r in w.roads:
    l=LineString(r.coords)
    for k,p in enumerate(lakes):
        if l.intersects(p):
            print('road',r.id,r.kind,r.ends,'lake',k,w.lakes[k].salt,'len in',round(l.intersection(p).length,1),[ (w.settlements[e].name,w.settlements[e].kind,round(w.settlements[e].x),round(w.settlements[e].y), round(p.distance(Point(w.settlements[e].x,w.settlements[e].y)))) for e in r.ends if e is not None], 'in pts', np.round(np.asarray(l.intersection(p).coords if l.intersection(p).geom_type=='LineString' else [])[[0,-1]],0).tolist() if l.intersection(p).geom_type=='LineString' else 'multi')
bad=[]
for r in w.rivers:
    if r.seasonal: continue
    ch=channel(r,rc); rib=c.ribbons[r.id]
    d=np.gradient(r.coords,axis=0); nrm=np.stack([-d[:,1],d[:,0]],1)/np.maximum(np.hypot(*d.T),1e-9)[:,None]
    on=np.flatnonzero((rib.along>=rib.start)&(rib.along<=rib.end)&(ch["half"]>0.5))
    for side in (-1.,1.):
        p=r.coords[on]+nrm[on]*(side*(ch["half"][on]+ch["lip"][on]))[:,None]
        h=c.ground(p[:,0],p[:,1],w.terrain.height(p[:,0],p[:,1]))
        o=h-r.surface[on]
        for i in np.flatnonzero(o<0.1):
            past=c.past_bank(p[i:i+1,0],p[i:i+1,1])[0]
            bad.append((r.id,int(on[i]),round(float(o[i]),2),round(float(rib.end-rib.along[on[i]])),round(float(rib.along[on[i]]-rib.start)),r.mouth,r.source,round(float(past),1)))
print(len(bad))
byr=collections.Counter(b[0] for b in bad)
print(byr.most_common(12))
print('worst',sorted(bad,key=lambda b:b[2])[:12])
print('near end <60m',sum(b[3]<60 for b in bad),'near start<60',sum(b[4]<60 for b in bad))
print("rest",[b for b in sorted(bad,key=lambda b:b[2]) if b[7]>-0.3][:24])
