"""Experiment: towns and villages on their own streams: how much of the capital's plan changes? (no repo change)"""
import sys, json, time, types
sys.path.insert(0, ".")
import numpy as np
import citygen.world as W
from citygen.config import load_config
from citygen.rng import stream

src = open("citygen/world.py", encoding="utf-8").read()
new = src.replace('''        score = base + rng.uniform(0.0, 0.1 if kind == "capital" else 0.7, size=H.shape)''',
'''        if kind in ("town", "village"):
            rng = stream(seed, "settlements", kind)
        score = base + rng.uniform(0.0, 0.1 if kind == "capital" else 0.7, size=H.shape)''')
assert new != src
M = types.ModuleType("citygen.world_exp"); M.__package__ = "citygen"
sys.modules["citygen.world_exp"] = M
exec(compile(new, "world_exp", "exec"), M.__dict__)
from citygen.city import plan_city

def fp(plan):
    return dict(
        streets={(s.kind, round(s.width, 2), tuple(np.round(np.asarray(s.line.coords), 2).ravel())) for s in plan.streets},
        buildings={(b.kind, b.floors, round(b.footprint.area, 2), tuple(np.round(b.footprint.exterior.coords[0], 2))) for b in plan.buildings},
        districts={(d.kind, round(d.polygon.area, 1)) for d in plan.districts},
        marks={(m.kind, str(m.name), round(m.x, 1), round(m.y, 1)) for m in plan.landmarks})

for quick in (True, False):
    cfg = load_config(quick=quick)
    a, b = W.generate_world(cfg), M.generate_world(cfg)
    t = time.time()
    pa, pb = plan_city(a, a.capital()), plan_city(b, b.capital())
    fa, fb = fp(pa), fp(pb)
    print("quick" if quick else "64km", "capital", a.capital().name, "planned in", round(time.time() - t, 1), "s")
    for k in fa:
        print(f"  {k}: before {len(fa[k])} after {len(fb[k])} common {len(fa[k] & fb[k])}")
    h = lambda p: {k: sum(1 for x in p.buildings if x.kind == k) for k in ("house", "domed", "apartments", "villa")}
    print("  by kind before", h(pa), "after", h(pb))
