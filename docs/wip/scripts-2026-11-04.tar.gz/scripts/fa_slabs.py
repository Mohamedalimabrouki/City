import sys; sys.path.insert(0,'.')
import numpy as np
from citygen.interior.context import city_plan, load_build
ctx=load_build('output/bodjantouna-42',log=lambda m:None); plan=city_plan(ctx,None)
d=ctx.dresser(plan)
import json
idx=json.load(open('output/bodjantouna-42/tiles/index.json'))
n=0
for k,b in enumerate(plan.buildings):
    if d._is_slab(b):
        c=b.footprint.centroid
        if n<8 and k%17==0:
            n+=1
            w=d.walls(b,k); i=np.argmin(np.where(w.open&(w.street<0),w.length,1e9)); m=(w.a[i]+w.b[i])/2
            print(k,round(c.x),round(c.y),b.floors,'gable',round(w.length[i],1),m.round(1),w.n[i].round(2), round(float(ctx.ground.surface(m[0],m[1])),1))
