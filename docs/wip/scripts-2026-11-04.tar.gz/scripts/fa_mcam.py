import sys,json; sys.path.insert(0,'.')
import collections, numpy as np
from citygen.interior.context import city_plan, load_build
from citygen.interior.outside import Outside
folder='output/megine/bodjantouna-42'
ctx=load_build(folder,log=lambda m:None); plan=city_plan(ctx,'Megine')
idx=json.load(open(folder+'/tiles/index.json'))
print(len(idx['tiles']), idx['focus'], sum(1 for t in idx['tiles']))
d=ctx.dresser(plan)
full=[(t['x0'],t['y0'],t['x0']+idx['tile_size'],t['y0']+idx['tile_size']) for t in idx['tiles'] if t['pieces']>0]
res=[]
for k,b in enumerate(plan.buildings):
    if plan.districts[b.district].kind!='colonial' or b.kind not in('house','apartments') : continue
    c=b.footprint.centroid
    if not any(x0<c.x<x1 and y0<c.y<y1 for x0,y0,x1,y1 in full): continue
    home=d.homes.get(k)
    res.append((home.door if home else '',k,round(c.x),round(c.y),int(b.floors),round(b.footprint.area)))
print(len(res)); 
yel=[r for r in res if r[0]=='door_yellow' and r[5]>600][:6]; print(yel); print(res[:4])
