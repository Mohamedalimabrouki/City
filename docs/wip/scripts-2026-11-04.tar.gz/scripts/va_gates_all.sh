#!/bin/zsh
# Worlds and plans on 3 seeds at both sizes.
PY=/Users/mohamedalimabrouki/Desktop/City/.venv/bin/python
SP=/private/tmp/claude-501/-Users-mohamedalimabrouki-Desktop/3a588b2b-bf2f-4191-acd4-5b1ae750c3f3/scratchpad
cd /tmp/claude-501/va_tree4
for size in quick full; do for seed in 42 7 3; do
  echo "=== world $seed $size"; $PY $SP/va_gates.py $seed $size 2>&1 | tail -1
done; done
for size in quick full; do for seed in 42 7 3; do
  echo "=== plans $seed $size"; $PY $SP/va_plans.py $seed $size 5 2>&1 | grep -v "RuntimeWarning\|return lib" | tail -8
done; done
echo "=== done"
