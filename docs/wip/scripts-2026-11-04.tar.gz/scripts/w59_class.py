import sys, math
sys.path.insert(0, sys.argv[1])
import numpy as np
from scipy import ndimage
from collections import defaultdict, Counter
from citygen.config import load_config
from citygen.terrain import Terrain, classify, STEPPE, DESERT
from citygen import hydro
cfg = load_config(quick=False); ter = Terrain(42, cfg); rc = cfg["rivers"]
g = hydro._routing(ter, rc)
n=g.n; c=g.c; X,Y=np.meshgrid(c,c); H=ter.height(X,Y); M=ter.moisture(X,Y,H); sea=H<=0
filled0,recv0=hydro._flood(H,sea)
depth0=np.where(sea,0.,filled0-H)
labels,count=ndimage.label(depth0>0.01,np.ones((3,3),bool))
cells=np.bincount(labels.ravel(),minlength=count+1)
cell=c[1]-c[0]; min_cells=float(rc["lake_min_area"])*1e6/(cell*cell)
ids=np.arange(1,count+1)
deep=np.zeros(count+1); deep[1:]=ndimage.maximum(depth0,labels,ids)
# which labels hold a lake, and is it salt
lake_of=np.full(count+1,-1); 
for i in np.flatnonzero(g.lake_id>=0): lake_of[labels.ravel()[i]]=g.lake_id[i]
lakes=g.lakes
def kind(l):
    if l==0: return "none"
    if lake_of[l]>=0: return "salt basin pocket" if lakes[lake_of[l]].salt else "fresh lake"
    if deep[l]>=float(rc["lake_min_depth"]) and cells[l]>=min_cells: return "wet hollow drained"
    if cells[l]<min_cells: return "small pit"
    return "shallow"
# walk every river cell (flow >= min_flow, not lake): what does it cross
river=(~g.sea)&(g.lake_id<0)&(g.flow>=float(rc["min_flow"]))
L=labels.ravel(); D=depth0.ravel(); 
rows=defaultdict(lambda:[0,0.0,set()])
flatdepth=g.flat-H.ravel()
for i in np.flatnonzero(river):
    l=L[i]; k=kind(l)
    if flatdepth[i]>0.01:
        rows[k][0]+=1; rows[k][1]=max(rows[k][1],flatdepth[i]); rows[k][2].add(l)
for k,v in rows.items(): print(k,"river cells over filled ground",v[0],"max bed above ground (grid)",round(v[1],1),"distinct basins",len(v[2]))
# river cells deeper than various thresholds by kind
for th in (1,3,5,10,20):
    print("flat-ground >",th, Counter(kind(L[i]) for i in np.flatnonzero(river&(flatdepth>th))))
sz=[(int(cells[l]),round(float(deep[l]),1)) for l in sorted(rows["small pit"][2])]
print("small pits crossed (cells, depth) by depth:", sorted(sz,key=lambda a:-a[1])[:30])
sz=[(int(cells[l]),round(float(deep[l]),1)) for l in sorted(rows["wet hollow drained"][2])]
print("wet hollows crossed:", sorted(sz,key=lambda a:-a[1]))
sz=[(int(cells[l]),round(float(deep[l]),1)) for l in sorted(rows["salt basin pocket"][2])]
print("salt basins crossed:", sorted(sz,key=lambda a:-a[1]))
