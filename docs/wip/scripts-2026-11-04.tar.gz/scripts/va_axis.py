"""Why a capital far from its river is dealt anew: the inputs of the old town, printed. Run from a tree, quick world, seed 42."""
import sys

sys.path.insert(0, '.')
from shapely.geometry import LineString

from citygen.city import CityContext
from citygen.city import layout as L
from citygen.city import __dict__ as cd
from citygen.config import load_config
from citygen.world import generate_world

w = generate_world(load_config(quick=True))
s = next(s for s in w.settlements if s.kind == 'capital')
ctx = CityContext(w, s)
land = cd['land_near'](w.terrain, s.x, s.y, s.radius * 1.35)
print('land area', round(land.area, 1))
boundary = cd['city_boundary'](ctx, land)
print('boundary area', round(boundary.area, 1))
roads = [r for r in w.roads if LineString(r.coords).intersects(boundary)]
print('roads through the boundary', len(roads), [(getattr(r, 'kind', '?'), round(LineString(r.coords).intersection(boundary).length)) for r in roads])
axis = cd['main_axis'](ctx, roads)
print('axis', round(float(axis), 6))
for name in ('rivers',):
    print('rivers near', [r.id for r in w.rivers if LineString(r.coords).distance(boundary) < 200])
