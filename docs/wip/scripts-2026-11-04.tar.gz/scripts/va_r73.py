import sys, numpy as np
sys.path.insert(0,'.')
from citygen.config import load_config
from citygen.world import generate_world
w=generate_world(load_config(overrides={"world":{"seed":42}}))
r=[r for r in w.rivers if r.id==int(sys.argv[1])][0]
k=np.flatnonzero((r.coords[:,0]>int(sys.argv[2]))&(r.coords[:,0]<int(sys.argv[3]))&(r.coords[:,1]>int(sys.argv[4]))&(r.coords[:,1]<int(sys.argv[5])))
for i in k[::20]: print(i,[int(v) for v in r.coords[i]],round(float(r.surface[i]),2),round(float(r.width[i]),1) if hasattr(r,'width') else '')
