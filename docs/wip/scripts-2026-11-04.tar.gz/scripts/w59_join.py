import sys, math, time
sys.path.insert(0, sys.argv[1])
import numpy as np
from shapely.geometry import LineString, Point
from citygen.config import load_config
from citygen.terrain import Terrain
from citygen import hydro
for quick in (True, False):
    cfg = load_config(quick=quick); ter = Terrain(42, cfg)
    t=time.perf_counter(); rivers, lakes = hydro.drainage(ter, cfg); t=time.perf_counter()-t
    rc = cfg["rivers"]
    g = hydro._routing(ter, rc)
    n=g.n; has = g.recv>=0
    i=np.flatnonzero(has); bad=np.count_nonzero(g.flat[i] <= g.flat[g.recv[i]])
    print("quick" if quick else "full", round(t,2),"s; order violations", bad, "of", len(i), "rivers", len(rivers), "lakes", len(lakes), "salt", sum(k.salt for k in lakes))
    gaps=[]; 
    for r in rivers:
        if r.mouth=="river":
            m=rivers[r.into]; line=LineString(m.coords); s=line.project(Point(r.coords[-1]))
            seg=np.concatenate([[0.],np.cumsum(np.hypot(*np.diff(m.coords,axis=0).T))]); zm=float(np.interp(s,seg,m.profile))
            gaps.append(zm-r.profile[-1])
    gaps=np.array(gaps); print("tributaries", len(gaps), "ending under main bed:", int((gaps>1e-6).sum()), "worst", round(float(gaps.max()) if len(gaps) else 0,2), "ending above:", int((gaps<-1e-6).sum()), round(float(-gaps.min()) if len(gaps) else 0,2))
    # points above the ground, outside lakes
    worst=[]
    for r in rivers:
        gr=ter.height(r.coords[:,0],r.coords[:,1]); cell=g.c[1]-g.c[0]
        a,b=np.clip(np.floor(r.coords/cell).astype(int),0,n-1).T; over=g.lake_id[b*n+a]>=0
        d=(r.profile-gr)
        worst.append((float(d[~over].max()) if (~over).any() else -9, r.id, r.mouth, float(d[over].max()) if over.any() else -9))
    worst.sort(reverse=True); print("above ground off lakes:", [(round(a,2),b,c,round(e,2)) for a,b,c,e in worst[:5]])
    print("total river km", round(sum(np.hypot(*np.diff(r.coords,axis=0).T).sum() for r in rivers)/1000,1))
    lk=[(hydro.Polygon(k.polygon).area/1e6) for k in lakes if k.salt]; print("salt areas km2 min/med/max", round(min(lk),2), round(float(np.median(lk)),2), round(max(lk),2), " under .5:", sum(a<.5 for a in lk))
    lk=[(hydro.Polygon(k.polygon).area/1e6) for k in lakes if not k.salt]
    if lk: print("fresh areas min/med/max", round(min(lk),2), round(float(np.median(lk)),2), round(max(lk),2))
    # lake cells per lake
    cnt=np.bincount(g.lake_id[g.lake_id>=0]); print("cells per lake min", cnt.min(), "km2", round(cnt.min()*(cell**2)/1e6,2))
