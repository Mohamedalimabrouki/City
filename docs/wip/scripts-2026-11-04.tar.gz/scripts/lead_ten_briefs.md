# Ten more helpers (lead, 3 November, about 20:50 UTC): finish and push by 20:59 UTC
Common: work only in your folder /tmp/claude-501/<name> (`cd` there first; it is a detached worktree already on the right commit). Python `/Users/mohamedalimabrouki/Desktop/City/.venv/bin/python`. Never the em dash character. Do not touch WORKLOG, ROADMAP, HANDOFF or SPEC. Commit in your folder (message `WIP <name>`, last line `Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>`) and `git push origin HEAD:refs/heads/wip/<name>`; if the sandbox blocks the push, run it again with github.com in the Bash call's allowed_domains. Push a first commit by 20:55 UTC if you have anything, then improve and push again. Stop at 20:59 UTC (check `date -u`) even if a part is left, and say in `docs/wip/<name>.md` what is left. Never change the world's output unless your section says so. Report in one line.

## fix-hide (from wip/shot-hide)
Fix what `docs/wip/shot-hide.md` lists in the kit-hide pieces: hidoura needs visible tufts and a soft dome (no straight flat edges) and a fleece colour that reads as wool, not sand; net_pile needs one UV projection across the whole pile, so the net does not stretch or turn at each crease. Keep the piece names; `pytest -q -k "kit or home or furn"` must pass. Render the new sheet with the scratchpad's `hg_render.py` (as shot-hide did) into `docs/wip/fix-hide.png` and write two honest lines in `docs/wip/fix-hide.md`.

## fix-textile (from wip/shot-textile)
Fix what `docs/wip/shot-textile.md` lists: the ticking mattress top needs correct UVs so its stripes show; the cushion piping must be a thin round cord, not a wide flat gold frame; the cushion face needs smooth domed normals. Same tests, render and notes as fix-hide (`docs/wip/fix-textile.png` and `.md`).

## fix-brass (from wip/shot-brass)
Fix what `docs/wip/shot-brass.md` lists: tray_brass's rim is too steep for a one-sided material (give it an outer skin, or go back to about 0.03 m in); the pots_stack bowl hollow at 6 sides reads as a pointed lid (more sides or a rounded inside). Same tests, render and notes as fix-hide (`docs/wip/fix-brass.png` and `.md`).

## shot-goods (from wip/kit-goods)
Render a z-buffer contact sheet of the pieces kit-goods changed (see `docs/wip/kit-goods.md`) and of the same pieces at e871984 side by side, with the scratchpad's `hg_render.py`, into `docs/wip/shot-goods.png`; look at it and write two honest lines (better, worse, what to fix) into `docs/wip/shot-goods.md`. Change no code.

## fix-81b (from wip/fix-81)
Apply the review-81 findings that fix-81 left (1, 2, 5-7, 9-12; see `/tmp/claude-501/review-81/docs/wip/review-81.md` and `docs/wip/fix-81.md`). History wording may change; nothing else. Skip any finding that needs Ali's answer and list it. Run `pytest -q -k "histor or lore"` and read a few of the capital's histories. Notes in `docs/wip/fix-81b.md`.

## fix-87 (from wip/review-87)
Fix the six Low findings in `docs/wip/review-87.md` (fixed_name default template, _twins list-length check, reject a negative canon id, the gazetteer's Arabic column, the pinned-settlement test also checking its plan's landmarks). The output must stay byte-identical (compare the quick build's names and lore files before and after); a fix that would change output is not done, only noted. `pytest -q -k "name or lore or canon"`. Notes in `docs/wip/fix-87.md`.

## fix-59 (from wip/review-59)
From `docs/wip/review-59.md` do only what keeps the output byte-identical: make `_snap`'s comment match what it does (hydro.py:327), make the never-rising-profile test able to fail, and add tests for fresh lakes, lake outlets and multi-pocket salt basins (the quick world, or a small synthetic case). Do not change the water-balance rule (Ali decides) or the salt-pocket drawing: write both as open questions with a one-line suggested fix. `pytest -q -k "river or hydro or lake"`. Notes in `docs/wip/fix-59.md`.

## check-70 (from wip/fix-70)
Check fix-70 for merging: run the full `pytest -q` (not slow) and the quick build; check that streets.json and the other outputs are byte-identical to the same build of the commit before fix-70 (`git log --oneline -3`; make a second worktree at /tmp/claude-501/check-70-base); say whether the new `[streets]` config section makes the build redo its cached data files and whether that matters. Change no code unless a test fails. Notes in `docs/wip/check-70.md`.

## merge-map (from main)
Make the merge map for the next session. `git fetch origin 'refs/heads/wip/*:refs/remotes/origin/wip/*'` (github.com in allowed_domains), then for every origin/wip/* branch: its merge base with main, the files it touches, and `git merge-tree --write-tree --name-only main origin/wip/<b>` (clean, or the conflicting files); then the same pairwise for the branches that change code. Write `docs/wip/merge-map.md`: one table (branch, based on, files touched, conflicts with main, conflicts with others) and a suggested merge order. Change no code.

## canon-60 (from wip/rivers-60)
Read-only study for prompt 60: on the 64 km world 127 of 131 settlements move and their names shift (`docs/wip/rivers-60.md`). Find why the names shift (which random stream and which order gives the names), which names are canon (pinned in world.py, styles, docs, tests, the lore), and write a short plan in `docs/wip/canon-60.md` to keep every canon name and the names of settlements that did not really move: the exact code change (file:line) and a test that would catch the shift. If the change is small and safe, also make it with that test and say so.
