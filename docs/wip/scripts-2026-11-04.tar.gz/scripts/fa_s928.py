import sys; sys.path.insert(0,'.')
from citygen.interior.context import city_plan, load_build
from citygen.interior.layout import plan_interior
from citygen.interior.outside import Outside
from citygen.interior import stairs as S
ctx=load_build('output/bodjantouna-42',log=lambda m:None); plan=city_plan(ctx,None); st=ctx.world.style['interiors']['stairs']
it=plan_interior(Outside(ctx,plan,928),ctx.world.style)
print(it.layout,it.high,it.fh,it.floors)
for s in it.stairs:
    if s.kind=='steps':
        print(s.kind,s.door,s.floor,s.top,getattr(s,'sunk',None),getattr(s,'turn',None),s.polygon.bounds)
        for r in S.treads(s,it,st): print(' run',r.z_from,r.z_to,len(r.pts),r.pts[:3].round(2).tolist(),r.pts[-1].round(2).tolist())
