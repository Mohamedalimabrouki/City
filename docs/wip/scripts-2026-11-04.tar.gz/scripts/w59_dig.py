import sys, math
sys.path.insert(0, sys.argv[1])
import numpy as np
from citygen.config import load_config
from citygen.terrain import Terrain
from citygen.hydro import drainage
for quick in (True, False):
    cfg = load_config(quick=quick); ter = Terrain(42, cfg)
    rivers, lakes = drainage(ter, cfg)
    print("quick" if quick else "full", "rivers", len(rivers), "lakes", len(lakes), "salt", sum(k.salt for k in lakes))
    rows=[]
    for r in rivers:
        g = ter.height(r.coords[:,0], r.coords[:,1]); d = g - r.profile
        s = np.concatenate([[0],np.cumsum(np.hypot(*np.diff(r.coords,axis=0).T))])
        ds = np.gradient(s) if len(s)>1 else np.ones(len(s))
        rows.append((float(d.max()), float(-d.min()), r.id, r.mouth, round(float(r.flow),1), round(float(s[-1])/1000,1), round(float(ds[d>5].sum())/1000,2), round(float(ds[d>10].sum())/1000,2), round(float(ds[d>20].sum())/1000,2), round(float(ds[d>40].sum())/1000,2)))
    rows.sort(reverse=True)
    print("dig worst (m under ground, above ground, id, mouth, flow, km long, km deeper than 5/10/20/40):")
    for x in rows[:14]: print("  ", round(x[0],1), round(x[1],1), *x[2:])
    print("rivers digging >5:", sum(x[0]>5 for x in rows), ">10:", sum(x[0]>10 for x in rows), ">20:", sum(x[0]>20 for x in rows), ">40:", sum(x[0]>40 for x in rows), " total km >10:", round(sum(x[7] for x in rows),1), " >20:", round(sum(x[8] for x in rows),1), "max above ground", round(max(x[1] for x in rows),1))
