import sys; sys.path.insert(0,'.')
import collections
from citygen.interior.context import city_plan, load_build
ctx=load_build('output/bodjantouna-42',log=lambda m:None); plan=city_plan(ctx,None)
c=collections.Counter()
for b in plan.buildings:
    if b.kind=='apartments': c[(plan.districts[b.district].kind,round(b.height/max(1,b.floors),2))]+=1
print(sorted(c.items()))
