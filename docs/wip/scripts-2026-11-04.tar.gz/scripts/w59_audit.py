"""Water audit after the rounds: lead_water.py and lead_water2.py's measures, per seed and size. Run from a checkout."""
import sys, time, collections
sys.path.insert(0, ".")
import numpy as np, shapely
from scipy import ndimage
from shapely.geometry import LineString, Point, Polygon
from shapely.ops import unary_union
import citygen.hydro as hy
from citygen.config import load_config
from citygen.terrain import classify, STEPPE, DESERT, BIOME_NAMES
from citygen.world import generate_world

def seglen(xy): return np.hypot(*np.diff(xy, axis=0).T)

def audit(quick, seed, verbose=True):
    cfg = load_config(quick=quick, overrides={"world": {"seed": seed}})
    t0 = time.perf_counter(); w = generate_world(cfg); t_world = time.perf_counter() - t0
    t = w.terrain; rc = cfg["rivers"]
    g = hy._routing(t, rc)
    n, c = g.n, g.c; step = c[1] - c[0]
    X, Y = np.meshgrid(c, c); H = t.height(X, Y)
    lakes = {k.id: k for k in w.lakes}
    polys = {k.id: Polygon(k.polygon).buffer(0) for k in w.lakes}
    depth = (g.flat - H.ravel()).reshape(n, n)
    depth[(g.lake_id.reshape(n, n) >= 0) | (H <= 0)] = 0.0
    labels, count = ndimage.label(depth > float(rc["basin_depth"]), np.ones((3, 3), bool))
    sizes = np.bincount(labels.ravel(), minlength=count + 1)
    maxd = ndimage.maximum(depth, labels, np.arange(count + 1)) if count else np.zeros(1)
    # top-level basins, to tell a pit in the open from a pocket of a closed basin
    sea = H <= 0
    filled, _ = hy._flood(H, sea)
    top, _c = ndimage.label(np.where(sea, 0.0, filled - H) > float(rc["basin_depth"]), np.ones((3, 3), bool))
    closed = set(top[(g.salt.reshape(n, n))].tolist()) - {0}
    total = deep10 = deep20 = 0.0; worst = 0.0; rises = 0
    stretches = []; dry_km = 0.0; dry_gap = 0.0; dry_rows = []
    for r in w.rivers:
        xy, z = r.coords, r.profile
        gr = t.height(xy[:, 0], xy[:, 1]); L = seglen(xy); d = gr - z
        mid = (d[:-1] + d[1:]) / 2
        total += L.sum(); deep10 += L[mid > 10].sum(); deep20 += L[mid > 20].sum(); worst = max(worst, d.max())
        rises += bool((np.diff(z) > 1e-9).any())
        # follow the river down to the lake it reaches, through its main rivers
        cur = r; at_end = None
        seen = 0
        while cur.mouth == "river" and cur.into is not None and seen < 50:
            cur = w.rivers[cur.into]; seen += 1
        if cur.mouth in ("lake", "basin"):
            k = lakes[cur.into]
            dry = (z < k.level) & (gr > k.level)
            km = L[dry[:-1] & dry[1:]].sum() / 1000
            gap = float((k.level - z)[dry].max()) if dry.any() else 0.0
            dry_km += km
            if km > 0 or gap > 0:
                dry_rows.append((round(gap, 1), round(float(km), 2), r.id, r.mouth, cur.mouth, cur.into))
        i, j = np.clip(np.floor(xy / step).astype(int), 0, n - 1).T
        k = 0
        while k < len(mid):
            if mid[k] > 10:
                e = k
                while e + 1 < len(mid) and mid[e + 1] > 10:
                    e += 1
                b = k
                while b > 0 and z[b - 1] <= z[k] + 1e-6:
                    b -= 1
                l = labels[j[b], i[b]]
                where = ("a pocket of a closed basin" if top[j[b], i[b]] in closed else "a pit in the open") if l else "no pit (a tributary's bed or the line)"
                stretches.append((float(L[k:e + 1].sum()), float(mid[k:e + 1].max()), r.id, where, int(sizes[l]) if l else 0, round(float(maxd[l]), 1) if l else 0.0, r.mouth, round(r.flow, 1)))
                k = e + 1
            else:
                k += 1
    wet = unary_union(list(polys.values())) if polys else None
    touch = [s.name for s in w.settlements if wet is not None and Point(s.x, s.y).buffer(s.radius).intersects(wet)]
    roads = sum(LineString(r.coords).intersects(wet) for r in w.roads) if wet is not None else 0
    i = np.flatnonzero(g.recv >= 0); bad = int(np.count_nonzero(g.flat[i] <= g.flat[g.recv[i]]))
    ends = sum(r.mouth in ("lake", "basin") and not polys[r.into].buffer(step).contains(Point(r.coords[-1])) for r in w.rivers)
    # inflow against size of the salt lakes
    cells = np.bincount(g.lake_id[g.lake_id >= 0], minlength=len(w.lakes))
    over = []
    for k in w.lakes:
        if k.salt:
            inflow = g.flow[g.lake_id == k.id].sum()
            need = max(int(np.ceil(float(rc["lake_area_per_flow"]) * inflow * 1e6 / (step * step))), int(np.ceil(float(rc["lake_min_area"]) * 1e6 / (step * step))))
            if cells[k.id] > need * 1.2 and cells[k.id] > 40:
                over.append((k.id, int(cells[k.id]), need))
    salt_a = sorted(polys[k.id].area / 1e6 for k in w.lakes if k.salt)
    fresh_a = sorted(polys[k.id].area / 1e6 for k in w.lakes if not k.salt)
    print(f"{'quick' if quick else '64km'} seed {seed}: country step {t_world:.2f} s; {len(w.rivers)} rivers {total/1000:.0f} km; lakes {len(fresh_a)} fresh, {len(salt_a)} salt; "
          f"salt km2 median {np.median(salt_a) if salt_a else 0:.2f} total {sum(salt_a):.0f}; fresh total {sum(fresh_a):.0f}")
    print(f"   under the ground: over 10 m {deep10/1000:.1f} km, over 20 m {deep20/1000:.1f} km, worst {worst:.1f} m; rising {rises}; order faults {bad}; ends off shore {ends}")
    print(f"   bed under its lake's level with ground above it: {dry_km:.2f} km, worst {max([x[0] for x in dry_rows], default=0)} m; rows {sorted(dry_rows, reverse=True)[:5]}")
    print(f"   towns touching a lake {len(touch)}: {touch[:6]}...; roads crossing a lake {roads} of {len(w.roads)}")
    print(f"   salt lakes over 20% bigger than their true inflow says: {len(over)} {sorted(over, key=lambda a: -a[1])[:6]}")
    by = collections.Counter(); km = collections.Counter()
    for s in stretches:
        by[s[3]] += 1; km[s[3]] += s[0] / 1000
    print(f"   stretches over 10 m: {len(stretches)}; by cause {[(k, by[k], round(km[k], 2)) for k in by]}")
    for s in sorted(stretches, key=lambda s: -s[1]):
        if verbose:
            print(f"      river {s[2]} (flow {s[7]}, mouth {s[6]}): {s[0]/1000:.2f} km, up to {s[1]:.1f} m: low point in {s[3]} ({s[4]} cells, {s[5]} m deep)")
    return w

seeds = [int(a) for a in sys.argv[1:]] or [42, 7, 3]
for quick in (False, True):
    for seed in seeds:
        audit(quick, seed)
