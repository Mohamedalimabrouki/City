# Fast helper briefs (lead, 3 November): each about 6 minutes, push by the time the lead gives
Common: work only in your folder (`cd` there first); python `/Users/mohamedalimabrouki/Desktop/City/.venv/bin/python`; rules of CLAUDE.md (own streams, numbers in the style, never the em dash character); when done, add one line to `docs/wip/<name>.md`, commit on your branch (message `WIP <name>`, last line `Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>`) and `git push origin HEAD:refs/heads/wip/<name>`. Report in one line.
## fix-70 (folder /tmp/claude-501/fix-70)
Apply the two Medium findings of `docs/wip/review-70.md`: a slow test that writes streets.json in two processes with PYTHONHASHSEED 1 and 2 and compares the bytes; move `GRID = 0.05` (citygen/export/streets.py:16) into citygen/defaults.toml. Run the new test and `pytest -q -k street`.
## fix-94 (folder /tmp/claude-501/fix-94)
Apply the must-fix of `docs/wip/review-94.md`: remove the live empty `[styles]` tables in worlds/example.toml (lines 25, 28), keep them as comments; then `pytest -q tests/test_styles.py`.
## fix-81 (folder /tmp/claude-501/fix-81)
Apply `docs/wip/review-81.md`'s grammar finding ("One gates/shrines": singular forms) and its wording one ("in the time of the Caravan Age"); then `pytest -q -k histor`.
## check-k (folder /tmp/claude-501/check-k)
Verify `wip/colonial-k`'s claim that no slab plan changed: run round G's parallel survey `hm_dump.py` (session scratchpad) for slab only on this tree and on a HEAD copy of c48fb1e, compare rooms.json hashes, and write the counts into `docs/wip/check-k.md`. Change no code.
