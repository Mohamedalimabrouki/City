import sys
sys.path.insert(0, "."); sys.path.insert(0, "tests")
import numpy as np
from scipy import ndimage
from citygen.config import load_config
from citygen import hydro
import test_hydro as th
for name, cfg in (("normal", load_config(quick=True)), ("little", th._little_water())):
    rc = cfg["rivers"]
    for at in (14400, 14600, 14700, 14800, 15000, 15200, 15400):
        for ridge in (20, 25, 30, 35, 40, 45, 50):
            land = th._Valley(0.02, ridge=float(ridge), at=float(at))
            g = hydro._routing(land, rc)
            X, Y = np.meshgrid(g.c, g.c); H = land.height(X, Y)
            filled, _ = hydro._flood(H, H <= 0)
            top = ndimage.label(filled - H > 0.01, np.ones((3, 3), bool))[1]
            rivers, lakes = hydro.drainage(land, cfg)
            n = len(lakes)
            if top == 1 and n == 2:
                c = np.bincount(g.lake_id[g.lake_id >= 0]).tolist()
                print(name, "at", at, "ridge", ridge, "top basins", top, "lakes", n, "levels", [round(k.level, 1) for k in lakes], "cells", c, "salt", [k.salt for k in lakes], "rivers", [(r.mouth, r.into, round(r.flow, 1)) for r in rivers])
