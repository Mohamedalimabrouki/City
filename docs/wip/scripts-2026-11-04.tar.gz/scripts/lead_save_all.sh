#!/bin/bash
# Lead: save every helper worktree of 3 November as a WIP commit with its notes, and push the branch.
S=/private/tmp/claude-501/-Users-mohamedalimabrouki-Desktop/3a588b2b-bf2f-4191-acd4-5b1ae750c3f3/scratchpad
EM="$(printf '\342\200\224')"
while read -r name notes; do
  W=/tmp/claude-501/$name
  [ -d "$W" ] || { echo "$name: no worktree"; continue; }
  mkdir -p "$W/docs/wip"
  [ -f "$S/$notes" ] && cp "$S/$notes" "$W/docs/wip/$name.md"
  git -C "$W" add -A
  git -C "$W" reset -q -- output 2>/dev/null
  n=$(git -C "$W" diff --cached | grep -c "$EM")
  if git -C "$W" diff --cached --quiet; then
    echo "$name: nothing new to commit"
  else
    git -C "$W" commit -q -m "WIP $name (saved at the weekly reset, 3 November; notes in docs/wip/$name.md)

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
    echo "$name: committed $(git -C "$W" rev-parse --short HEAD) (em dashes in diff: $n)"
  fi
  git -C "$W" push -q origin "HEAD:refs/heads/wip/$name" 2>&1 | grep -v -E 'could not write config|remote:|^$'
done <<'EOF'
houses-patio hr_notes.md
flats-j hs_notes.md
colonial-k ht_notes.md
furnish-m hu_notes.md
speed-n hv_notes.md
villas-o hy_notes.md
lore-81 hz_notes.md
godot-72 ia_notes.md
styles-94 id_notes.md
arabic-87 hx_notes.md
rivers-59 hw_notes.md
graph-70 ib_notes.md
EOF
echo "remote wip branches:"; git -C /Users/mohamedalimabrouki/Desktop/City ls-remote origin 'refs/heads/wip/*' | awk '{print substr($1,1,7), $2}'
