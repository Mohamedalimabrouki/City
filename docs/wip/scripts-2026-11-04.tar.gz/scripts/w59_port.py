"""Apply the hydro changes to a hydro.py taken from wip/fix-59 (same edits go to the worktree after the merge)."""
import sys
p = sys.argv[1]
s = open(p).read()
def sub(a, b, n=1):
    global s
    assert s.count(a) >= 1 and (n == 0 or s.count(a) == n), (s.count(a), a)
    s = s.replace(a, b)

sub('''A pure function of the terrain, no randomness. On a coarse grid (`[rivers] cell`) a
priority flood (Barnes et al. 2014, with an epsilon gradient) runs inward from the sea and
the map border: each land cell drains to the cell the flood reached it from, so every cell
drains, even on filled flats. Filled basins deep and wide enough are lakes; in steppe and
desert they are endorheic (salt) basins where rivers end. Flow is the catchment area weighted
by moisture; rivers follow the cells where it passes `[rivers] min_flow`.
"""''', '''A pure function of the terrain, no randomness. On a coarse grid (`[rivers] cell`) a
priority flood (Barnes et al. 2014, with an epsilon gradient) runs inward from the sea and
the map border: each land cell drains to the cell the flood reached it from, so every cell
drains, even on filled flats. Filled basins deep and wide enough are lakes; in steppe and
desert they are always closed (salt) basins where rivers end. Flow is the catchment area
weighted by moisture; rivers follow the cells where it passes `[rivers] min_flow`.
"""''')

# 1. the routing apart from the river lines, so a test can read it
sub('''def drainage(terrain, cfg: dict) -> tuple:
    """(rivers, lakes) of the whole country."""
    rc = cfg["rivers"]
    size = terrain.size
''', '''@dataclass
class _Routing:
    """Where the water of each grid cell goes (cells numbered row by row, `n` to a side)."""
    n: int
    c: np.ndarray        # (n,) the cell centers' x (and y), meters
    sea: np.ndarray      # (n * n,) bool
    flat: np.ndarray     # (n * n,) heights that strictly fall from each cell to `recv` (the flood's, lakes at rest)
    recv: np.ndarray     # (n * n,) the cell each cell drains to, -1 for the sea, a salt lake and the map border
    flow: np.ndarray     # (n * n,) rain-weighted catchment, km2
    catch: np.ndarray    # (n * n,) plain catchment, km2
    lake_id: np.ndarray  # (n * n,) the lake on each cell, -1 for none
    salt: np.ndarray     # (n * n,) bool: a salt lake's cell
    lakes: list


def drainage(terrain, cfg: dict) -> tuple:
    """(rivers, lakes) of the whole country."""
    rc = cfg["rivers"]
    g = _routing(terrain, rc)
    river = (~g.sea) & (g.lake_id < 0) & (g.flow >= float(rc["min_flow"]))
    return _rivers(_chains(g.recv, g.flow, river, g.lake_id, g.n), g, terrain, rc), g.lakes


def _routing(terrain, rc: dict) -> _Routing:
    """The drainage of the grid: the flood, then the lakes, then the flow with the lakes in place."""
    size = terrain.size
''')
sub('''    for k, (lab, level, is_salt) in enumerate(basins):
        sy, sx = boxes[lab - 1]
        m, h, g = labels[sy, sx] == lab, H[sy, sx], gid[sy, sx]
        water = m & (h <= level)
        if is_salt:                     # endorheic: the basin drains to its lake, which keeps the water
''', '''    for k, (lab, wet, is_salt) in enumerate(basins):
        sy, sx = boxes[lab - 1]
        m, h, g = labels[sy, sx] == lab, H[sy, sx], gid[sy, sx]
        water, level = _water(h, m, wet, float(filled[sy, sx][m].max()))
        if is_salt:                     # endorheic: the whole basin drains to its lake, which keeps the water
''')
sub('''    river = (~sea.ravel()) & (lake_id < 0) & (flow >= float(rc["min_flow"]))
    chains = _chains(recv, flow, river, lake_id, n)
    rivers = _rivers(chains, flat, flow, catch, sea.ravel(), salt, lake_id, c, n, rc)
    return rivers, lakes
''', '''    return _Routing(n, c, sea.ravel(), flat, recv, flow, catch, lake_id, salt, lakes)
''')

# 2. basins: every dry one stays closed
sub('''    """Labels of the filled basins and the lakes among them: [(label, level, salt)].

    A lake spreads until evaporation from its surface (`lake_area_per_flow` km2 per km2 of
    inflow) takes all the water that reaches it: a basin of wet country that fills up spills
    over and its river goes on; in steppe and desert the basin keeps its water (endorheic)."""
    labels, count = ndimage.label(depth > 0.01, np.ones((3, 3), dtype=bool))
''', '''    """Labels of the filled basins and the lakes among them: [(label, cells of water, salt)].

    A lake spreads until evaporation from its surface (`lake_area_per_flow` km2 per km2 of
    inflow) takes all the water that reaches it: a basin of wet country that fills up spills
    over and its river goes on, one that does not fill just drains. In steppe and desert every
    basin keeps its water (endorheic), in a lake of at least `lake_min_area`."""
    labels, count = ndimage.label(depth > float(rc["basin_depth"]), np.ones((3, 3), dtype=bool))
''')
sub('''    deepest = ndimage.maximum(depth, labels, ids)
    spill = ndimage.maximum(filled, labels, ids)
    inflow''', '''    deepest = ndimage.maximum(depth, labels, ids)
    inflow''')
sub('''        if wet < min_cells or (not is_salt and wet < size):
            continue                    # too little water to keep a lake: a damp hollow that drains
        if wet >= size:
            level = float(spill[k])
        else:
            level = float(np.sort(H[labels == ids[k]])[wet - 1])
        out.append((int(ids[k]), level, is_salt))
    return labels, out
''', '''        if is_salt:
            wet = max(wet, math.ceil(min_cells))
        elif wet < size:
            continue                    # too little water to fill it: a damp hollow that drains
        out.append((int(ids[k]), wet, is_salt))
    return labels, out


def _water(h, m, wet: int, spill: float) -> tuple:
    """(cells, level) of a basin's lake (`m` the basin in its box of the grid): the water around the basin's
    bottom, at the lowest level that covers `wet` cells or at the spill. Its cells are 4-connected, so its shore
    is one ring; the hollows of the basin it does not reach stay out, and their water runs on from there."""
    bottom = np.unravel_index(np.argmin(np.where(m, h, np.inf)), h.shape)

    def pocket(level):
        parts, _ = ndimage.label(m & (h <= level))
        return parts == parts[bottom]

    heights = np.sort(h[m])
    if wet >= len(heights):
        return pocket(spill), spill
    lo, hi = wet - 1, len(heights) - 1
    while lo < hi:                      # the lowest level whose pocket covers `wet` cells
        mid = (lo + hi) // 2
        if np.count_nonzero(pocket(heights[mid])) >= wet:
            hi = mid
        else:
            lo = mid + 1
    return pocket(heights[lo]), float(heights[lo])
''')

# 3. the bed
sub('''def _rivers(chains, filled, flow, catch, sea, salt, lake_id, c, n, rc) -> list:
    def own(path, kind):''', '''def _rivers(chains, g: _Routing, terrain, rc: dict) -> list:
    filled, flow, catch, sea, salt, lake_id, c, n = g.flat, g.flow, g.catch, g.sea, g.salt, g.lake_id, g.c, g.n

    def own(path, kind):''')
sub('''    smooth = {r[0]: _smooth(r[1], r[2], r[5]) for r in out}
    rivers = []
    for rid, _, _, fl, seas, _, mouth, into in out:
        xy, w, z = smooth[rid]
''', '''    smooth = {r[0]: _smooth(r[1], r[2], r[5]) for r in out}
    smooth = {rid: (xy, w, _bed(xy, z, g, terrain)) for rid, (xy, w, z) in smooth.items()}
    rivers = []
    for rid, _, _, fl, seas, _, mouth, into in out:
        xy, w, z = smooth[rid]
''')
sub('''def _snap(xy, z, main_xy, main_z) -> tuple:
    """A tributary ends on its main river's smoothed line. Its last height is the main bed there, unless
    the point before is lower: the profile never rises, so then it ends below the main bed."""
''', '''def _bed(xy, z, g: _Routing, terrain) -> np.ndarray:
    """The bed under a smoothed line: the running minimum of the ground, the highest line that never rises
    and never lies above the ground, which a valley can only be cut into, never lifted out of. Where a river
    crosses a hollow it goes down to the hollow's floor and cuts through the rim. Over a lake, `z`."""
    cell = g.c[1] - g.c[0]
    i, j = np.clip(np.floor(xy / cell).astype(np.int64), 0, g.n - 1).T
    return np.minimum.accumulate(np.where(g.lake_id[j * g.n + i] >= 0, z, terrain.height(xy[:, 0], xy[:, 1])))


def _snap(xy, z, main_xy, main_z) -> tuple:
    """A tributary ends on its main river's smoothed line, on the main bed there; if the point before
    already lies lower it stays at that height, as a bed never rises."""
''')
sub('''    z = z.copy()
    z[-1] = max(min(z[-1], z[-2] if len(z) > 1 else z[-1]), zm)
    return xy, np.minimum.accumulate(z)
''', '''    z = z.copy()
    z[-1] = min(zm, z[-2]) if len(z) > 1 else zm
    return xy, z
''')
open(p, "w").write(s)
