import json, sys, collections
import numpy as np
from shapely.geometry import Polygon, shape
a=json.load(open(sys.argv[1])); b=json.load(open(sys.argv[2]))
print('keys',[k for k in a if k in ('districts','buildings','streets','parcels','blocks')], list(a['districts'][0])[:6], list(a['buildings'][0])[:8])
def poly(x):
    p=x.get('polygon') or x.get('footprint')
    return p
for da in a['districts']:
    db=next((d for d in b['districts'] if d['id']==da['id']),None)
    same=json.dumps(poly(da))==json.dumps(poly(db)) if db else None
    print(da['id'],da['kind'],da.get('name'),'->',(db['kind'],db.get('name')) if db else None,'same polygon',same)
print('new districts',[ (d['id'],d['kind'],d.get('name')) for d in b['districts'][len(a['districts']):]])
def key(fp,dec):
    return json.dumps(np.round(np.asarray(fp if not isinstance(fp[0][0],list) else fp[0],dtype=float),dec).tolist())
for dec in (6,3,1,0):
    sb={key(x['footprint'],dec) for x in b['buildings']}
    print('decimals',dec,'kept',sum(key(x['footprint'],dec) in sb for x in a['buildings']),'of',len(a['buildings']))
