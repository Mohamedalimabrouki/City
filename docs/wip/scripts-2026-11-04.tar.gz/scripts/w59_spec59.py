p = "docs/SPEC.md"
s = open(p, encoding="utf-8").read()
def sub(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a)
    s = s.replace(a, b)
sub('''  filled flats. A filled basin (8-connected cells whose filled height is over the ground) is considered
  for a lake only if deeper than `lake_min_depth` (3 m) and larger than `lake_min_area` (0.5 km2); its
  lake surface is `lake_area_per_flow` (0.04) km2 per km2 of rain-weighted inflow: a basin of wet country
  that this fills spills over (a fresh lake at the spill level, its river goes on from the outlet); one
  it cannot fill just drains; a basin whose lowest cell is steppe or desert is endorheic: a salt lake of
  that balanced size (level: the height that gives that area), its rim re-flooded from the lake so every
  cell of the basin drains into it, and rivers end there (prompt 65 turns them into chotts). Lakes under
  `lake_min_area` are left out. Flow: catchment area weighted by rain, `dry_weight + (1 - dry_weight) x
''', '''  filled flats. A filled basin (8-connected cells the flood fills deeper than `basin_depth`, 1 cm) is
  considered for a lake only if deeper than `lake_min_depth` (3 m) and larger than `lake_min_area` (0.5
  km2); its lake surface is `lake_area_per_flow` (0.04) km2 per km2 of rain-weighted inflow. A basin of wet
  country that this fills spills over (a fresh lake at the spill level, its river goes on from the outlet);
  one it does not fill just drains. A basin whose lowest cell is steppe or desert always stays closed
  (Ali, 4 November): a salt lake of that balanced size, never under `lake_min_area`, however little water
  reaches it; the rest of the basin is re-flooded from the lake so every cell of it drains in, and rivers
  end there (prompt 65 turns them into chotts). A lake is the 4-connected water around the basin's lowest
  cell, at the lowest level that covers its cells (so its shore is one ring and all a closed basin's water
  counts for one lake); other hollows under that level stay out: their water drains on into the lake, so
  no river ends where no shore is drawn. Flow: catchment area weighted by rain, `dry_weight + (1 - dry_weight) x
''')
sub('''  mean moisture is under `seasonal_moisture` (an oued); `profile` the bed height per point: the filled
  height along the D8 path, made non-increasing with a running minimum (smoothing only averages it, so it
  never rises downstream); `mouth` `sea` | `lake` | `basin` | `border` | `river`, `into` the lake or river
  id. `Lake(id, polygon, level, salt)`: the shore ring where the ground inside the basin meets `level`.
''', '''  mean moisture is under `seasonal_moisture` (an oued); `profile` the bed height per point, the highest bed
  that never rises downstream, never lies above the ground under the drawn line and lets every tributary end
  exactly on its main river's bed: the running minimum of the ground along the line, worked out tributaries
  first, each tributary's end carried into its main river. Prompt 59 first asked for the filled height, but
  that flies over every hollow a river crosses (up to 55 m on the 64 km world) and prompt 60 can only cut
  the ground, never lift it; so a river crossing a hollow goes down to the floor and cuts through the rim,
  and its main river stays under it from their junction on (on the 64 km world 36 km of the 525 km of rivers
  run over 10 m under the ground). Over a lake the bed is the lake's level (a fresh lake's outlet starts
  there), or a salt lake's floor. `mouth` `sea` | `lake` | `basin` | `border` | `river`, `into` the lake or
  river id. `Lake(id, polygon, level, salt)`: the shore ring where the ground meets `level`.
''')
open(p, "w", encoding="utf-8").write(s)
