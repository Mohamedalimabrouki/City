import sys
sys.path.insert(0, sys.argv[1])
import numpy as np, shapely
from scipy import ndimage
from shapely.geometry import Polygon, Point
from citygen.config import load_config
from citygen.terrain import Terrain
from citygen import hydro
cfg = load_config(); ter = Terrain(42, cfg); rc = cfg["rivers"]
rivers, lakes = hydro.drainage(ter, cfg); g = hydro._routing(ter, rc)
cell = g.c[1]-g.c[0]; n=g.n
for k in lakes:
    mask=(g.lake_id==k.id).reshape(n,n)
    ys,xs=np.nonzero(mask)
    poly=Polygon(k.polygon)
    d=shapely.distance(poly, shapely.points(g.c[xs], g.c[ys]))
    parts4=ndimage.label(mask)[1]
    ring_cells=(d==0).sum()
    if d.max()>cell*0.75 or parts4>1:
        print("lake",k.id,"salt",k.salt,"cells",mask.sum(),"4-parts",parts4,"sizes",np.bincount(ndimage.label(mask)[0].ravel())[1:].tolist(),"farthest cell from ring (m)",round(float(d.max()),0),"poly km2",round(poly.area/1e6,2),"cells km2",round(mask.sum()*cell*cell/1e6,2))
r=rivers[14]
print(r.mouth, r.into, r.flow, r.coords[:3].tolist(), r.profile[:6])
