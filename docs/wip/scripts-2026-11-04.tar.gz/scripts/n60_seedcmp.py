import json, collections, sys
a = json.load(open(sys.argv[1])); b = json.load(open(sys.argv[2]))
moved = []
tot = collections.Counter()
for k in a:
    pa = {(s[0], s[1], s[2]): s[3] for s in a[k]}; pb = {(s[0], s[1], s[2]): s[3] for s in b[k]}
    cap_a = [s for s in a[k] if s[0] == "capital"]; cap_b = [s for s in b[k] if s[0] == "capital"]
    ca = {x for x in pa if x[0] == "city"}; cb = {x for x in pb if x[0] == "city"}
    tot["worlds"] += 1
    tot["capital same"] += cap_a == cap_b
    tot["cities"] += len(ca); tot["cities same"] += len(ca & cb)
    if ca != cb: moved.append((k, len(ca), len(ca & cb)))
print(dict(tot)); print("worlds where a city moved:", moved)
