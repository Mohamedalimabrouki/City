import sys,json; sys.path.insert(0,'.')
from citygen.interior.context import city_plan, load_build, layout_of
from citygen.city.dressing import building_highs
ctx=load_build('output/bodjantouna-42',log=lambda m:None); plan=city_plan(ctx,None); d=ctx.dresser(plan)
out={}
for k,b in enumerate(plan.buildings):
    if b.kind in('house','domed','apartments','villa'):
        ps=d.building(k,float(building_highs(ctx.ground,[b])[0]))
        out[k]=(plan.districts[b.district].kind,b.kind,[(p.piece,round(p.x,4),round(p.y,4),round(p.z,4),round(p.yaw,5),p.scale,round(p.stretch,4)) for p in ps])
json.dump(out,open(sys.argv[1],'w'))
