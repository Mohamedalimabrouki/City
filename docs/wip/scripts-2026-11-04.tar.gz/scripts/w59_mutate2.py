import subprocess, sys
PY = sys.executable
F = "citygen/hydro.py"
good = open(F).read()
M = {
 "rounds off: only the first round of lakes": ('''        if not basins:                  # a pit that failed once fails again, so this ends
''', '''        if not basins or lakes:
'''),
 "wet hollows drain again": ('''        wet = max(balance, math.ceil(min_cells)) if is_salt else int(size)
''', '''        wet = max(balance, math.ceil(min_cells))
        if not is_salt and wet < size:
            continue
'''),
 "pockets take the first lake's kind": ('''        for lab, wet, is_salt in basins:
''', '''        for lab, wet, is_salt in basins:
            is_salt = is_salt or any(l.salt for l in lakes)
'''),
 "rule (a) off: dry basins with little water drain": ('''        wet = max(balance, math.ceil(min_cells)) if is_salt else int(size)
''', '''        wet = balance if is_salt else int(size)
        if wet < min_cells:
            continue
'''),
 "rule (b) off: every pocket under the level is water": ('''        parts, _ = ndimage.label(m & (h <= level))
        return parts == parts[bottom]
''', '''        return m & (h <= level)
'''),
 "8-connected lake (a corner joins two parts)": ('''        parts, _ = ndimage.label(m & (h <= level))
''', '''        parts, _ = ndimage.label(m & (h <= level), np.ones((3, 3), dtype=bool))
'''),
 "bed = the flood's filled height": ('''        z = np.where(g.lake_id[cells] >= 0, g.flat[cells], terrain.height(xy[:, 0], xy[:, 1]))
''', '''        z = g.flat[cells]
'''),
 "no tributary reaches its main bed": ('''        for at, low in joins.get(rid, []):
            z[at] = min(z[at], low)
''', ''),
 "tributary keeps its own end": ('''    z[-1] = float(np.interp(s, _along(main_xy), main_z))
''', ''),
 "shore half a cell inside": ('''    f = np.where(mask, H, np.maximum(H, level + 1.0))   # other hollows under the level stay out
''', '''    f = np.where(mask, H, level + 50.0)
'''),
 "salt re-flood skipped": ('''                recv[gi[dry_cells]] = gi[sub_r[dry_cells]]
''', ''),
}
caught = 0
try:
    for name, (a, b) in M.items():
        assert good.count(a) == 1, a
        open(F, "w").write(good.replace(a, b))
        try:
            r = subprocess.run([PY, "-m", "pytest", "-q", "--no-header", "-p", "no:cacheprovider", "tests/test_hydro.py", "--tb=no"], capture_output=True, text=True, timeout=120)
            failed = [l.split("::")[1].split(" ")[0] for l in r.stdout.splitlines() if l.startswith("FAILED")]
        except subprocess.TimeoutExpired:
            failed = ["TIMEOUT"]
        caught += bool(failed)
        print(f"{name}: {len(failed)} failed")
        for f in failed[:7]:
            print("     ", f)
finally:
    open(F, "w").write(good)
print("caught", caught, "of", len(M))
