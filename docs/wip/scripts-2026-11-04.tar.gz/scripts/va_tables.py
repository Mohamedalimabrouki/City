import json
rows=[];plans=[]
import os
for line in open(os.environ.get('GATES','/tmp/claude-501/va_tmp/gates_final9.log')):
    if line.startswith('{"seed"'):
        d=json.loads(line)
        (rows if 'country_s' in d else plans).append(d)
print('| world | country s | rivers (dry) | km | lakes (salt) | roads km | road in a lake | river crossings, longest m | over 60 m | town or village center on water | water rises | step at mouth or junction m | bank over water: min, p1, p50, p99, max | under water of ~57k |')
print('|---|---|---|---|---|---|---|---|---|---|---|---|---|---|')
for d in rows:
    b=d['bank_over_water']; s=d['step_at_mouth']
    print(f"| {d['size']} {d['seed']} | {d['country_s']} | {d['rivers']} ({d['seasonal']}) | {d['river_km']} | {d['lakes']} ({d['salt']}) | {d['road_km']} | {d['roads_in_lake']} | {d['crossings']}, {d['longest_crossings'][0][0] if d['longest_crossings'] else 0} | {d['over_60']} | {d['towns_villages_on_water']} | {d['water_rises_max']} | {max(s.values())} | {b['min']}, {b['p1']}, {b['p50']}, {b['p99']}, {b['max']} | {b['below_0']} of {b['points']} |")
print()
print('| world | settlements | crashes | with a river | buildings in the corridor | street surface in it m2 | crossings | stations | ports | under 99.5% as streets are | with crossings as links |')
print('|---|---|---|---|---|---|---|---|---|---|---|')
for d in plans:
    print(f"| {d['size']} {d['seed']} | {d['settlements']} | {d['crashes']} | {d['with_river']} | {d['in_corridor']} | {d['streets_in_corridor_m2']} | {d['crossings']} | {d['stations']} | {d['ports']} | {d['under_99.5']} | {d['under_99.5_with_crossings']} |")
