import json, sys
a = json.load(open(sys.argv[1])); b = json.load(open(sys.argv[2]))
def key_b(x): return json.dumps([x["kind"], x["footprint"]], sort_keys=True)
def key_s(x): return json.dumps([x["kind"], x["width"], x["coords"]])
for name, key, part in (("buildings", key_b, "buildings"), ("streets", key_s, "streets")):
    A, B = {key(x) for x in a[part]}, {key(x) for x in b[part]}
    print(f"{name}: {len(a[part])} -> {len(b[part])}, the same in both {len(A & B)} ({100 * len(A & B) / len(A):.1f}%)")
print("districts by (kind, name):", len({(d['kind'], d['name']) for d in a['districts']} & {(d['kind'], d['name']) for d in b['districts']}), "of", len(a['districts']), "->", len(b['districts']))
print("landmarks by (kind, name):", len({(d['kind'], d['name']) for d in a['landmarks']} & {(d['kind'], d['name']) for d in b['landmarks']}), "of", len(a['landmarks']), "->", len(b['landmarks']))
print("trees", len(a["trees"]), "->", len(b["trees"]), "households", len(a["households"]), "->", len(b["households"]), "souks", len(a["souks"]), "->", len(b["souks"]))
print("boundary same:", a["boundary"] == b["boundary"])
for k in ("kind", "x", "y", "population", "radius", "elevation", "coastal", "biome", "known_for", "founded", "name", "id"):
    if a["settlement"].get(k) != b["settlement"].get(k): print(" settlement differs in", k)
