import json, sys, collections
b, a = (json.load(open(p)) for p in sys.argv[1:3])
print(f"{'group':9}{'homes':>6}{'pass':>11}{'same':>6}{'won':>5}{'lost':>5}{'crash':>7}{'flats':>13}{'chambres':>15}{'salons':>13}{'narrow':>9}")
gs = sorted({r["g"] for r in b.values()} | {r["g"] for r in a.values()})
def tot(d, g, f):
    return sum(f(r) for r in d.values() if r["g"] == g)
for g in gs:
    keys = [k for k in a if k in b and a[k]["g"] == g]
    same = sum(a[k].get("h") == b[k].get("h") for k in keys)
    won = sum(bool(a[k].get("ok")) and not b[k].get("ok") for k in keys)
    lost = sum(bool(b[k].get("ok")) and not a[k].get("ok") for k in keys)
    T = lambda d, t: tot(d, g, lambda r: r.get("types", {}).get(t, 0))
    P = lambda d, f: tot(d, g, f)
    print(f"{g:9}{len(keys):6}{P(b, lambda r: bool(r.get('ok'))):5}->{P(a, lambda r: bool(r.get('ok'))):<4}{same:6}{won:5}{lost:5}"
          f"{P(b, lambda r: 'crash' in r):3}->{P(a, lambda r: 'crash' in r):<2}{P(b, lambda r: r.get('flats', 0)):6}->{P(a, lambda r: r.get('flats', 0)):<6}"
          f"{T(b, 'chambre'):7}->{T(a, 'chambre'):<6}{T(b, 'salon'):6}->{T(a, 'salon'):<6}{P(b, lambda r: r.get('narrow', 0)):4}->{P(a, lambda r: r.get('narrow', 0)):<4}")
