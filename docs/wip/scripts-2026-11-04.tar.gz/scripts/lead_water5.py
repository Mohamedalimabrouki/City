"""Option: a salt lake needs a river that ends in it. Draw the country map with and without the unfed ones."""
import sys
from pathlib import Path
from PIL import Image, ImageDraw
sys.path.insert(0, ".")
from shapely.geometry import LineString, Point, Polygon
from shapely.ops import unary_union
from citygen.config import load_config
from citygen.export.maps import country_map
from citygen.world import generate_world
SP = Path(sys.argv[1])
out = []
for seed in (42, 7):
    cfg = load_config(quick=False)
    cfg["world"]["seed"] = seed
    w = generate_world(cfg)
    ends = {r.into for r in w.rivers if r.mouth in ("lake", "basin")}
    a = SP / f"lead_map_all_{seed}.png"
    country_map(w, a, width=1400)
    wet = unary_union([Polygon(k.polygon).buffer(0) for k in w.lakes])
    t0 = sum(Point(s.x, s.y).buffer(s.radius).intersects(wet) for s in w.settlements)
    r0 = sum(LineString(r.coords).intersects(wet) for r in w.roads)
    fresh_none = sum(1 for k in w.lakes if not k.salt and k.id not in ends and not any(
        Polygon(k.polygon).buffer(160).contains(Point(r.coords[0])) for r in w.rivers))
    all_salt = sum(k.salt for k in w.lakes)
    w.lakes = [k for k in w.lakes if not k.salt or k.id in ends]
    wet = unary_union([Polygon(k.polygon).buffer(0) for k in w.lakes])
    t1 = sum(Point(s.x, s.y).buffer(s.radius).intersects(wet) for s in w.settlements)
    r1 = sum(LineString(r.coords).intersects(wet) for r in w.roads)
    b = SP / f"lead_map_fed_{seed}.png"
    country_map(w, b, width=1400)
    print(f"seed {seed}: salt {all_salt} -> {sum(k.salt for k in w.lakes)}; fresh {sum(not k.salt for k in w.lakes)} ({fresh_none} with no river at all); towns touching {t0} -> {t1}; roads crossing {r0} -> {r1}")
    ia, ib = Image.open(a).convert("RGB"), Image.open(b).convert("RGB")
    sheet = Image.new("RGB", (ia.width * 2 + 10, ia.height + 26), "white")
    sheet.paste(ia, (0, 26)); sheet.paste(ib, (ia.width + 10, 26))
    d = ImageDraw.Draw(sheet)
    d.text((6, 6), f"seed {seed}: every salt lake", fill="black")
    d.text((ia.width + 16, 6), f"seed {seed}: only salt lakes a river ends in", fill="black")
    sheet.save(SP / f"lead_map_sheet_{seed}.png")
