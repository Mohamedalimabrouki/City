"""How much of a city plan stayed: buildings by footprint, per district, base build against new build."""
import json, sys, collections
a=json.load(open(sys.argv[1])); b=json.load(open(sys.argv[2]))
ka={d['id']:d['kind'] for d in a['districts']}; kb={d['id']:d['kind'] for d in b['districts']}
fa=collections.Counter(); same=collections.Counter()
setb={json.dumps(x['footprint']) for x in b['buildings']}
for x in a['buildings']:
    k=ka.get(x['district'],'?'); fa[k]+=1
    if json.dumps(x['footprint']) in setb: same[k]+=1
for k in sorted(fa): print(k, fa[k], 'kept', same[k], f"{100*same[k]/fa[k]:.0f}%")
print('all', sum(fa.values()), 'new', len(b['buildings']), 'kept', sum(same.values()))
print('streets', len(a['streets']), len(b['streets']), 'same', len({json.dumps(s['coords']) for s in a['streets']} & {json.dumps(s['coords']) for s in b['streets']}))
print('roads?')
