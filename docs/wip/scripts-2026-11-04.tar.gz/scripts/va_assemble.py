"""Put docs/wip/valleys.md together from the four drafts and the fills in va_fill.json."""
import json
import subprocess

SP = '/private/tmp/claude-501/-Users-mohamedalimabrouki-Desktop/3a588b2b-bf2f-4191-acd4-5b1ae750c3f3/scratchpad/'
head, mid, tail, end = (open(SP + f'va_notes_{n}.md').read() for n in ('head', 'mid', 'tail', 'end'))
tables = subprocess.run(['/Users/mohamedalimabrouki/Desktop/City/.venv/bin/python', SP + 'va_tables.py'],
                        capture_output=True, text=True, check=True).stdout
t1, t2 = (t.strip() for t in tables.split('\n\n', 1))
fills = json.load(open(SP + 'va_fill.json'))
fills['TABLE1'], fills['TABLE2'] = t1, t2
text = head.rstrip() + '\n\n' + mid.rstrip() + '\n\n' + tail.rstrip() + '\n' + end
for key, value in fills.items():
    assert '@@' + key + '@@' in text, key
    text = text.replace('@@' + key + '@@', value)
assert '@@' not in text
assert '-' not in text
open('/tmp/claude-501/valleys/docs/wip/valleys.md', 'w').write(text)
print(len(text.splitlines()), 'lines')
