import subprocess,sys,shutil,os
SP=sys.argv[1]; PY='/Users/mohamedalimabrouki/Desktop/City/.venv/bin/python'
SRC='/tmp/claude-501/facades'
M=[
 ('door-window kept a window','citygen/city/dressing.py','''        p.piece = next(n for n in (f"window_door_{family}{tint}", f"window_door_{tint}") if n in self.kit.pieces)''','''        pass''','iron_balcony'),
 ('rail counts as opening','citygen/interior/outside.py','''if cat not in FACADE or p.piece in railings:''','''if cat not in FACADE:''','a_door_window_is'),
 ('balconnets on the terrace','citygen/city/dressing.py','''if floor < 1 or i % step or slot[6] or (floor == 1 and any(s0 < s < s1 for s0, s1 in covered.get(wall, ()))):''','''if floor < 1 or i % step or slot[6]:''','colonial_arcades'),
 ('balconnets on clotheslines','citygen/city/dressing.py','''if floor < 1 or i % step or slot[6] or (floor''','''if floor < 1 or i % step or (floor''','iron_balcony'),
 ('door-window moved','citygen/city/dressing.py','''        family = "kit_" if p.piece.startswith("tounes/") else ""''','''        p.z -= 0.1
        family = "kit_" if p.piece.startswith("tounes/") else ""''','draw_nothing'),
 ('door-window category window','citygen/mesh/props.py','''pieces["window_door_" + color[5:]] = (window_door(color, iron, "plain"), "balcony", "wall")''','''pieces["window_door_" + color[5:]] = (window_door(color, iron, "plain"), "window", "wall")''','reach_the_floor'),
 ('narrow balcony','styles/maghreb.toml','''width = 1.8 ''','''width = 1.2 ''','reach_the_floor'),
 ('no lit twin','citygen/mesh/props.py','''    _faces(mb, [_front(-x, x, z0, head, g)], "glass_dark")''','''    _faces(mb, [_front(-x, x, z0, head, g)], "iron")''','reach_the_floor'),
 ('gables in the old stream','styles/maghreb.toml','''gable_bay = 0.0 ''','''gable_bay = 3.2 ''','new_windows'),
 ('stair window high','styles/maghreb.toml','''stair_window = 0.25 ''','''stair_window = 0.55 ''','stair_windows'),
 ('persienne back gone','citygen/mesh/props.py','''        _faces(mb, [_front(x0, x1, f, h - f, 0.06, back=True) for x0, x1 in leaves], color)   # seen from the room
''','','persienne'),
]
for name,f,a,b,k in M:
    d=SP+'/fa_mut'
    subprocess.run(f"cd {SRC} && tar --exclude=./output --exclude=./.git --exclude=__pycache__ -cf - . | tar -xf - -C {d}",shell=True,check=True)
    s=open(f'{d}/{f}').read()
    assert a in s,name
    open(f'{d}/{f}','w').write(s.replace(a,b))
    r=subprocess.run([PY,'-m','pytest','-q','-x','tests/test_citygen.py','-k',k],cwd=d,capture_output=True,text=True)
    print(name,'->',r.stdout.strip().splitlines()[-1][:90],flush=True)
