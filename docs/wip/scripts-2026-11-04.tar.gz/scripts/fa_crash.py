import sys,traceback; sys.path.insert(0,'.')
from citygen.interior.context import city_plan, load_build
from citygen.interior.layout import plan_interior
from citygen.interior.outside import Outside
ctx=load_build('output/bodjantouna-42',log=lambda m:None); plan=city_plan(ctx,None)
k=int(sys.argv[1])
try: plan_interior(Outside(ctx,plan,k),ctx.world.style)
except Exception: traceback.print_exc()
