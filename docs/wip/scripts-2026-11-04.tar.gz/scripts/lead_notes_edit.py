import re
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
p = Path("docs/wip/world-59.md")
s = p.read_text()
# the speckle paragraph
a = s.index("**The dry country is more speckled, as you feared.**")
b = s.index("\n\n", a)
s = s[:a] + ("**The dry country was speckled, and the lead fixed that last (his own commit on this branch):** the pockets took the salt lakes\n"
"from 63 to 87, and 49 of the 87 had no river ending in them, 40 of those at the smallest size. A salt flat needs water to come to\n"
"it, so `hydro._drawn` keeps every fresh lake and only the salt lakes a river ends in; the other hollows stay closed, on bare\n"
"ground. Salt lakes 87 -> 38 (seed 7: 93 -> 35; seed 3: 81 -> 33), towns touching a lake 14 -> 10, roads crossing one 19 -> 13.\n"
"It narrows Ali's (a) (\"every dry basin ... stays a closed salt lake\"): every such basin stays closed, as he chose, but only\n"
"the fed ones show salt. No river changed: none ends in those hollows. The picture shows the result.") + s[b:]
# the step table
s = s.replace("| | fix-59 | Ali's answers (77cfe16) | wet lakes (ad22101) | now, pockets too |\n|---|---|---|---|---|",
              "| | fix-59 | Ali's answers (77cfe16) | wet lakes (ad22101) | pockets too (7af6644) | now, fed salt lakes only |\n|---|---|---|---|---|---|")
for old, new in [
    ("| Lakes, fresh + salt | 10 + 31 | 10 + 63 | 26 + 63 | 28 + 87 |", "| Lakes, fresh + salt | 10 + 31 | 10 + 63 | 26 + 63 | 28 + 87 | 28 + 38 |"),
    ("| Rivers, km of river | 157, 525 | 150, 526 | 154, 495 | 148, 424 |", "| Rivers, km of river | 157, 525 | 150, 526 | 154, 495 | 148, 424 | 148, 424 |"),
    ("| Over 10 m under the ground, km | | 35.6 | 24.0 | 0.0 |", "| Over 10 m under the ground, km | | 35.6 | 24.0 | 0.0 | 0.0 |"),
    ("| Over 20 m, km | | 20.2 | 14.7 | 0.0 |", "| Over 20 m, km | | 20.2 | 14.7 | 0.0 | 0.0 |"),
    ("| Worst cut, m | | 58.6 | 50.9 | 10.3 |", "| Worst cut, m | | 58.6 | 50.9 | 10.3 | 10.3 |"),
    ("| Bed under its lake's level, ground above, worst m | | 15.3 | 14.5 | 3.1 |", "| Bed under its lake's level, ground above, worst m | | 15.3 | 14.5 | 3.1 | 3.1 |"),
    ("| Towns touching a lake | 9 | 9 | 12 | 14 |", "| Towns touching a lake | 9 | 9 | 12 | 14 | 10 |"),
    ("| Roads crossing a lake | 12 | 13 | 18 | 19 |", "| Roads crossing a lake | 12 | 13 | 18 | 19 | 13 |"),
    ("| 64 km, seed 42 | 424 | 28 + 87 | 0.0 | 0.0 | 10.3 | 2.8, 3.1 | 14 of 131 | 19 of 141 |", "| 64 km, seed 42 | 424 | 28 + 38 | 0.0 | 0.0 | 10.3 | 2.8, 3.1 | 10 of 131 | 13 of 141 |"),
    ("| 64 km, seed 7 | 419 | 33 + 93 | 0.7 | 0.0 | 18.4 | 1.5, 3.3 | 7 of 131 | 19 of 143 |", "| 64 km, seed 7 | 419 | 33 + 35 | 0.7 | 0.0 | 18.4 | 1.5, 3.3 | 5 of 131 | 11 of 143 |"),
    ("| 64 km, seed 3 | 425 | 28 + 81 | 1.5 | 0.3 | 33.4 | 2.7, 4.5 | 19 of 131 | 22 of 144 |", "| 64 km, seed 3 | 425 | 28 + 33 | 1.5 | 0.3 | 33.4 | 2.7, 4.5 | 14 of 131 | 18 of 144 |"),
    ("| Quick, seed 42 | 34 | 0 + 4 | 0.1 | 0.0 | 10.4 | 0.0, 2.6 | 0 of 14 | 0 of 14 |", "| Quick, seed 42 | 34 | 0 + 2 | 0.1 | 0.0 | 10.4 | 0.0, 2.6 | 0 of 14 | 0 of 14 |"),
    ("| Quick, seed 7 | 26 | 0 + 7 | 0.0 | 0.0 | 4.0 | 0.5, 0.5 | 0 of 14 | 2 of 14 |", "| Quick, seed 7 | 26 | 0 + 4 | 0.0 | 0.0 | 4.0 | 0.5, 0.5 | 0 of 14 | 0 of 14 |"),
    ("| Quick, seed 3 | 37 | 0 + 4 | 0.1 | 0.0 | 11.8 | 0.0, 0.0 | 1 of 14 | 1 of 14 |", "| Quick, seed 3 | 37 | 0 + 1 | 0.1 | 0.0 | 11.8 | 0.0, 0.0 | 0 of 14 | 0 of 14 |"),
    ("**Tests:** merge of 70 + 81: 178 passed. After their fixes: 182. Now: 206 passed,", "**Tests:** merge of 70 + 81: 178 passed. After their fixes: 182. At 7af6644: 206 passed. Now, with the fed-lake rule: 209 passed (run by the lead; its three new tests fail without the rule). The helper's run at 7af6644:"),
    # paste text
    ("- Checks: tests 206 passed, slow 15 passed + the old xfail;", "- Checks: tests 209 passed, slow 15 passed + the old xfail;"),
    ("plans unchanged. Country step 1.3 s (budget 10 s).", "plans unchanged. Country step 1.4 s (budget 10 s)."),
    ("- Rivers (Ali's answers): every dry basin over 3 m and 0.5 km2 stays a closed salt lake; towns by salt lakes accepted;\n", "- Rivers (Ali's answers): every dry basin over 3 m and 0.5 km2 stays closed; towns by salt lakes accepted;\n"),
    ("ends where no shore is drawn). 64 km world: 28 fresh + 87 salt lakes, 148 rivers, 424 km.\n", "ends where no shore is drawn); a salt lake needs a river that ends in it (49 of 87 had none and only speckled the dry\n  country; those hollows stay closed, on bare ground). 64 km world: 28 fresh + 38 salt lakes, 148 rivers, 424 km.\n"),
    ("  (counting only what reaches it loses the great chotts, picture docs/wip/world-59-inflow.png). The dry country is busier\n  (66 of 87 salt lakes under 1 km2). 14 towns touch a lake and 19 roads cross one, for prompt 60 to move.\n", "  (counting only what reaches it loses the great chotts, picture docs/wip/world-59-inflow.png). 10 towns touch a lake and\n  13 roads cross one, for prompt 60 to move.\n"),
    ("- Doubts and questions for Ali: none; the lead decided the wet hollows and the pockets.\n", "- Doubts and questions for Ali: none; the lead decided the wet hollows, the pockets and the fed salt lakes.\n"),
    ("- **A lake's size is a look as much as a number.**", "- **A lake needs water that reaches it.** 49 of 87 salt lakes had no river: a look fault (speckle) with a logic cause. Keep\n  a dry hollow closed, but show salt only where a river ends. Removing them moves no river, and fewer towns have to move.\n- **A lake's size is a look as much as a number.**"),
]:
    assert old in s, old
    s = s.replace(old, new)
s = s.replace("### docs/LEAD.md, section 3\n", "### docs/LEAD.md, section 3\n- **Take a number down to its causes.** \"36 km of river deep under the ground\" was accepted as a price until a list of every\n  stretch with what lay at its low point showed one cause, pockets of salt basins, and a two-line idea removed it all.\n  Scripts for a world step: keep them in the scratchpad, `lead_water*.py`.\n")
p.write_text(s)

# the picture: keep the helper's before panel, draw the new now panel
from citygen.config import load_config
from citygen.export.maps import country_map
from citygen.world import generate_world
w = generate_world(load_config(quick=False))
out = Path("docs/wip/world-59-maps.png")
old = Image.open(out).convert("RGB")
W, H = old.size
half = W // 2
strip = H - (H - 0)  # title strip is found from the panel width
tmp = Path(__import__("sys").argv[1]) / "lead_now.png"
country_map(w, tmp, width=half - 4)
now = Image.open(tmp).convert("RGB")
top = H - now.height
sheet = Image.new("RGB", (W, H), "white")
sheet.paste(old.crop((0, 0, half, H)), (0, 0))
sheet.paste(now, (W - now.width, top))
d = ImageDraw.Draw(sheet)
d.rectangle((half + 1, 0, W, top - 1), fill="white")
try:
    font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", max(12, top // 2))
except OSError:
    font = None
d.text((half + 12, max(2, top // 4)), f"Now: {len(w.rivers)} rivers, {sum(k.salt for k in w.lakes)} salt + {sum(not k.salt for k in w.lakes)} fresh lakes", fill="black", font=font)
sheet.save(out)
print(W, H, now.size, top)
