import sys
sys.path.insert(0, ".")
import numpy as np
from shapely.geometry import Point, LineString
from citygen.config import load_config
from citygen.world import generate_world
from citygen.city import plan_city
from citygen.export import streets as S
w = generate_world(load_config(quick=True)); plan = plan_city(w, w.capital())
nodes, edges = S.street_graph(plan.streets, 0.05)
print("nodes", len(nodes), "edges", len(edges))
for l in S.road_links(w, plan, nodes):
    print(l, "kinds near:", sorted({plan.streets[k].kind for k, line, a, b in edges if a == l["node"] or b == l["node"]}))
    p = Point(l["x"], l["y"])
    near = sorted(((p.distance(st.line), i, st.kind, round(st.width, 1)) for i, st in enumerate(plan.streets)))[:4]
    print("   nearest streets", [(round(a, 3), b, c, d) for a, b, c, d in near])
    print("   ends of the nearest:", [ (tuple(round(v,2) for v in plan.streets[b].line.coords[0]), tuple(round(v,2) for v in plan.streets[b].line.coords[-1])) for a,b,c,d in near[:2]])
