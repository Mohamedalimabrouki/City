"""Every old-town house: door rise, sunken, turned, way, wet room moves: to design stable picks. Writes JSON."""
import sys, collections, time, json
sys.path.insert(0, ".")
import numpy as np, shapely
from citygen.config import load_config
from citygen.world import generate_world
from citygen.city import plan_city
from citygen.city.dressing import building_highs
from citygen.interior import rooms
from citygen.interior.context import BuildContext, layout_of
from citygen.interior.layout import plan_interior
from citygen.interior.outside import Outside
from citygen.interior.plancheck import way_in, way_rooms
world = generate_world(load_config(quick=True))
plan = plan_city(world, world.capital())
ctx = BuildContext(world, [plan], world.capital())
style = world.style
houses = [k for k, b in enumerate(plan.buildings) if b.kind == "house" and layout_of(plan, b, style) in ("dar", "compact", "small")]
d = ctx.dresser(plan)
t = time.time()
rise = {}
for k in houses:
    b = plan.buildings[k]
    high = float(building_highs(ctx.ground, [b])[0])
    sp = d.entrances(k)
    rise[k] = max((high - s.z for s in sp), default=0.0)
print("entrances for", len(houses), "houses:", round(time.time() - t, 2), "s")
t = time.time()
out = []
for k in houses:
    i = plan_interior(Outside(ctx, plan, k), style)
    sunk = any(r.z < i.storeys[0].z - 0.05 for r in i.rooms if r.floor == 0)
    turn = any(s.kind == "steps" and s.turn for s in i.stairs)
    bad = rooms.check(i)
    out.append(dict(k=k, layout=i.layout, rise=round(rise[k], 3), sunk=sunk, turn=turn, ok=not bad, flights=sum(s.kind == "steps" for s in i.stairs)))
print("plans in", round(time.time() - t, 1), "s")
json.dump(out, open(sys.argv[1], "w"))
out.sort(key=lambda o: -o["rise"])
print("sunken", [(n, o["k"], o["layout"], o["rise"], o["ok"]) for n, o in enumerate(out) if o["sunk"]])
print("turned", [(n, o["k"], o["layout"], o["rise"], o["ok"]) for n, o in enumerate(out) if o["turn"]])
