import sys, numpy as np, shapely
from shapely.geometry import LineString, Point, Polygon
sys.path.insert(0,'.')
from citygen.config import load_config
from citygen.hydro import channel, along
from citygen.world import generate_world, _Router, _build_roads
cfg=load_config()
w=generate_world(cfg); c=w.carve
r=w.rivers[119]
print('r119 mouth',r.mouth,r.into,'surface',np.round(r.surface[120:140],2).tolist(),'profile',np.round(r.profile[120:140],2).tolist(),'ground',np.round(w.terrain.height(*r.coords[120:140].T),2).tolist())
r=w.rivers[0]
print('r0 source',r.source,'lvl',w.lakes[r.source].level,np.round(r.surface[20:34],2).tolist(),'ground',np.round(w.terrain.height(*r.coords[20:34].T),2).tolist())
rt=_Router(w.terrain,float(cfg["roads"]["routing_cell"]),w.rivers,c,{"lake_margin":cfg["roads"]["lake_margin"],"road_cost":cfg["rivers"]["road_cost"]})
ro=w.roads[30]
print(len(ro.coords),np.round(ro.coords[::6],0).tolist())
xy=ro.coords
ix=(xy/rt.cell).astype(int); k=ix[:,1]*rt.n+ix[:,0]
print('points on water cells',rt.water[k].sum(), 'of',len(k), 'lake 37 poly bbox',w.lakes[37].polygon.min(axis=0),w.lakes[37].polygon.max(axis=0))
