"""Same cameras before and after: python va_look.py NAME [NAME...] (run with the sandbox off)."""
import subprocess, sys
from pathlib import Path
from PIL import Image, ImageDraw
PY='/Users/mohamedalimabrouki/Desktop/City/.venv/bin/python'
T='/tmp/claude-501/va_tree4/tools/snapshot.py'
LOOKS={ # name: (base folder, new folder, camera query)
 'valley': ('mid','mid','cam=18050,25600,250&look=19000,26300,48'),
 'valley_low': ('mid','mid','cam=18990,26040,120&look=19120,26180,52'),
 'lake': ('lake2','lake2','cam=26450,19680,400&look=25350,20600,292'),
 'shore': ('lake3','lake3','cam=26950,20700,345&look=27100,21250,298'),
 'shore_high': ('lake3','lake3','cam=27000,18800,1400&look=27000,21400,300'),
 'capital_river': ('full','full','cam=35035,52930,62&look=34905,53290,20'),
 'road_far': ('mid','mid','cam=19150,26560,130&look=19260,26790,60'),
 'capital_bank': ('full','full','cam=35022,53060,39&look=34918,53256,24'),
 'salt': ('salt2','salt2','cam=33200,17950,520&look=34350,16800,396'),
 'city': ('city','city','cam=25560,41150,210&look=24900,41870,42'),
 'lakecity': ('lakecity','lakecity','cam=8800,2850,420&look=8700,4100,290'),
 'town': ('town','town','cam=3640,8800,190&look=3360,9120,110'),
 'capital': ('full','full','cam=34300,52500,380&look=34850,53300,18'),
 'quick': ('quick',None,'cam=6050,10450,260&look=6420,11120,14'),
}
for name in sys.argv[1:]:
    b,n,q=LOOKS[name]
    shots=[]
    for label,root,folder in (('before','/tmp/claude-501/va_base_out',b),('after','/tmp/claude-501/va_out',n)):
        src = (f'{root}/{folder}/bodjantouna-42' if folder else '/tmp/claude-501/va_tree4/output/bodjantouna-42')
        png=f'/tmp/claude-501/va_shots/{name}_{label}.png'
        r=subprocess.run([PY,T,src,'--png',png,'--view','aerial','--width','960','--height','720','--gpu','--query',q+'&ui=0'],capture_output=True,text=True,cwd='/tmp/claude-501/va_tree4')
        print(name,label,r.stdout.strip()[-60:],r.stderr.strip()[-200:])
        shots.append((label,png))
    a,c=(Image.open(p).convert('RGB') for _,p in shots)
    sheet=Image.new('RGB',(a.width+c.width+8,a.height),(255,255,255))
    sheet.paste(a,(0,0)); sheet.paste(c,(a.width+8,0))
    d=ImageDraw.Draw(sheet); d.text((12,10),'before',fill=(20,20,20)); d.text((a.width+20,10),'after',fill=(20,20,20))
    Path('/tmp/claude-501/valleys/output/checks').mkdir(parents=True,exist_ok=True)
    sheet.save(f'/tmp/claude-501/valleys/output/checks/valleys_{name}.png')
