"""Compare two gazetteer dumps (n60_gaz.py): how many settlements keep their exact place, population, by kind."""
import json, sys, collections
a = json.load(open(sys.argv[1])); b = json.load(open(sys.argv[2]))
print("country", a["country"], "->", b["country"], "| settlements", len(a["settlements"]), "->", len(b["settlements"]), "| roads", a["roads"], "->", b["roads"])
A = {(s["kind"], s["x"], s["y"]): s for s in a["settlements"]}
B = {(s["kind"], s["x"], s["y"]): s for s in b["settlements"]}
for kind in ("capital", "city", "town", "village"):
    total_a = sum(s["kind"] == kind for s in a["settlements"]); total_b = sum(s["kind"] == kind for s in b["settlements"])
    same = [k for k in A if k[0] == kind and k in B]
    pop = sum(A[k]["population"] == B[k]["population"] for k in same)
    name = sum(A[k]["name"] == B[k]["name"] for k in same)
    sid = sum(A[k]["id"] == B[k]["id"] for k in same)
    print(f"{kind:8s} before {total_a:3d} after {total_b:3d}  same place {len(same):3d}  of those same population {pop:3d}, same name {name:3d}, same id {sid:3d}")
for k in sorted(set(A) & set(B), key=lambda k: A[k]["id"]):
    s, t = A[k], B[k]
    if k[0] in ("capital", "city"):
        print(f"  {s['id']:3d}->{t['id']:3d} {k[0]:7s} {s['name']:24s} -> {t['name']:24s} pop {s['population']:7d} -> {t['population']:7d}  r {s['radius']:.0f} -> {t['radius']:.0f} coastal {s['coastal']}->{t['coastal']}  founded {s['founded']!r}->{t['founded']!r}")
