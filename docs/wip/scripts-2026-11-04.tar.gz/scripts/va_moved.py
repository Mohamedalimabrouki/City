import json, os
import numpy as np
T='/tmp/claude-501/va_tmp/'
for size in ('quick','full'):
    for seed in (42,7,3):
        b=json.load(open(f'{T}base_{seed}_{size}.json')); n=json.load(open(f'{T}world_{seed}_{size}.json'))
        key=lambda r:(r['kind'],round(r['x'],3),round(r['y'],3))
        B={key(r):r for r in b}; N={key(r):r for r in n}
        same=set(B)&set(N)
        out={}
        for k in ('capital','city','town','village'):
            nb=sum(r['kind']==k for r in b); stay=sum(x[0]==k for x in same)
            out[k]=(stay,nb, sum(r['kind']==k for r in n))
        line=f'{size} {seed}: stay/base/new '+str(out)
        p=f'{T}plans_{seed}_{size}.json'
        if os.path.exists(p):
            pl=json.load(open(p))
            lost=[]
            base={ (r['kind'],round(r['x'],3)):r for r in b if r['kind'] in ('capital','city')}
            names={ (r['name']):r for r in b}
            for r in pl:
                if r['kind'] in ('capital','city') and 'land' in r:
                    # match by order: capital and cities keep their rank
                    pass
            cs=[r for r in b if r['kind'] in ('capital','city')]
            ps=[r for r in pl if r['kind'] in ('capital','city')]
            for c,q in zip(cs,ps):
                d=c['land']-q['land']
                lost.append((q['name'],round(c['land']/1e6,2),round(q['land']/1e6,2),f"{100*d/c['land']:.1f}%", q['river'],q['crossings']))
            line+='\n   cities base km2 -> new km2, lost, river, crossings: '+str(lost)
        print(line)
