def edit(p, pairs):
    s = open(p, encoding="utf-8").read()
    for a, b in pairs:
        assert s.count(a) == 1, (s.count(a), a)
        s = s.replace(a, b)
    open(p, "w", encoding="utf-8").write(s)
edit("tests/test_citygen.py", [
('''def _phrases(text: str) -> set:
    """Every run of words of a history, in lower case."""
    words = text.lower().replace(",", " ").replace(".", " ").replace(";", " ").split()
    return {" ".join(words[a:b]) for a in range(len(words)) for b in range(a + 1, min(a + 9, len(words)) + 1)}


''', ''),
('''        told = [e for e in eras if {words["era_in"][e].lower(), words["era_since"][e].lower()} & _phrases(d.history)]
''', '''        text = d.history.lower()   # the era's whole phrase: an era's bare name could sit in a landmark's name
        told = [e for e in eras if words["era_in"][e].lower() in text or words["era_since"][e].lower() in text]
'''),
('''    assert _era_phrase(words, "era_in", "the Flood") == "in the time of the Flood" and _era_phrase(words, "era_in", "") == ""
''', '''    assert _era_phrase(words, "era_in", "the Flood") == "in the time of the Flood"
    assert _era_phrase(words, "era_in", "") == ""
'''),
('''    facts = _Facts.__new__(_Facts)
    facts.plan, facts.inside = NS(districts=[NS(id=0, polygon=box(0, 0, 10, 10)), NS(id=1, polygon=box(10, 0, 20, 10))]), 1.0
''', '''    facts = _Facts.__new__(_Facts)
    facts.inside = 1.0
    facts.plan = NS(districts=[NS(id=0, polygon=box(0, 0, 10, 10)), NS(id=1, polygon=box(10, 0, 20, 10))])
'''),
])
