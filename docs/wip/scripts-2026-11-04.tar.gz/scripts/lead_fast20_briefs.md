# Twenty fast helpers (lead, 3 November, about 20:56 UTC): you have 4 minutes in all
Common: work only in your folder /tmp/claude-501/<name> (`cd` there first; a detached worktree already on the right commit). `main` = branch `claude/procedural-city-generator-xop72h`. Python `/Users/mohamedalimabrouki/Desktop/City/.venv/bin/python`. Never the em dash character. Change no code; write only `docs/wip/<name>.md` (plain short English; findings as file:line, severity, one-line fix). Within 3 minutes of starting: commit (message `WIP <name>`, last line `Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>`) and `git push origin HEAD:refs/heads/wip/<name>` with github.com in the Bash call's allowed_domains. Write what you have even if a part is left, and say what is left. Report in one line.

## rev-little, rev-fix70, rev-fix81, rev-colonial, rev-rivers60, rev-lead-notes
Code review of the branch's own commits (`git log --oneline -6` shows where its parent ends; rev-colonial and rev-rivers60: the commits on top of main or rivers-59): correctness, determinism (own random streams, no new draws on old ones, no set order), numbers in toml not code, tests that can fail. rev-lead-notes: is each LEAD.md lesson right and not in conflict with CLAUDE.md?

## rev-kit-hide, rev-kit-brass, rev-kit-textile, rev-kit-goods
Code review of `git diff e871984..HEAD -- citygen tests styles`: geometry bugs (normals, UVs, one-sided faces, sizes against SPEC 6), piece names, materials that could clash with the city's, determinism, tests.

## scan-dash, scan-random, scan-streams
`git fetch origin 'refs/heads/wip/*:refs/remotes/origin/wip/*'`, then for every origin/wip/* branch scan `git diff main...origin/wip/<b>`: scan-dash for the em dash character (U+2014) in added lines; scan-random for `import random`, unseeded numpy, iteration over a set, `hash(`, time or os order; scan-streams for every new `stream(` purpose path and any draw added to an existing purpose. One table per branch.

## check-81, check-mats
Run the full `.venv/bin/python -m pytest -q` here and report pass or fail with the failing tests' names; nothing else.

## spec-55
List every piece of SPEC section 6d and prompt 55 (`grep -n "## 55\." docs/prompts/*.md`) with done (in `citygen/interior/kit_life.py`) or left, and the steps of prompt 55 that are left, as a checklist for the next session.

## spec-54
Prompt 54's text (`grep -n "## 54\." docs/prompts/*.md`) against this branch: each step done, partly done or left, with the file that does it; end with "54 can be ticked: yes/no, because ...".

## prompt-next
From docs/ROADMAP.md and docs/prompts/*.md: the unticked prompts whose "Needs" are all ticked (ready to start now), with one line each on size and risk, and a suggested order.

## questions-ali
Fetch as in scan-*, then collect every open question for Ali from `docs/wip/*.md` on every origin/wip/* branch and from docs/WORKLOG.md: one numbered list, each with its branch and the choices.

## pictures
Fetch as in scan-*, then copy every `docs/wip/*.png` of every origin/wip/* branch (`git show origin/wip/<b>:docs/wip/<f>.png > docs/wip/pictures/<b>-<f>.png`) and write `docs/wip/pictures.html`: each picture with its branch name and the two lines of its notes, one under another, so Ali can open one page and look; commit the folder and the page.
