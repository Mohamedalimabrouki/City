"""Tile build time over a world: every 6th tile of the 64 km world, no plans."""
import sys, time, tempfile, pathlib
sys.path.insert(0,'.')
from citygen.config import load_config
from citygen.world import generate_world
from citygen.mesh.tile import TileContext, export_tile
cfg=load_config(); w=generate_world(cfg)
tc=TileContext(w,[])
keys=[(i,j) for i in range(0,125,6) for j in range(0,125,6)]
d=pathlib.Path(tempfile.mkdtemp(dir='/tmp/claude-501/va_tmp'))
for rep in range(2):
    t=time.perf_counter(); n=0; tris=0
    for i,j in keys:
        e=export_tile(tc,i,j,d); n+=e['bytes']; tris+=e['triangles']
    dt=time.perf_counter()-t
    print('rep',rep,'tiles',len(keys),'ms per tile',round(1000*dt/len(keys),1),'MB',round(n/1e6,1),'tris',tris)
