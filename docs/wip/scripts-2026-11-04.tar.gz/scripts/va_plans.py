"""Plan every settlement of a world and check it against the rivers: python va_plans.py SEED quick|full [workers]"""
import collections, json, multiprocessing, sys, time
import numpy as np, shapely
from shapely.geometry import Point, Polygon
from shapely.ops import unary_union
sys.path.insert(0, '.')
sys.path.insert(0, 'tools')
from citygen.city import plan_city
from citygen.city import river as R
from citygen.config import load_config
from citygen.export.streets import street_graph
from citygen.world import generate_world
seed, size = int(sys.argv[1]), sys.argv[2]
workers = int(sys.argv[3]) if len(sys.argv) > 3 else 6
W = {}
def world():
    if 'w' not in W:
        W['w'] = generate_world(load_config(quick=size == 'quick', overrides={"world": {"seed": seed}}))
    return W['w']
def parts(nodes, edges, links=()):
    parent = list(range(len(nodes)))
    def root(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]; a = parent[a]
        return a
    for _k, _l, a, b in edges:
        parent[root(a)] = root(b)
    for a, b in links:
        parent[root(a)] = root(b)
    out = collections.Counter()
    for _k, l, a, _b in edges:
        out[root(a)] += l.length
    return out
def job(i):
    w = world(); s = w.settlements[i]
    t = time.perf_counter()
    try:
        p = plan_city(w, s)
    except Exception as e:
        import traceback
        return {"i": i, "name": s.name, "kind": s.kind, "crash": repr(e), "trace": traceback.format_exc()[-800:]}
    dt = time.perf_counter() - t
    water = R.corridor(w, s)
    fp = [b.footprint for b in p.buildings]
    tree = shapely.STRtree(fp) if fp else None
    hit = 0; area = 0.0
    if water is not None and tree is not None:
        idx = tree.query(water, predicate="intersects")
        hit = len(idx); area = float(sum(fp[int(k)].intersection(water).area for k in idx))
    st = 0.0
    if water is not None:
        st = float(sum(x.line.buffer(x.width / 2, cap_style="flat").intersection(water).area for x in p.streets if x.line.distance(water) < x.width))
    grid = float(w.cfg["street_graph"]["grid"])
    n, e = street_graph(p.streets, grid)
    pa = parts(n, e)
    from citygen.city.river import crossing_nodes
    links = crossing_nodes(e, p.crossings)
    pb = parts(n, e, links)
    total = sum(pa.values())
    return {"i": i, "name": s.name, "kind": s.kind, "seconds": round(dt, 1), "buildings": len(p.buildings), "in_corridor": hit, "in_corridor_m2": round(area, 2),
            "streets_in_corridor_m2": round(st, 2), "streets": len(p.streets), "parts": len(pa), "share": round(max(pa.values(), default=0) / total, 4) if total else 1.0,
            "parts_linked": len(pb), "share_linked": round(max(pb.values(), default=0) / total, 4) if total else 1.0,
            "crossings": len(p.crossings), "land": round(p.boundary.area), "disc": round(np.pi * s.radius ** 2), "river": water is not None and water.intersects(p.boundary),
            "station": p.station is not None, "port": p.port is not None, "medina": p.medina is not None, "riverside": sum(x.kind == "riverside" for x in p.walks)}
if __name__ == "__main__":
    t0 = time.perf_counter()
    count = len(world().settlements)
    with multiprocessing.get_context("fork").Pool(workers) as pool:
        rows = pool.map(job, range(count), chunksize=1)
    crash = [r for r in rows if "crash" in r]
    ok = [r for r in rows if "crash" not in r]
    print(json.dumps({"seed": seed, "size": size, "settlements": count, "crashes": len(crash), "minutes": round((time.perf_counter() - t0) / 60, 1),
                      "in_corridor": sum(r["in_corridor"] for r in ok), "in_corridor_m2": round(sum(r["in_corridor_m2"] for r in ok), 1), "streets_in_corridor_m2": round(sum(r["streets_in_corridor_m2"] for r in ok), 1),
                      "with_river": sum(r["river"] for r in ok), "more_than_one_part": sum(r["parts"] > 1 for r in ok), "under_99.5": sum(r["share"] < 0.995 for r in ok if r["streets"]),
                      "under_99.5_with_crossings": sum(r["share_linked"] < 0.995 for r in ok if r["streets"]), "crossings": sum(r["crossings"] for r in ok),
                      "stations": sum(r["station"] for r in ok), "ports": sum(r["port"] for r in ok)}))
    for r in crash:
        print("CRASH", r["name"], r["kind"], r["crash"], r["trace"])
    json.dump(rows, open(f"/tmp/claude-501/va_tmp/plans_{seed}_{size}.json", "w"))
    for r in sorted(ok, key=lambda r: r["share_linked"])[:6]:
        print({k: r[k] for k in ("name", "kind", "streets", "parts", "share", "parts_linked", "share_linked", "crossings", "in_corridor")})
