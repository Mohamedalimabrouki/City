import sys
p=sys.argv[1]+"/citygen/hydro.py"; s=open(p).read()
s=s.replace("""        elif wet < size:
            continue
""","""        else:
            wet = size
""")
open(p,"w").write(s)
