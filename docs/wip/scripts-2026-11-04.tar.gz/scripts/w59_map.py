import sys, time
sys.path.insert(0, sys.argv[1])
from pathlib import Path
from citygen.config import load_config
from citygen.world import generate_world
from citygen.export.maps import country_map
t=time.perf_counter()
w=generate_world(load_config())
t=time.perf_counter()-t
country_map(w, Path(sys.argv[2]), width=1800)
print(sys.argv[1], "generate_world", round(t,2), "s; rivers", len(w.rivers), "lakes", len(w.lakes), "salt", sum(k.salt for k in w.lakes), "settlements", len(w.settlements))
