#!/bin/bash
cd "/private/tmp/claude-501/-Users-mohamedalimabrouki-Desktop/3a588b2b-bf2f-4191-acd4-5b1ae750c3f3/scratchpad"
P=/Users/mohamedalimabrouki/Desktop/City/.venv/bin/python
B=/Users/mohamedalimabrouki/Desktop/City/output/bodjantouna-42
$P lead_rooms.py --root /tmp/claude-501/lead-before --folder $B --groups colonial,slab --out lf_before.json --workers 4 > lf_before.txt 2>&1 &
$P lead_rooms.py --root /tmp/claude-501/lead-after --folder $B --groups colonial,slab --out lf_after.json --workers 4 > lf_after.txt 2>&1 &
wait
python3 -I lead_rooms_sum.py lf_before.json lf_after.json
