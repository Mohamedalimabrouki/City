"""Each rule of names-60 taken out in a copy of the tree: which tests fail? Writes a table."""
import os, re, shutil, subprocess, sys
from pathlib import Path
SRC = Path(sys.argv[2])
PY = "/Users/mohamedalimabrouki/Desktop/City/.venv/bin/python"
OUT = Path(sys.argv[1])
K = ("keys_follow or stream_reads or follows_the_key or refused or refusal or change_of_ground or name_clash or pin_ or pinning or describing_word "
     "or fixed_names or country_ending or no_arabic_column")
W, N, L, H = "citygen/world.py", "citygen/names.py", "citygen/export/lore.py", "citygen/city/history.py"
M = [
 ("towns and villages on the shared stream", W, 'grid = rng if kind in ("capital", "city") else stream(seed, "settlements", kind)', 'grid = rng'),
 ("capital draws per candidate", W, 'draw = capital_draw if kind == "capital" else _log_population(stream(seed, "settlements", kind, int(flat)), kc)',
  'draw = _log_population(rng, kc) if kind == "capital" else _log_population(stream(seed, "settlements", kind, int(flat)), kc)'),
 ("cities draw population in turn", W, 'draw = capital_draw if kind == "capital" else _log_population(stream(seed, "settlements", kind, int(flat)), kc)',
  'draw = capital_draw if kind == "capital" else _log_population(rng if kind == "city" else stream(seed, "settlements", kind, int(flat)), kc)'),
 ("towns and villages draw population in turn", W, 'draw = capital_draw if kind == "capital" else _log_population(stream(seed, "settlements", kind, int(flat)), kc)',
  'draw = capital_draw if kind == "capital" else _log_population(rng if kind == "city" else grid, kc)'),
 ("names in list order", W, 'made = namer.settlement(s.kind) if s.kind == "capital" else _fresh_name(seed, style, s, namer.used)', 'made = namer.settlement(s.kind)'),
 ("no redraw on a clash", W, '        if not maker.used & used:\n            break\n', '        break\n'),
 ("redraw not on the place's stream", W, 'stream(seed, "names", s.kind, s.cell, *((k,) if k else ()))', 'stream(seed, "names", s.kind, s.cell, *((k + 5,) if k else ()))'),
 ("lore in list order", W, '    for s in settlements:\n        rng = stream(seed, "lore", *((s.key,) if s.key else ()))\n', '    rng = stream(seed, "lore")\n    for s in settlements:\n'),
 ("key is the rank", W, 'return 0 if self.kind == "capital" else self.cell + 1', 'return self.id'),
 ("capital's key is its cell", W, 'return 0 if self.kind == "capital" else self.cell + 1', 'return self.cell + 1'),
 ("key is a numpy integer", W, 'cell=int(flat)))', 'cell=flat))'),
 ("city streams read the rank", "citygen/city/__init__.py", 'stream(self.seed, "city", self.s.key, *path)', 'stream(self.seed, "city", self.s.id, *path)'),
 ("boundary noise reads the rank", "citygen/city/layout.py", 'Perlin(ctx.seed, "boundary", s.key)', 'Perlin(ctx.seed, "boundary", s.id)'),
 ("dressing reads the rank", "citygen/city/dressing.py", 'plan.settlement.key', 'plan.settlement.id'),
 ("pin key by rank", W, 'places = {s.generated: s for s in settlements}', 'places = {str(s.id): s for s in settlements}'),
 ("no warning on a dead pin", W, '        if key not in places:\n', '        if False:\n'),
 ("pinned Latin keeps the Arabic", W, 's.name, s.name_ar = str(new_name), ""', 's.name = str(new_name)'),
 ("country draw skipped when pinned", W, '    name = namer.country()                         # always drawn: pinning the country\'s name renames no place\n    if cfg["world"].get("name"):\n        name = Name(cfg["world"]["name"], str(cfg["world"].get("name_ar", "")))\n',
  '    name = Name(cfg["world"]["name"], str(cfg["world"].get("name_ar", ""))) if cfg["world"].get("name") else namer.country()\n'),
 ("no feminine agreement", N, 'feminine = "descriptors_f" in n and core.endswith(tuple(n.get("feminine_endings", ())))', 'feminine = False'),
 ("feminine read from the Arabic only", N, 'feminine = "descriptors_f" in n and core.endswith(tuple(n.get("feminine_endings", ())))', 'feminine = "descriptors_f" in n and core.ar.endswith("ة")'),
 ("fixed_name needs a default", N, '(n[key] if key in n else FIXED_DEFAULTS[key])', 'n.get(key, FIXED_DEFAULTS[key])'),
 ("empty country ending fails", N, 'if lat and lat[-1] in "aeiou":', 'if lat[-1] in "aeiou":'),
 ("no length check on prefixes_ar", N, 'if len(prefixes) != len(n["prefixes_ar"].get(kind, [])):', 'if False:'),
 ("Arabic column always", L, 'ar = any(s.name_ar for s in world.settlements)', 'ar = True'),
]
rows = []
base = Path(os.environ["TMPDIR"]) / "n60_mut"
ONLY = sys.argv[3:]
for name, path, old, new in [m for m in M if not ONLY or m[0] in ONLY]:
    shutil.rmtree(base, ignore_errors=True)
    shutil.copytree(SRC, base, ignore=shutil.ignore_patterns("output", ".git", "__pycache__", ".pytest_cache"))
    p = base / path
    t = p.read_text(encoding="utf-8")
    assert t.count(old) >= 1, name
    p.write_text(t.replace(old, new), encoding="utf-8")
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    r = subprocess.run([PY, "-m", "pytest", "-q", "--tb=no", "-m", "slow or not slow", "-k", K, "-p", "no:cacheprovider"], cwd=base, env=env, capture_output=True, text=True)
    failed = sorted(set(re.findall(r"^(?:FAILED|ERROR) tests/test_citygen.py::(\S+)", r.stdout, re.M)))
    tail = r.stdout.strip().splitlines()[-1] if r.stdout.strip() else r.stderr[-200:]
    rows.append((name, failed, tail))
    print(f"{name}: {len(failed)} fail: {failed}", flush=True)
shutil.rmtree(base, ignore_errors=True)
with open(OUT, "w") as f:
    for name, failed, tail in rows:
        f.write(f"- {name}: {', '.join(failed) or 'NONE FAILS'}\n")
