"""Rivers, lakes and settlements of a world: where they meet (baseline for valleys)."""
import sys, time
import numpy as np, shapely
from shapely.geometry import LineString, Point, Polygon
sys.path.insert(0, '.')
from citygen.config import load_config
from citygen.world import generate_world
quick = sys.argv[1] == 'quick'
seed = int(sys.argv[2]) if len(sys.argv) > 2 else None
ov = {"world": {"seed": seed}} if seed is not None else None
cfg = load_config(quick=quick, overrides=ov)
t=time.perf_counter(); w = generate_world(cfg); print('world', round(time.perf_counter()-t,2),'s', w.name, w.seed, w.size)
print(len(w.settlements), 'settlements', len(w.roads), 'roads', len(w.rivers), 'rivers', len(w.lakes), 'lakes (salt', sum(k.salt for k in w.lakes), ')')
L = {r.id: LineString(r.coords) for r in w.rivers}
for r in w.rivers[:12]:
    print('river', r.id, 'pts', len(r.coords), 'len', round(L[r.id].length), 'flow', round(r.flow,1), 'seasonal', r.seasonal, 'mouth', r.mouth, r.into, 'z', round(r.profile[0],1), round(r.profile[-1],1), 'w', round(r.widths.max(),1))
print('seasonal', sum(r.seasonal for r in w.rivers), 'total km', round(sum(l.length for l in L.values())/1000))
for s in w.settlements:
    if s.kind in ('capital','city'):
        d=[(round(L[r.id].distance(Point(s.x,s.y))), r.id, round(r.flow,1), r.seasonal) for r in w.rivers]
        d.sort()
        inside=[x for x in d if x[0] < s.radius]
        lk=[(k.id, round(Polygon(k.polygon).distance(Point(s.x,s.y))), k.salt, round(Polygon(k.polygon).area/1e6,2)) for k in w.lakes if Polygon(k.polygon).distance(Point(s.x,s.y))<s.radius*1.5]
        print(s.kind, s.id, s.name, 'xy', round(s.x), round(s.y), 'r', round(s.radius), 'pop', s.population, 'z', round(s.elevation), s.biome, 'coastal', s.coastal, 'rivers within r', inside[:5], 'lakes', lk)
print('lakes')
for k in w.lakes:
    p=Polygon(k.polygon); print(k.id, 'salt' if k.salt else 'fresh', 'level', round(k.level,1), 'area', round(p.area/1e6,2), 'c', round(p.centroid.x), round(p.centroid.y))
