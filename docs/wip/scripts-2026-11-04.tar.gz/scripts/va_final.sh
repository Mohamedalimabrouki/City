#!/bin/zsh
# Final box builds, fingerprints against the base boxes, timings.
PY=/Users/mohamedalimabrouki/Desktop/City/.venv/bin/python
OUT=/tmp/claude-501/va_out
BASE=/tmp/claude-501/va_base_out
cd /tmp/claude-501/va_tree4
for b in mid:17.7,25.4,19.7,27.4 lake2:24.6,19.6,26.6,21.6 salt2:33.0,16.0,35.0,18.0 city:24.0,40.3,26.0,42.3 lakecity:7.4,2.8,9.4,4.8; do
  n=${b%%:*}; a=${b#*:}
  echo "=== box $n $a"
  /usr/bin/time -p $PY -m citygen build --area box:$a --out $OUT/$n --force 2>&1 | tail -5
  $PY tools/fingerprint.py save box_$n $BASE/$n/bodjantouna-42 | tail -1
  $PY tools/fingerprint.py compare box_$n $OUT/$n/bodjantouna-42 --allow "world,gazetteer,plan/*,tiles/*,maps/*,files/*" 2>&1 | tail -2 | cut -c1-200
done
echo "=== capital full"
/usr/bin/time -p $PY -m citygen build --area capital --out $OUT/full --force 2>&1 | tail -5
echo "=== quick fingerprint"
$PY -m citygen build --quick --force 2>&1 | tail -1
$PY tools/fingerprint.py compare before --allow "world,gazetteer,plan/*,tiles/*,maps/*,files/*" 2>&1 | tail -3 | cut -c1-200
echo "=== two hash seeds"
PYTHONHASHSEED=1 $PY -m citygen build --quick --force --out $OUT/hash1 2>&1 | tail -1
PYTHONHASHSEED=2 $PY -m citygen build --quick --force --out $OUT/hash2 2>&1 | tail -1
$PY tools/fingerprint.py save hash1 $OUT/hash1/bodjantouna-42 | tail -1
$PY tools/fingerprint.py compare hash1 $OUT/hash2/bodjantouna-42 --allow "" 2>&1 | tail -2 | cut -c1-200
echo "=== reuse"
/usr/bin/time -p $PY -m citygen build --quick 2>&1 | tail -5
echo "=== interior survey quick"
$PY tools/interior_survey.py --folder output/bodjantouna-42 2>&1 | grep -E "^(dar|compact|small|koubba|colonial|slab|villa|maison|shop):|the villa town" 
echo "=== interior survey villas"
$PY tools/interior_survey.py --folder output/bodjantouna-42 --city villas 2>&1 | grep -E "^(dar|compact|small|koubba|colonial|slab|villa|maison|shop):|the villa town"
echo "=== street survey quick"
$PY tools/street_survey.py --quick 2>&1 | tail -6
echo "=== done"
