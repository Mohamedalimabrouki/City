import sys,re,collections; sys.path.insert(0,'.')
import numpy as np, shapely
from citygen.interior import furnish as FU
from citygen.interior.context import HOUSING, city_plan, layout_of, load_build
from citygen.interior.layout import plan_interior
from citygen.interior.outside import Outside
ctx=load_build('output/bodjantouna-42',log=lambda m:None)
plan, style = city_plan(ctx), ctx.world.style
centers = shapely.get_coordinates(shapely.centroid([b.footprint for b in plan.buildings]))
d = np.hypot(centers[:, 0] - plan.settlement.x, centers[:, 1] - plan.settlement.y)
got={}
for k in np.lexsort((np.arange(len(d)), d)).tolist():
    b = plan.buildings[k]
    lay = layout_of(plan, b, style) if b.kind in HOUSING else None
    if lay is not None and len(got.setdefault(lay, [])) < 8: got[lay].append(k)
c=collections.Counter(); rooms=warned=0
for lay,ks in sorted(got.items()):
    for k in ks:
        o=Outside(ctx,plan,k); it=plan_interior(o,style); fu=FU.furnish(it,o,style,"sparse")
        rooms+=len(fu.functions); ws={w.split()[2] for w in fu.warnings if " has no " in w}; warned+=len(ws)
        for w in fu.warnings:
            if " has no " in w:
                rid=int(w.split()[2]) if w.split()[2].isdigit() else -1
                bal=''
                if 0<=rid<len(it.rooms):
                    bal=[(x.kind) for x in it.openings if x.rooms[0]==rid and x.kind in('balcony','window')]
                c[(lay,re.sub(r'\d+','N',w),str(sorted(set(bal))))]+=1
print(rooms,warned,round(100*warned/rooms,2))
for x,y in sorted(c.items(),key=lambda t:(t[0][0],-t[1])): print(y,x)
