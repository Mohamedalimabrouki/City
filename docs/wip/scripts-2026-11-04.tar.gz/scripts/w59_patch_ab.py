import re,sys
p=sys.argv[1]+"/citygen/hydro.py"; s=open(p).read()
s=s.replace("""        if wet < min_cells or (not is_salt and wet < size):
            continue                    # too little water to keep a lake: a damp hollow that drains
""","""        if is_salt:
            wet = max(wet, math.ceil(min_cells))
        elif wet < size:
            continue
""")
s=s.replace("""        water = m & (h <= level)
        if is_salt:                     # endorheic""","""        water = m & (h <= level)
        if is_salt:
            parts, _ = ndimage.label(water)
            b = np.unravel_index(np.argmin(np.where(m, h, np.inf)), h.shape)
            water = parts == parts[b]
        if is_salt:                     # endorheic""")
open(p,"w").write(s)
