import sys, collections, re
sys.path.insert(0, ".")
from citygen.config import load_config
from citygen.world import generate_world
from citygen.city import plan_city
from citygen.interior import rooms
from citygen.interior.context import BuildContext, layout_of
from citygen.interior.layout import plan_interior
from citygen.interior.outside import Outside
world = generate_world(load_config(quick=True))
plan = plan_city(world, world.capital())
ctx = BuildContext(world, [plan], world.capital())
kinds = collections.Counter()
for k in [int(v) for v in sys.argv[1].split(",")]:
    b = plan.buildings[k]
    i = plan_interior(Outside(ctx, plan, k), world.style)
    bad = rooms.check(i)
    print(k, b.kind, i.layout, f"{b.footprint.area:.0f} m2", b.floors, "floors:", [p[:70] for p in bad[:3]], len(bad))
    for p in bad:
        kinds[" ".join(w for w in p.split() if not any(c.isdigit() for c in w))[:60]] += 1
print(kinds.most_common(12))
