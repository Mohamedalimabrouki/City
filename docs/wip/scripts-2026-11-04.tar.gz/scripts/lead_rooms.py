"""Lead's review tool: hash every dwelling's rooms.json and keep its rooms.check result and CPU time.

    python lead_hash.py --root CODE --folder BUILD [--city NAME] --groups g,g --out FILE.json [--workers N]

It imports citygen from --root (a clean copy of a commit, or the tree under review), so half-made edits of
a helper never mix into a baseline. Groups as tools/interior_survey.py counts them.
"""
import argparse
import hashlib
import json
import multiprocessing
import sys
import time
from pathlib import Path

_S = {}


def _init(root: str, folder: str, city: str | None) -> None:
    sys.path.insert(0, str(Path(root).resolve()))
    from citygen.city import plan_city
    from citygen.interior.context import BuildContext, city_plan, load_build
    ctx = load_build(Path(folder), log=lambda m: None)
    if city:
        s = next(s for s in ctx.world.settlements if s.name.lower() == city.lower())
        if not any(p.settlement is s for p in ctx.plans):
            ctx = BuildContext(ctx.world, [plan_city(ctx.world, s)], s)
    _S.update(ctx=ctx, plan=city_plan(ctx, city))


def _todo(groups: tuple) -> list:
    from citygen.interior.context import layout_of
    ctx, plan = _S["ctx"], _S["plan"]
    style, front = ctx.world.style, ctx.dresser(plan).front_of
    out = []
    for k, b in enumerate(plan.buildings):
        if b.kind not in ("house", "domed", "apartments", "villa"):
            continue
        shop = b.kind == "house" and front(k)[2] == "shop"
        if (shop and "shop" in groups) or layout_of(plan, b, style) in groups:
            out.append((k, shop and "shop" in groups))
    return out


def _parts(g) -> int:
    return 0 if g.is_empty else len(getattr(g, "geoms", [g]))


def _narrow(it) -> int:
    """Ladders standing in a couloir or hall so that less than 0.8 m stays clear beside them."""
    import dataclasses
    n = 0
    for s in it.stairs:
        names = [f.name for f in dataclasses.fields(s)]
        kind, spot, lo = getattr(s, names[0]), getattr(s, names[1]), getattr(s, names[2])
        if kind != "ladder":
            continue
        for r in it.rooms:
            if r.floor in (lo, lo + 1) and r.type in ("couloir", "hall") and r.polygon.intersection(spot).area > 0.05:
                whole = r.polygon.buffer(-0.399, join_style="mitre")
                free = r.polygon.difference(spot).buffer(-0.399, join_style="mitre")
                n += _parts(free) != _parts(whole)
    return n


def _one(job: tuple) -> tuple:
    from citygen.interior import rooms as R
    from citygen.interior.layout import plan_interior
    from citygen.interior.outside import Outside
    k, shop = job
    ctx, plan = _S["ctx"], _S["plan"]
    t = time.process_time()
    try:
        it = plan_interior(Outside(ctx, plan, k), ctx.world.style)
    except Exception as e:                                # a crash is a finding
        return k, {"g": "shop" if shop else "?", "crash": type(e).__name__}
    cpu = time.process_time() - t
    text = json.dumps(it.to_json(), sort_keys=True, separators=(",", ":"))
    bad = R.check(it)
    types = {}
    for r in it.rooms:
        types[r.type] = types.get(r.type, 0) + 1
    return k, {"g": "shop" if shop else it.layout, "h": hashlib.sha1(text.encode()).hexdigest()[:16],
               "ok": not bad, "n": len(bad), "cpu": round(cpu, 3), "types": types, "flats": len(it.flats),
               "ladders": sum(s.kind == "ladder" for s in it.stairs), "narrow": _narrow(it)}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--folder", required=True)
    ap.add_argument("--city")
    ap.add_argument("--groups", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--workers", type=int, default=3)
    a = ap.parse_args()
    groups = tuple(g for g in a.groups.split(",") if g)
    t0 = time.time()
    _init(a.root, a.folder, a.city)
    jobs = _todo(groups)
    res = {}
    with multiprocessing.get_context("spawn").Pool(a.workers, initializer=_init,
                                                   initargs=(a.root, a.folder, a.city)) as pool:
        for k, r in pool.imap_unordered(_one, jobs, chunksize=1):
            res[str(k)] = r
    Path(a.out).write_text(json.dumps(res, sort_keys=True, indent=0))
    by = {}
    for r in res.values():
        g = by.setdefault(r["g"], [0, 0, 0, 0.0, -1])
        g[0] += 1
        g[1] += bool(r.get("ok"))
        g[2] += "crash" in r
        if r.get("cpu", 0) > g[3]:
            g[3], g[4] = r["cpu"], next(k for k, v in res.items() if v is r)
    for g, (n, ok, cr, cpu, k) in sorted(by.items()):
        print(f"{g}: {ok}/{n} pass, {cr} crashes, slowest {cpu:.2f} s CPU (No. {k})")
    print(f"{len(res)} dwellings in {time.time() - t0:.0f} s -> {a.out}")


if __name__ == "__main__":
    main()
