import sys,math; sys.path.insert(0,'.')
from citygen.interior.context import city_plan, load_build
from citygen.city.dressing import building_highs
ctx=load_build('output/bodjantouna-42',log=lambda m:None); plan=city_plan(ctx,None); d=ctx.dresser(plan)
best=[]
for k,b in enumerate(plan.buildings):
    if plan.districts[b.district].kind!='colonial' or b.kind not in('house','apartments'): continue
    c=b.footprint.centroid
    if not(6700<c.x<7100 and 11800<c.y<12700): continue
    h=float(building_highs(ctx.ground,[b])[0]); ps=d.building(k,h)
    arc=[p for p in ps if p.piece=='arcade_bay']
    if len(arc)>4:
        g=[p for p in ps if p.piece.startswith(('window_grille','tounes/window_grille')) and abs(p.z-h-1.3)<.01]
        best.append((len(arc),len(g),k,h,arc[len(arc)//2]))
best.sort(key=lambda t:-t[1])
for n,g,k,h,p in best[:3]:
    fx,fy=-math.sin(p.yaw),math.cos(p.yaw); print(n,g,k,round(h,1),round(p.x,1),round(p.y,1),round(fx,2),round(fy,2), 'cam',round(p.x+fx*11,1),round(p.y+fy*11,1),round(h+3,1))
