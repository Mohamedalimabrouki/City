"""What the `old_town` fixture's 50 houses look like now: pass, sunken, turned steps, ways."""
import sys, collections
sys.path.insert(0, ".")
import numpy as np, shapely
from citygen.config import load_config
from citygen.world import generate_world
from citygen.city import plan_city
from citygen.interior import rooms
from citygen.interior.context import BuildContext, city_plan, layout_of
from citygen.interior.layout import plan_interior
from citygen.interior.outside import Outside
from citygen.interior.plancheck import way_in, way_rooms
world = generate_world(load_config(quick=True))
plan = plan_city(world, world.capital())
ctx = BuildContext(world, [plan], world.capital())
style = world.style
centers = shapely.get_coordinates(shapely.centroid([b.footprint for b in plan.buildings]))
d = np.hypot(centers[:, 0] - plan.settlement.x, centers[:, 1] - plan.settlement.y)
want = {"dar": 20, "compact": 20, "small": 10}
out = []
for k in np.lexsort((np.arange(len(d)), d)).tolist():
    b = plan.buildings[k]
    lay = layout_of(plan, b, style) if b.kind == "house" else None
    if want.get(lay, 0) > 0:
        want[lay] -= 1
        o = Outside(ctx, plan, k)
        out.append((plan_interior(o, style), o))
    if not any(want.values()):
        break
print("got", len(out))
bad = [(i.building, i.layout, rooms.check(i)[:2]) for i, _ in out if rooms.check(i)]
print("fail", len(bad), bad)
sunk = [(i.building, i.layout) for i, _ in out if any(r.z < i.storeys[0].z - 0.05 for r in i.rooms if r.floor == 0)]
print("sunken", sunk)
turned = [(i.building, i.layout) for i, _ in out for s in i.stairs if s.kind == "steps" and s.turn]
print("turned", turned)
print("wet", sum(any(r.unit == "home" and r.type == "bit_el_ma" for r in i.rooms) for i, _ in out))
from citygen.interior.plancheck import KITCHENS, WET
faults = []
for interior, _ in out:
    types = {r.id: r.type for r in interior.rooms}
    steps_in = [s for s in interior.stairs if s.kind == "steps" and types[s.rooms[0]] in WET + KITCHENS]
    court = interior.layout == "dar"
    if way_in(interior) or (court and (not way_rooms(interior) or rooms.sees_court(interior))) or steps_in:
        faults.append((interior.building, interior.layout, way_in(interior)))
print("way faults", len(faults), faults)
with_bath = [i for i, _ in out if any(r.unit == "home" and r.type == "bit_el_ma" for r in i.rooms)]
print("with bath", len(with_bath), "crossed", [i.building for i in with_bath if {r.id for r in i.rooms if r.type == "bit_el_ma"} & set(way_rooms(i))])
