import sys, numpy as np
sys.path.insert(0,'.')
from citygen.config import load_config
from citygen.world import generate_world
w=generate_world(load_config(overrides={"world":{"seed":42}}))
c=w.carve; t=w.terrain
want=int(sys.argv[1])
s=[s for s,l in zip(c.shores,w.lakes) if l.id==want][0]
b=s.polygon.boundary; L=b.length
fs=np.arange(0,L,50.)
P=np.array([b.interpolate(f).coords[0] for f in fs])
Pn=np.array([b.interpolate((f+10)%L).coords[0] for f in fs])
d=Pn-P; d/=np.hypot(*d.T)[:,None]; n=np.stack([d[:,1],-d[:,0]],1)
import shapely
test=P+n*30
ins=shapely.contains_xy(s.polygon,test[:,0],test[:,1])
n[ins]*=-1  # now outward
out=P+n*300
h=np.asarray(t.height(out[:,0],out[:,1]))-s.level
o=np.argsort(-h)[:8]
print('level',s.level,'bounds',[int(v) for v in s.polygon.bounds])
for k in o: print([int(v) for v in P[k]],'out',[round(float(v),2) for v in n[k]],'h300',round(float(h[k]),1))
