import sys, math, collections
sys.path.insert(0, "."); sys.path.insert(0, "tests")
import numpy as np, shapely
from shapely.strtree import STRtree
from citygen.config import load_config
from citygen.world import generate_world
from citygen.city import plan_city
from citygen.city.ground import Ground
from citygen.mesh.tile import TileContext, build_tile
import test_citygen as T
world = generate_world(load_config(quick=True))
plan = plan_city(world, world.capital())
tc = TileContext(world, [plan])
s = world.capital()
i, j = int(s.x // tc.size), int(s.y // tc.size)
mb, placements = build_tile(tc, i, j)
covers = tc.covers[0]
stretches = covers.all()
quads = [q for st in stretches for q in T._roof_quads(st)]
tree = STRtree([q[0] for q in quads])
hooks = {(round(q[0], 6), round(q[1], 6), round(z, 6)) for st in stretches for x, z in st.lanterns for q in [st.frame(x)[0]]}
for p in placements:
    box, z0, z1 = T._footprint_box(tc.kit, p, p.z)
    for q in tree.query(box, predicate="intersects"):
        _, spring, top = quads[int(q)]
        if (round(p.x, 6), round(p.y, 6), round(p.z, 6)) in hooks: continue
        if z0 < top and z1 > spring + 1e-6:
            poly = quads[int(q)][0]
            print(p.piece, "at", round(p.x, 2), round(p.y, 2), "z", round(p.z, 2), "z0,z1", round(z0, 2), round(z1, 2), "spring", round(spring, 2), "top", round(top, 2),
                  "trunk to roof quad", round(poly.distance(shapely.Point(p.x, p.y)), 2), "overlap area", round(box.intersection(poly).area, 2), "box area", round(box.area, 2))
            pts = [t for t in plan.trees if math.hypot(t.x - p.x, t.y - p.y) < 2]
            print("  planned tree nearby:", [(t.kind, round(t.height, 1)) for t in pts])
            d = [dd for dd in plan.districts if dd.polygon.contains(shapely.Point(p.x, p.y))]
            print("  district", [(dd.kind, dd.name) for dd in d], "street souk?", )
            near = sorted((plan.streets[k].line.distance(shapely.Point(p.x, p.y)), plan.streets[k].kind, k) for k in range(len(plan.streets)))[:3]
            print("  nearest streets", [(round(a, 1), b, c) for a, b, c in near])
            break
