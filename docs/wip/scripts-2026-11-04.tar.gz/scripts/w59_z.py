import sys, json, collections
sys.path.insert(0, ".")
import numpy as np, shapely
from citygen.config import load_config
from citygen.world import generate_world
from citygen.city import plan_city
from citygen.city.ground import Ground, STREET_LIFT
from citygen.export.streets import streets_json
w = generate_world(load_config(quick=True)); plan = plan_city(w, w.capital()); ground = Ground(w, [plan])
data = streets_json(w, plan, ground)
nodes, edges = data["nodes"], data["edges"]
xy = np.array([[n["x"], n["y"]] for n in nodes]); z = np.array([n["z"] for n in nodes])
inc = collections.defaultdict(list)
for e in edges:
    for i in (e["from"], e["to"]): inc[i].append(e)
lift = np.array([max(STREET_LIFT[e["kind"]] for e in inc[n["id"]]) for n in nodes])
h = np.asarray(ground.height(xy[:,0], xy[:,1]))
over = z - h - lift
print("nodes", len(nodes), "|over|<0.015:", int((abs(over)<0.015).sum()), "low:", int((over<-0.015).sum()), "high:", int((over>0.015).sum()))
low = np.flatnonzero(over < -0.015)
pts = shapely.points(xy[:,0], xy[:,1])
walk = np.zeros(len(nodes),bool); apron = np.zeros(len(nodes),bool)
if ground.walk_tree is not None: walk[np.unique(ground.walk_tree.query(pts, predicate="intersects")[0])] = True
if ground.apron_tree is not None: apron[np.unique(ground.apron_tree.query(pts, predicate="intersects")[0])] = True
lifted = np.asarray(ground.lift(xy[:,0], xy[:,1]))
print(collections.Counter((bool(walk[i]), bool(apron[i]), round(float(lifted[i]),2), tuple(sorted({e["kind"] for e in inc[i]})), nodes[i]["degree"]) for i in low).most_common(20))
hi = np.flatnonzero(over > 0.015)
print(collections.Counter((bool(walk[i]), bool(apron[i]), round(float(lifted[i]),2), tuple(sorted({e["kind"] for e in inc[i]}))) for i in hi).most_common(12))
print("off-ribbon lifted==0 nodes:", int((lifted==0).sum()))
print("over for no walk/apron:", over[~walk & ~apron].min(), over[~walk & ~apron].max())
print("min/max apron over", over[apron].min() if apron.any() else None, over[apron].max() if apron.any() else None)
print("min/max walk over", over[walk].min() if walk.any() else None, over[walk].max() if walk.any() else None)
