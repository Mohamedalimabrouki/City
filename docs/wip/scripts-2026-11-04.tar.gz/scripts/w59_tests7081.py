p = "tests/test_citygen.py"
s = open(p, encoding="utf-8").read()
def sub(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a)
    s = s.replace(a, b)

# prompt 81
sub('''    eras = world.style["lore"]["eras"]
    founded = eras.index(plan.settlement.founded)
    for d in plan.districts:
''', '''    eras = world.style["lore"]["eras"]
    founded = eras.index(plan.settlement.founded)
    words = world.style["history"]
    for d in plan.districts:
''')
sub('''        assert all(eras.index(e) >= founded for e in eras if e in d.history)
''', '''        told = [e for e in eras if words["era_in"][e] in d.history or words["era_since"][e] in d.history]
        assert told and all(eras.index(e) >= founded for e in told), d.history
''')
sub('''def test_fingerprint_tool(tmp_path, monkeypatch):
''', '''def test_a_new_history_template_changes_no_sentence(world, plan):
    """Every choice of a history has its own stream: a list the sentences never use moves no other draw."""
    import copy
    from citygen.city import CityContext
    from citygen.city.history import histories
    ctx = CityContext(world, plan.settlement)
    ctx.style = dict(world.style, history=copy.deepcopy(world.style["history"]))
    ctx.style["history"]["fact"] = {"aside": ["One.", "Two.", "Three."], **ctx.style["history"]["fact"]}
    again = copy.copy(plan)
    again.districts = [copy.copy(d) for d in plan.districts]
    histories(ctx, again)
    assert [d.history for d in again.districts] == [d.history for d in plan.districts]


def test_history_words(world):
    """The style words every era, the eras' names stay in those words, and plurals follow the style's endings."""
    from citygen.city.history import _era_phrase, _plural
    words = world.style["history"]
    for era in world.style["lore"]["eras"]:
        assert era in words["era_in"][era] and era in words["era_since"][era]
    assert _era_phrase(words, "era_in", "the Flood") == "in the time of the Flood" and _era_phrase(words, "era_in", "") == ""
    assert [_plural(words, w) for w in ("fisherman", "teacher", "secretary", "coach")] == \\
        ["fishermen", "teachers", "secretaries", "coaches"]


def test_a_history_landmark_belongs_to_the_district_it_stands_in():
    """A point near a shared border goes to the district it lies in, not to the lower number within reach."""
    from types import SimpleNamespace as NS
    from shapely.geometry import box
    from citygen.city.history import _Facts
    facts = _Facts.__new__(_Facts)
    facts.plan, facts.inside = NS(districts=[NS(id=0, polygon=box(0, 0, 10, 10)), NS(id=1, polygon=box(10, 0, 20, 10))]), 1.0
    assert [facts.district_at(x, 5.0) for x in (9.5, 10.5, 20.5, 25.0)] == [0, 1, 1, None]


def test_fingerprint_tool(tmp_path, monkeypatch):
''')

# prompt 70
sub('''    from citygen.export.streets import road_links, street_graph
    nodes, edges = street_graph(plan.streets, float(world.cfg["streets"]["graph_grid"]))
''', '''    from citygen.export.streets import road_links, street_graph
    nodes, edges = street_graph(plan.streets, float(world.cfg["street_graph"]["grid"]))
''')
sub('''    drawn = sum(st.line.length for st in plan.streets)
    assert drawn - 1.0 < total < drawn * 1.01     # impasse mouths add their stubs to the street centers
''', '''    drawn = shapely.unary_union([st.line for st in plan.streets]).length   # a street under a boulevard counts once
    assert drawn - 1.0 < total < drawn * 1.01     # impasse mouths add their stubs to the street centers
''')
sub('''@pytest.mark.slow  # sidewalk widths of the whole city, about 3 s
def test_streets_json_lists_nodes_on_the_drawn_street_and_measured_edges(world, plan, ground):
    from citygen.export.streets import streets_json
''', '''def test_street_graph_nodes_a_mouth_exactly_on_its_street():
    """A mouth on the center line itself needs no stub, but it must still become a vertex of that street:
    snapped apart, the two lines of this case pass each other 3 cm off and the plain union finds no junction."""
    from citygen.city.model import Street
    from citygen.export.streets import street_graph
    from shapely.geometry import LineString
    street = LineString([(0.01, 0.01), (90.01, 37.01)])
    mouth = street.interpolate(0.164, normalized=True)
    assert mouth.distance(street.interpolate(street.project(mouth))) == 0.0
    lane = LineString([(mouth.x, mouth.y), (mouth.x - 8.0, mouth.y + 20.0)])
    nodes, edges = street_graph([Street("street", 8.0, street), Street("impasse", 3.0, lane)], 0.05)
    assert len(nodes) == 4 and len(edges) == 3


@pytest.mark.slow  # sidewalk widths of the whole city, about 3 s
def test_streets_json_lists_nodes_on_the_drawn_street_and_measured_edges(world, plan, ground):
    from citygen.city.ground import STREET_LIFT
    from citygen.export.streets import streets_json
''')
sub('''    assert np.allclose([n["z"] for n in nodes], ground.surface(xy[:, 0], xy[:, 1]), atol=0.01)
    degree = collections.Counter(i for e in edges for i in (e["from"], e["to"]))
''', '''    z = np.array([n["z"] for n in nodes])
    assert np.allclose(z, ground.surface(xy[:, 0], xy[:, 1]), atol=0.01)
    lift = collections.Counter()   # the highest ribbon meeting at each node, from the graph's own street kinds
    for e in edges:
        for i in (e["from"], e["to"]):
            lift[i] = max(lift[i], STREET_LIFT[e["kind"]])
    over = z - ground.height(xy[:, 0], xy[:, 1]) - np.array([lift[n["id"]] for n in nodes])
    curb = float(world.style["streets"]["curb_height"])
    assert over.min() > -0.015 and over.max() < curb + 0.1, (over.min(), over.max())   # on the ribbon, or a curb up
    degree = collections.Counter(i for e in edges for i in (e["from"], e["to"]))
''')
sub('''        subprocess.run([sys.executable, "-c", code, str(tmp_path / f"{name}.json")], cwd=root,
                       env={**os.environ, "PYTHONHASHSEED": seed}, check=True, capture_output=True)
    assert (tmp_path / "a.json").read_bytes() == (tmp_path / "b.json").read_bytes()
''', '''        r = subprocess.run([sys.executable, "-c", code, str(tmp_path / f"{name}.json")], cwd=root,
                           env={**os.environ, "PYTHONHASHSEED": seed}, capture_output=True)
        assert r.returncode == 0, r.stderr.decode()[-2000:]
    assert (tmp_path / "a.json").read_bytes() == (tmp_path / "b.json").read_bytes()
''')
open(p, "w", encoding="utf-8").write(s)
