# merge-3d (lead, 3 November, 21:20 UTC): one merge branch so Ali can see the work in 3D, only if nothing gets worse
Folder: /tmp/claude-501/merge-3d (a detached worktree on main 2ddab41; `main` = branch `claude/procedural-city-generator-xop72h`). Work only there. Python `/Users/mohamedalimabrouki/Desktop/City/.venv/bin/python`. Never the em dash character. Commits end with `Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>`. Push with `git push origin HEAD:refs/heads/wip/merge-3d` (github.com in the Bash call's allowed_domains) after every step that works, so a cut-off loses little; if a "save now" message comes, commit and push at once. Do not edit WORKLOG, ROADMAP, HANDOFF or SPEC except to resolve merge conflicts in them. Never start Blender and never run tools/make_blend.py (the lead does).

## 1. Baseline on main (before any merge)
`build --quick`, then `tools/fingerprint.py save main3d`, then the interior survey (`tools/interior_survey.py`, read its help): rooms.check pass counts per group and the warned-room share (furnishing). Check that you get the WORKLOG's counts (slab 247/353, colonial 3/270, maison 499/616, villa 167/178, old town at its bars); if not, find out why before going on. Keep the table.

## 2. Merge, in this order
`git fetch origin 'refs/heads/wip/*:refs/remotes/origin/wip/*'`, then for each: `git merge --no-ff -m "Merge wip/<b>: <what it brings>" origin/wip/<b>`; after each, the quick tests of its area, then push.
1. merge-prep (speed-n, flats-j, furnish-m: prompt 54 round 3)
2. fix-side-54, test-scrap-hall, test-cache-warm, fix-dar-is (small branches on merge-prep)
3. fix-materials (the furniture's copper, terracotta, net_green renamed copper_ware, clay_red, twine_green)
4. fix-hide, fix-brass, fix-goods, fix-textile (each on furnish-m e871984, with its kit-* commits)
5. colonial-k, villas-o, test-villa-369, fix-little
Conflicts: tests at the end of a file keep both sides; docs keep both sides; in `kit_old.py` and `styles/maghreb.toml` keep both changes. Mind fix-materials against the kit branches: kit-hide changed the interior `net_green`, which fix-materials renamed `twine_green`; the merged palette has one `twine_green` with kit-hide's new values, and every furniture piece must use the new names (grep copper, terracotta, net_green after step 4; fix-materials' shared-name test must pass). Notes for each branch: `docs/wip/<b>.md` and the reviews `docs/wip/rev-*.md` / `review-*.md` on their branches.

## 3. Three known small fixes (one commit each, each with a test)
- hidoura edge folds in about 1 seed of 5 (rev-fix-hide, kit_old.py about 857): jitter along the radius only; test: no fold over 200 seeds (the reviewer's script: scratchpad `rev-fix-hide/folds.py`).
- cushion cord normals face the wall (rev-fix-textile, kit_old.py about 359 and 389): give the cord its own round normals; test: cord vertex normals agree with their faces.
- the 8-sided brass bowl reaches past its 0.30 m half-depth (rev-fix-brass, kit_old.py about 1021); test that the piece stays in its table size.

## 4. Gates (all must hold; a branch that breaks one is taken out again, and you say why)
- full `pytest -q` passes, and `pytest -q -m slow` passes;
- `build --quick` finishes;
- `tools/fingerprint.py compare main3d`: explain every changed part by the branch that changes it; nothing unexplained;
- the interior survey again: no group's pass count goes down and the warned-room share does not go up (say the numbers before and after).

## 5. Finish
`docs/wip/merge-3d.md`: what was merged, each conflict and how you solved it, the three fixes, test results, the fingerprint changes and their causes, the survey table before and after, anything left out and why. Push. Report in a few lines.
