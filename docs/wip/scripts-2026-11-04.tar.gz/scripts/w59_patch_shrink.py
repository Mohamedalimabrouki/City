import sys
p = sys.argv[1]; s = open(p).read()
def sub(a, b):
    global s
    assert s.count(a) == 1, a
    s = s.replace(a, b)
sub('''        if not basins:                  # a pit that failed once fails again, so this ends
            return _Routing(n, c, sea.ravel(), flat, recv, flow, catch, lake_id, salt, lakes)
''', '''        if not basins:                  # a pit that failed once fails again, so this ends
            changed = False
            per = float(rc["lake_area_per_flow"]); least = math.ceil(float(rc["lake_min_area"]) * 1e6 / (cell * cell))
            for k, (sy, sx, m, spill) in list(records.items()):
                grid = lake_id.reshape(n, n)
                now = grid[sy, sx] == k
                inflow = float(flow[lake_id == k].sum())
                need = max(math.ceil(per * inflow * 1e6 / (cell * cell)), least)
                if need >= np.count_nonzero(now):
                    continue
                h, g = H[sy, sx], gid[sy, sx]
                water, level = _water(h, now, need, float(h[now].max()))
                freed = now & ~water
                if not freed.any():
                    continue
                lake_id[g[freed]] = -1
                salt[g[freed]] = False
                grid = lake_id.reshape(n, n)
                sinks = (grid[sy, sx] >= 0) & salt.reshape(n, n)[sy, sx] & m
                sub_f, sub_r = _flood(h, sinks, wall=~m, border=False, eps=EPS * 1e-3)
                rest = (m & ~sinks).ravel()
                gi = g.ravel()
                recv[gi[rest]] = gi[sub_r[rest]]
                flat[gi[m.ravel()]] = np.where(rest, sub_f.ravel(), h.ravel())[m.ravel()]
                wy, wx = slice(max(sy.start - 1, 0), sy.stop + 1), slice(max(sx.start - 1, 0), sx.stop + 1)
                lakes[k] = _lake(k, lake_id.reshape(n, n)[wy, wx] == k, H[wy, wx], c[wx], c[wy], level, True)
                changed = True
            if changed:
                continue
            return _Routing(n, c, sea.ravel(), flat, recv, flow, catch, lake_id, salt, lakes)
''')
sub('''    gid = np.arange(n * n).reshape(n, n)
    while True:
''', '''    gid = np.arange(n * n).reshape(n, n)
    records = {}
    while True:
''')
sub('''            lake_id[g[water]] = k
            salt[g[water]] = is_salt
''', '''            lake_id[g[water]] = k
            salt[g[water]] = is_salt
            if is_salt:
                records[k] = (sy, sx, m, float(flat[g][m].max()))
''')
open(p, "w").write(s)
