"""What test_furnish_required_share counts, with the warnings by what is missing. Run from a tree; argument: a quick build."""
import collections
import sys
from pathlib import Path

import numpy as np
import shapely

sys.path.insert(0, '.')
from citygen.interior import furnish as FU
from citygen.interior.context import HOUSING, city_plan, layout_of, load_build
from citygen.interior.layout import plan_interior
from citygen.interior.outside import Outside

ctx = load_build(Path(sys.argv[1]), log=lambda m: None)
plan, style = city_plan(ctx), ctx.world.style
centers = shapely.get_coordinates(shapely.centroid([b.footprint for b in plan.buildings]))
d = np.hypot(centers[:, 0] - plan.settlement.x, centers[:, 1] - plan.settlement.y)
got = {}
for k in np.lexsort((np.arange(len(d)), d)).tolist():
    b = plan.buildings[k]
    lay = layout_of(plan, b, style) if b.kind in HOUSING else None
    if lay is not None and len(got.setdefault(lay, [])) < 8:
        got[lay].append(k)
rooms = warned = 0
what = collections.Counter()
by = collections.Counter()
for lay, ks in sorted(got.items()):
    for k in ks:
        outside = Outside(ctx, plan, k)
        interior = plan_interior(outside, style)
        fu = FU.furnish(interior, outside, style, "sparse")
        rooms += len(fu.functions)
        w = {x.split()[2] for x in fu.warnings if " has no " in x}
        warned += len(w)
        by[lay] += len(w)
        for x in fu.warnings:
            if " has no " in x:
                what[" ".join(x.split()[3:7])] += 1
print('warned', warned, 'rooms', rooms, round(100 * warned / rooms, 2), '%')
print('by layout', dict(by))
print(what.most_common(12))
