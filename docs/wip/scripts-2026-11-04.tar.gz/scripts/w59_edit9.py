p = "tests/test_hydro.py"
s = open(p, encoding="utf-8").read()
a = '''    land, cfg = _Valley(0.9), _little_water()
    rivers, lakes = drainage(land, cfg)
    g = _routing(land, cfg["rivers"])
    X, Y = np.meshgrid(g.c, g.c)
    assert len(lakes) == 1 and not lakes[0].salt
    assert np.count_nonzero(g.lake_id == 0) > 100                  # the whole hollow, not its balanced 23 cells
    assert np.all((land.height(X, Y).ravel() >= lakes[0].level) | (g.lake_id == 0)
                  | ((X.ravel() - 15000.0) ** 2 + (Y.ravel() - 10000.0) ** 2 > 1000.0 ** 2))
    assert [r.mouth for r in rivers if r.coords[0, 0] > 15000.0 and r.flow > 10.0] == ["border"]   # it spills on
'''
b = '''    land, cfg = _Valley(0.9), _little_water()
    rivers, lakes = drainage(land, cfg)
    g = _routing(land, cfg["rivers"])
    assert len(lakes) == 1 and not lakes[0].salt
    assert np.count_nonzero(g.lake_id == 0) > 100                  # the whole hollow, not its balanced 23 cells
    shore = Polygon(lakes[0].polygon).buffer(float(cfg["rivers"]["cell"]))
    outlet = [r for r in rivers if shore.contains(Point(r.coords[0])) and r.mouth != "lake"]
    assert len(outlet) == 1 and outlet[0].mouth == "border" and abs(outlet[0].profile[0] - lakes[0].level) < 0.1
'''
assert s.count(a) == 1
open(p, "w", encoding="utf-8").write(s.replace(a, b))
