"""World gates of the valleys step, on one world: python va_gates.py SEED quick|full"""
import json, sys, time
import numpy as np, shapely
from shapely.geometry import LineString, Point, Polygon
from shapely.ops import unary_union
sys.path.insert(0, '.')
from citygen.config import load_config
from citygen.hydro import along, channel
from citygen.world import generate_world

seed, size = int(sys.argv[1]), sys.argv[2]
cfg = load_config(quick=size == 'quick', overrides={"world": {"seed": seed}})
t = time.perf_counter(); w = generate_world(cfg); dt = time.perf_counter() - t
c = w.carve
rc = cfg["rivers"]
out = {"seed": seed, "size": size, "country_s": round(dt, 2), "rivers": len(w.rivers), "lakes": len(w.lakes),
       "salt": sum(k.salt for k in w.lakes), "seasonal": sum(r.seasonal for r in w.rivers),
       "river_km": round(sum(LineString(r.coords).length for r in w.rivers) / 1000), "levee_segments": len(c.levees)}
# lakes and roads
lakes = unary_union([Polygon(k.polygon).buffer(0) for k in w.lakes]) if w.lakes else None
zones = unary_union([sh.zone for sh in c.shores]) if c.shores else None
lines = [LineString(r.coords) for r in w.roads]
out["road_km"] = round(sum(l.length for l in lines) / 1000)
out["roads_in_lake"] = sum(l.intersects(lakes) for l in lines) if lakes is not None else 0
out["road_m_in_lake"] = round(sum(l.intersection(lakes).length for l in lines), 1) if lakes is not None else 0
out["roads_in_drawn_water"] = sum(l.intersects(zones) for l in lines) if zones is not None else 0
# road crossings of beds: the channel and banks as polygons
beds = []
for r in w.rivers:
    ch = channel(r, rc)
    radii = 0.5 * (ch["half"][:-1] + ch["half"][1:]) + ch["lip"][:-1]
    seg = shapely.linestrings(np.stack([r.coords[:-1], r.coords[1:]], axis=1))
    beds.append(shapely.buffer(seg, radii, quad_segs=2))
bed = unary_union(np.concatenate(beds))
shapely.prepare(bed)
cross = []
for k, l in enumerate(lines):
    hit = l.intersection(bed)
    for g in getattr(hit, "geoms", [hit]):
        if not g.is_empty:
            cross.append((round(g.length, 1), k))
cross.sort(reverse=True)
out["crossings"] = len(cross); out["longest_crossings"] = cross[:6]; out["over_60"] = sum(a > 60 for a, _ in cross)
# centers
wet = [s for s in w.settlements if s.kind in ("town", "village") and bool(c.wet(s.x, s.y)[0])]
out["towns_villages_on_water"] = len(wet)
out["cities_on_water"] = [s.name for s in w.settlements if s.kind in ("capital", "city") and bool(c.wet(s.x, s.y)[0])]
# water
rises = max((float(np.diff(r.surface).max()) for r in w.rivers), default=0.0)
out["water_rises_max"] = rises
worst = {"sea": 0.0, "lake": 0.0, "basin": 0.0, "river": 0.0}
for r in w.rivers:
    z = float(r.surface[-1])
    if r.mouth == "sea": worst["sea"] = max(worst["sea"], abs(z))
    elif r.mouth in ("lake", "basin"): worst[r.mouth] = max(worst[r.mouth], abs(z - w.lakes[r.into].level))
    elif r.mouth == "river" and r.into is not None:
        m = w.rivers[r.into]
        at = LineString(m.coords).project(Point(r.coords[-1]))
        worst["river"] = max(worst["river"], abs(z - float(np.interp(at, along(m.coords), m.surface))))
out["step_at_mouth"] = {k: round(v, 4) for k, v in worst.items()}
out["outlet_step"] = round(max((abs(float(r.surface[0]) - w.lakes[r.source].level) for r in w.rivers if r.source is not None), default=0.0), 4)
# banks against the water at the ground: sampled along every wet river
under = []
n = 0
for r in w.rivers:
    if r.seasonal: continue
    ch = channel(r, rc)
    rib = c.ribbons[r.id]
    d = np.gradient(r.coords, axis=0); nrm = np.stack([-d[:, 1], d[:, 0]], 1) / np.maximum(np.hypot(*d.T), 1e-9)[:, None]
    on = (rib.along >= rib.start) & (rib.along <= rib.end) & (ch["half"] > 0.5)
    if not on.any(): continue
    for side in (-1.0, 1.0):
        p = r.coords[on] + nrm[on] * (side * (ch["half"][on] + ch["lip"][on]))[:, None]
        h0 = w.terrain.height(p[:, 0], p[:, 1])
        h = c.ground(p[:, 0], p[:, 1], h0)
        over = (h - r.surface[on])[c.past_bank(p[:, 0], p[:, 1]) > -0.3]   # a point in another channel is no bank
        n += len(over); under.append(over)
over = np.concatenate(under) if under else np.zeros(1)
out["bank_over_water"] = {"points": n, "min": round(float(over.min()), 3), "p1": round(float(np.percentile(over, 1)), 3), "p50": round(float(np.median(over)), 3), "p99": round(float(np.percentile(over, 99)), 3), "max": round(float(over.max()), 3), "below_0.1": int((over < 0.1).sum()), "below_0": int((over < 0).sum())}
print(json.dumps(out))
json.dump([{ "name": s.generated or s.name, "kind": s.kind, "x": s.x, "y": s.y, "cell": s.cell} for s in w.settlements], open(f"/tmp/claude-501/va_tmp/world_{seed}_{size}.json", "w"))
