import sys, time, math
sys.path.insert(0, sys.argv[1])
import numpy as np
from citygen.config import load_config
from citygen.terrain import Terrain
from citygen import hydro
from citygen.hydro import drainage
for quick in (True, False):
    cfg = load_config(quick=quick)
    t = time.perf_counter(); ter = Terrain(42, cfg); t1 = time.perf_counter()
    rivers, lakes = drainage(ter, cfg); t2 = time.perf_counter()
    print("quick" if quick else "full", "size", ter.size, "terrain", round(t1-t,2), "drainage", round(t2-t1,2), "rivers", len(rivers), "lakes", len(lakes), "salt", sum(k.salt for k in lakes), "seasonal", sum(r.seasonal for r in rivers))
    from collections import Counter
    print(Counter(r.mouth for r in rivers))
    over, under = [], []
    for r in rivers:
        g = ter.height(r.coords[:,0], r.coords[:,1])
        d = r.profile - g
        over.append((float(d.max()), r.id, r.mouth, float(r.flow), len(r.coords), float((d>5).mean()), float((d>20).mean())))
        under.append((float((-d).max()), r.id))
    over.sort(reverse=True)
    print("bed above ground, worst:", [(round(a,1),b,c,round(e,1),f,round(g,2),round(h,2)) for a,b,c,e,f,g,h in over[:15]])
    print("rivers with bed >5 m above ground:", sum(o[0]>5 for o in over), ">20:", sum(o[0]>20 for o in over), ">50:", sum(o[0]>50 for o in over))
    under.sort(reverse=True)
    print("bed under ground worst:", [(round(a,1),b) for a,b in under[:8]])
