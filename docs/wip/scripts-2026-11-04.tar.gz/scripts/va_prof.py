import sys, time, tempfile, pathlib, cProfile, pstats
sys.path.insert(0,'.')
from citygen.config import load_config
from citygen.world import generate_world
from citygen.mesh.tile import TileContext, export_tile
cfg=load_config(); w=generate_world(cfg)
tc=TileContext(w,[])
keys=[(i,j) for i in range(34,40) for j in range(49,55)]
d=pathlib.Path(tempfile.mkdtemp(dir='/tmp/claude-501/va_tmp'))
for i,j in keys: export_tile(tc,i,j,d)
pr=cProfile.Profile(); pr.enable()
for i,j in keys: export_tile(tc,i,j,d)
pr.disable()
s=pstats.Stats(pr); s.sort_stats('cumulative').print_stats(28)
