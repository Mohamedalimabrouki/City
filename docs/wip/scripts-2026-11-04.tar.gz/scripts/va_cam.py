"""Ground heights for cameras: va_cam.py x y"""
import sys; sys.path.insert(0,'.')
import numpy as np
from citygen.config import load_config
from citygen.world import generate_world
w=generate_world(load_config())
c=w.carve
for a in sys.argv[1:]:
    x,y=map(float,a.split(','))
    print(a, 'terrain', round(float(w.terrain.height(x,y)),1), 'carved', round(float(c.ground(np.array([x]),np.array([y]),np.array([float(w.terrain.height(x,y))]))[0]),1))
r=w.rivers[37]
print(r.id, r.mouth, r.flow, r.widths.max(), np.round(r.coords[::40],0).tolist()[:12], np.round(r.surface[::40],1).tolist()[:12])
for k in w.lakes:
    if k.id in (1,16,4): print(k.id,k.salt,k.level,k.polygon.min(axis=0),k.polygon.max(axis=0))
