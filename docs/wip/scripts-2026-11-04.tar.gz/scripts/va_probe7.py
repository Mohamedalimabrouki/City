import sys, numpy as np, shapely
from shapely.geometry import LineString, Point, Polygon
sys.path.insert(0,'.')
from citygen.config import load_config
from citygen.hydro import channel, along
from citygen.world import generate_world
w=generate_world(load_config(overrides={"world":{"seed":7}})); c=w.carve
for rid,a,b in ((16,10,34),(60,20,36)):
    r=w.rivers[rid]; g=w.terrain.height(*r.coords.T)
    print(rid,'source',r.source,'level',round(w.lakes[r.source].level,1),'flow',round(r.flow,1),'surface',np.round(r.surface[a:b],1).tolist())
    print('ground',np.round(g[a:b],1).tolist())
    print('profile',np.round(r.profile[a:b],1).tolist())
    p=Polygon(w.lakes[r.source].polygon); print('dist to shore',[round(p.distance(Point(q))) for q in r.coords[a:b:3]], 'joins', [(t.id, round(float(t.surface[-1]),1)) for t in w.rivers if t.mouth=='river' and t.into==rid][:6])
