def edit(p, pairs):
    s = open(p, encoding="utf-8").read()
    for a, b in pairs:
        assert s.count(a) == 1, (s.count(a), a)
        s = s.replace(a, b)
    open(p, "w", encoding="utf-8").write(s)
edit("citygen/hydro.py", [
('''    flat: np.ndarray     # (n * n,) heights that strictly fall from each cell to `recv` (the flood's, lakes at rest)
''', '''    flat: np.ndarray     # (n * n,) the flood's heights, closed basins re-flooded: each cell above its `recv`
'''),
('''    labels, basins = _basins(np.where(sea, 0.0, filled - H), H, filled, biome, flow.reshape(n, n), cell, rc)
''', '''    labels, basins = _basins(np.where(sea, 0.0, filled - H), H, biome, flow.reshape(n, n), cell, rc)
'''),
('''def _basins(depth, H, filled, biome, flow, cell, rc) -> tuple:
''', '''def _basins(depth, H, biome, flow, cell, rc) -> tuple:
'''),
])
edit("citygen/defaults.toml", [
('''lake_min_area = 0.5       # ...and larger than this many square kilometers (smaller pits just drain)
''', '''lake_min_area = 0.5       # ...and larger than this many square kilometers (smaller pits just drain)
basin_depth = 0.01        # meters: cells the flood fills deeper than this make up a basin
'''),
('''lake_area_per_flow = 0.04 # square kilometers of lake surface that evaporate the water of 1 km2 of catchment
''', '''lake_area_per_flow = 0.04 # square kilometers of lake surface that evaporate the water of 1 km2 of catchment
map_line = [0.8, 6.0]     # country map: a river's line is [0] + its width in meters / [1] pixels wide (at 1800 px)
'''),
])
edit("citygen/export/maps.py", [
('''    scale = width / 1800
    for lake in world.lakes:
''', '''    scale = width / 1800
    base, per_px = (float(v) for v in world.cfg["rivers"]["map_line"])
    for lake in world.lakes:
'''),
('''        px_w = np.maximum(1, np.round((0.8 + r.widths / 6.0) * scale)).astype(int)
''', '''        px_w = np.maximum(1, np.round((base + r.widths / per_px) * scale)).astype(int)
'''),
])
