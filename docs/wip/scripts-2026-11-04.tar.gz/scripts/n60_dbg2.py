import sys, math, collections
sys.path.insert(0, "."); sys.path.insert(0, "tests")
import numpy as np, shapely
from shapely.strtree import STRtree
from citygen.config import load_config
from citygen.world import generate_world
from citygen.city import plan_city
from citygen.city.ground import Ground
from citygen.export.streets import street_graph
import test_citygen as T
world = generate_world(load_config(quick=True))
plan = plan_city(world, world.capital())
ground = Ground(world, [plan])
from citygen.city.ground import STREET_LIFT
curb = float(world.style["streets"]["curb_height"])
for w in plan.walks:
    if w.kind != "sidewalk": continue
    st = plan.streets[w.street]
    p = w.polygon.representative_point()
    if not ground.surface(p.x, p.y) >= ground.height(p.x, p.y) + STREET_LIFT.get(st.kind, 0.24) + curb - 1e-6:
        print("walk", w.street, st.kind, st.width, "area", round(w.polygon.area, 2), "width", w.width, "polygon bounds", np.round(w.polygon.bounds, 1), "surface-height", round(float(ground.surface(p.x, p.y) - ground.height(p.x, p.y)), 3), "lift", float(ground.lift(p.x, p.y)), STREET_LIFT.get(st.kind, 0.24))
        # sample the polygon: where is the curb present?
        minx, miny, maxx, maxy = w.polygon.bounds
        xs = np.random.default_rng(0).uniform(minx, maxx, 4000); ys = np.random.default_rng(1).uniform(miny, maxy, 4000)
        inside = shapely.contains_xy(w.polygon, xs, ys)
        d = ground.surface(xs[inside], ys[inside]) - ground.height(xs[inside], ys[inside]) - np.asarray(ground.lift(xs[inside], ys[inside]))
        print("  inside samples", inside.sum(), "share with curb", float((d > curb * 0.9).mean()))
        tree = STRtree([s.line.buffer(s.width / 2, cap_style="flat") for s in plan.streets])
        for k in tree.query(shapely.Point(p.x, p.y), predicate="intersects"):
            print("  carriageway here:", int(k), plan.streets[int(k)].kind, plan.streets[int(k)].width)
grid = float(world.cfg["street_graph"]["grid"])
nodes, edges = street_graph(plan.streets, grid)
for k, line, a, b in edges:
    if plan.streets[k].line.is_closed: continue
    ahead = [plan.streets[k].line.project(line.interpolate(t, normalized=True)) for t in (0.25, 0.75)]
    if ahead[0] > ahead[1]:
        L = plan.streets[k].line
        print("edge street", k, plan.streets[k].kind, "len", round(L.length, 2), "piece len", round(line.length, 3), "ahead", np.round(ahead, 4))
        print("  piece", np.round(np.asarray(line.coords), 3).tolist())
        print("  street start", np.round(np.asarray(L.coords)[:4], 3).tolist(), "end", np.round(np.asarray(L.coords)[-3:], 3).tolist())
