import sys, collections
sys.path.insert(0, ".")
from citygen.config import load_config
from citygen.names import NameMaker
from citygen.rng import stream
from citygen.world import generate_world
tot = collections.Counter()
for seed in [42] + list(range(1, 21)):
    for size in (20, 64):
        w = generate_world(load_config(overrides={"world": {"seed": seed, "size_km": size}}))
        same = sum(1 for s in w.settlements if s.kind != "capital" and str(NameMaker(w.style, stream(seed, "names", s.kind, s.cell)).settlement(s.kind)) != s.generated)
        ar = collections.Counter(s.name_ar for s in w.settlements)
        tot["worlds"] += 1; tot["places"] += len(w.settlements); tot["redrawn"] += same
        tot["same Arabic"] += sum(v - 1 for v in ar.values() if v > 1)
        tot["same Latin"] += len(w.settlements) - len({s.name for s in w.settlements})
        if seed == 42: print(seed, size, "redrawn", same)
print(dict(tot))
