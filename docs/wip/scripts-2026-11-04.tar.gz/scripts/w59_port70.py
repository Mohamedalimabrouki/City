"""The prompt 70 review fixes, applied to the merged tree."""
import sys
root = sys.argv[1]
def edit(path, pairs):
    p = root + "/" + path
    s = open(p).read()
    for a, b in pairs:
        assert s.count(a) >= 1, a
        s = s.replace(a, b)
    open(p, "w").write(s)

edit("citygen/export/streets.py", [
('''center lines of `plan.streets` on a grid of `[streets] graph_grid` meters (5 cm, citygen/defaults.toml;
''', '''center lines of `plan.streets` on a grid of `[street_graph] grid` meters (5 cm, citygen/defaults.toml;
'''),
('''center line of `plan.streets` on a grid of `[streets] graph_grid` meters (5 cm, citygen/defaults.toml;
''', '''center line of `plan.streets` on a grid of `[street_graph] grid` meters (5 cm, citygen/defaults.toml;
'''),
]) if False else None
edit("citygen/export/streets.py", [
('''`[streets] graph_grid`''', '''`[street_graph] grid`'''),
('''from ..city.parking import walk_widths

def center_lines''', '''from ..city.parking import walk_widths


def center_lines'''),
('''        if 0.0 < mouth.distance(q) <= streets[h].width / 2 + grid:
            out[k] = LineString([(q.x, q.y), *st.line.coords])
            cuts.setdefault(h, []).append(d)
''', '''        off = mouth.distance(q)
        if off <= streets[h].width / 2 + grid:
            if off > 0.0:
                out[k] = LineString([(q.x, q.y), *st.line.coords])
            cuts.setdefault(h, []).append(d)
'''),
('''    nodes, edges = street_graph(plan.streets, float(world.cfg["streets"]["graph_grid"]))
''', '''    nodes, edges = street_graph(plan.streets, float(world.cfg["street_graph"]["grid"]))
'''),
])
edit("citygen/defaults.toml", [
('''[streets]
# The street graph for games (cities/<name>/streets.json, SPEC 6 "Street graph").
graph_grid = 0.05         # meters: center lines are noded on this grid; it also sets the impasse-mouth stub reach
''', '''[street_graph]
# The street graph for games (cities/<name>/streets.json, SPEC 6 "Street graph").
grid = 0.05               # meters: center lines are noded on this grid; it also sets the impasse-mouth stub reach
'''),
])
