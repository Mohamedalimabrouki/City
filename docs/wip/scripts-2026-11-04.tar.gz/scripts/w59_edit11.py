p = "tests/test_hydro.py"
s = open(p, encoding="utf-8").read()
i = s.index("def test_a_wet_pocket_of_a_dry_basin_fills_to_its_spill_and_runs_into_the_lake_below():")
j = s.index("@pytest.mark.slow  # two processes generate the 64 km world")
s = s[:i] + '''def test_a_wet_pocket_of_a_dry_basin_fills_to_its_spill_and_runs_into_the_lake_below():
    land, cfg = _WetWest(0.02, ridge=30.0), _little_water()
    rc = cfg["rivers"]
    rivers, lakes = drainage(land, cfg)
    g = _routing(land, rc)
    assert _one_basin(land, g, rc)
    assert sorted(k.salt for k in lakes) == [False, True]              # each pocket by the biome at its own bottom
    fresh, dry = sorted(lakes, key=lambda k: k.salt)
    cells = np.flatnonzero(g.lake_id == fresh.id)
    assert {_lake_reached(g, c) for c in cells} == {dry.id}            # its water runs on into the lake below
    rim = cells[0]
    while g.lake_id[rim] == fresh.id:
        rim = g.recv[rim]
    assert abs(land.height(g.c[rim % g.n], g.c[rim // g.n]) - fresh.level) < 2.0   # it stands up to its spill
    drains = np.flatnonzero(g.recv >= 0)
    assert np.all(g.flat[drains] > g.flat[g.recv[drains]])


''' + s[j:]
open(p, "w", encoding="utf-8").write(s)
