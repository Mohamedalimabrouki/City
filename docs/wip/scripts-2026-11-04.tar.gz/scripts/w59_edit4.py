def edit(p, pairs):
    s = open(p, encoding="utf-8").read()
    for a, b in pairs:
        assert s.count(a) == 1, (s.count(a), a)
        s = s.replace(a, b)
    open(p, "w", encoding="utf-8").write(s)
edit("tests/test_citygen.py", [
('''        assert link["distance"] < 1.0 and Point(nodes[link["node"]]).distance(plan.boundary.exterior) < 1.0
''', '''        limit = link["width"] / 2                 # the connector may start on the surface of a street at the limit
        assert link["distance"] < limit and Point(nodes[link["node"]]).distance(plan.boundary.exterior) < limit
'''),
('''def test_street_graph_nodes_a_mouth_exactly_on_its_street():
''', '''def test_street_graph_joins_a_street_that_stops_on_another_s_surface():
    """An alley ending on a street's surface, short of its center line, is a junction; one ending beside it is not."""
    from citygen.city.model import Street
    from citygen.export.streets import street_graph
    from shapely.geometry import LineString
    street = Street("street", 8.0, LineString([(0.0, 0.0), (100.0, 0.0)]))
    nodes, edges = street_graph([street, Street("alley", 4.0, LineString([(40.0, 3.9), (40.0, 30.0)]))], 0.05)
    assert len(nodes) == 4 and len(edges) == 3 and (40.0, 0.0) in nodes
    assert sum(line.length for k, line, _a, _b in edges if k == 1) == pytest.approx(30.0, abs=0.06)   # with its stub
    nodes, edges = street_graph([street, Street("alley", 4.0, LineString([(40.0, 4.2), (40.0, 30.0)]))], 0.05)
    assert len(nodes) == 4 and len(edges) == 2


def test_street_graph_nodes_a_mouth_exactly_on_its_street():
'''),
])
edit("docs/SPEC.md", [
('''limit: `road` (its id), `kind`, `width`, `x`, `y` (the crossing) and `node` (the nearest node,
`distance` meters away; the planner's connector street starts there).''', '''limit: `road` (its id), `kind`, `width`, `x`, `y` (the crossing) and `node` (the nearest node,
`distance` meters away, about where the planner's connector street starts).'''),
('''several streets (a grid street left under a boulevard) belongs to the widest. An impasse starts inside
the surface of the street its mouth opens on (prompt 20.2): its edge starts with a stub from the nearest
point of that street's center line, which also becomes a vertex of that street (even for a mouth on the
line itself, with no stub), so both snap to one node; the impasse's `length` includes the stub.''', '''several streets (a grid street left under a boulevard) belongs to the widest. A street that stops on the
surface of another, short of its center line (every impasse's mouth, prompt 20.2; some alleys and
connectors), gets a stub from the nearest point of that center line, which also becomes a vertex of that
street (even for an end on the line itself, with no stub), so both snap to one node; the edge's `length`
includes the stub.'''),
('''are joined. The largest connected part holds at least 99.5% of the street length (tested; the quick
capital is one part).
''', '''are joined. The largest connected part holds at least 99.5% of the street length (tested; the quick
capital is one part). A part stays apart only where the ribbons really do not meet (or two alleys overlap
side by side with no end on the other): the graph never invents a street the map does not draw.
'''),
])
