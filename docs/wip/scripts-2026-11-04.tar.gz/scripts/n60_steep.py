"""Do the houses on the steepest plots hold the turned and sunken entries? (old plan and new plan)"""
import sys, collections, time
sys.path.insert(0, ".")
import numpy as np, shapely
from citygen.config import load_config
from citygen.world import generate_world
from citygen.city import plan_city
from citygen.city.dressing import building_highs
from citygen.interior import rooms
from citygen.interior.context import BuildContext, layout_of
from citygen.interior.layout import plan_interior
from citygen.interior.outside import Outside
from citygen.interior.plancheck import way_in, way_rooms
world = generate_world(load_config(quick=True))
plan = plan_city(world, world.capital())
ctx = BuildContext(world, [plan], world.capital())
style = world.style
houses = [k for k, b in enumerate(plan.buildings) if b.kind == "house" and layout_of(plan, b, style) in ("dar", "compact", "small")]
t = time.time()
bs = [plan.buildings[k] for k in houses]
highs = building_highs(ctx.ground, bs)
drop = []
for k, b, high in zip(houses, bs, highs):
    xy = shapely.get_coordinates(b.footprint.exterior)
    drop.append((float(high - ctx.ground.height(xy[:, 0], xy[:, 1]).min()), k))
print("houses", len(houses), "drops in", round(time.time() - t, 2), "s")
drop.sort(key=lambda d: (-d[0], d[1]))
top = int(sys.argv[1]) if len(sys.argv) > 1 else 40
t = time.time(); n_sunk = n_turn = n_fail = 0
rows = []
for rank, (d, k) in enumerate(drop[:top]):
    i = plan_interior(Outside(ctx, plan, k), style)
    sunk = any(r.z < i.storeys[0].z - 0.05 for r in i.rooms if r.floor == 0)
    turn = any(s.kind == "steps" and s.turn for s in i.stairs)
    bad = rooms.check(i)
    n_sunk += sunk; n_turn += turn; n_fail += bool(bad)
    if sunk or turn: rows.append((rank, k, i.layout, round(d, 2), "sunk" if sunk else "", "turn" if turn else "", "FAIL" if bad else "ok"))
print("top", top, "sunken", n_sunk, "turned", n_turn, "fail", n_fail, "in", round(time.time() - t, 1), "s")
print(rows)
