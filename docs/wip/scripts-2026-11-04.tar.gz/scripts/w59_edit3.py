def edit(p, pairs):
    s = open(p, encoding="utf-8").read()
    for a, b in pairs:
        assert s.count(a) == 1, (s.count(a), a)
        s = s.replace(a, b)
    open(p, "w", encoding="utf-8").write(s)
s = open("citygen/export/streets.py", encoding="utf-8").read()
i, j = s.index("def center_lines(streets, grid: float) -> list:"), s.index("def _with_vertices(line, ds: list):")
s = s[:i] + '''def center_lines(streets, grid: float) -> list:
    """Each street's center line. A street that stops on another's surface, short of its center line, gets a
    stub from the nearest point of that line, and that point becomes a vertex of the other street too, so the
    grid snaps both to the same node. Impasses need it at their mouth: the planner starts the lane inside the
    surface of its street."""
    lines = [st.line for st in streets]
    if len(lines) < 2:
        return lines
    tree = STRtree(lines)
    reach = max(st.width for st in streets) / 2 + grid
    cuts: dict = {}
    stubs: dict = {}
    for k, st in enumerate(streets):
        for first in (True, False):
            end = Point(st.line.coords[0 if first else -1])
            h = _surface_under(streets, tree, k, end, reach, grid)
            if h is None:
                continue
            d = lines[h].project(end)
            q = lines[h].interpolate(d)
            cuts.setdefault(h, []).append(d)
            if end.distance(q) > 0.0:
                stubs[k, first] = (q.x, q.y)
    out = [_with_vertices(line, sorted(cuts[k])) if k in cuts else line for k, line in enumerate(lines)]
    for k, line in enumerate(out):
        head, tail = stubs.get((k, True)), stubs.get((k, False))
        if head is not None or tail is not None:
            out[k] = LineString(([head] if head else []) + list(line.coords) + ([tail] if tail else []))
    return out


def _surface_under(streets, tree, k: int, end, reach: float, grid: float):
    """The street whose surface the `end` of street k lies on, the nearest (the lowest index on a tie), or None.
    An impasse opens on a real street, never on another impasse."""
    found = []
    for h in tree.query(end, predicate="dwithin", distance=reach).tolist():
        if h == k or (streets[k].kind == "impasse" and streets[h].kind == "impasse"):
            continue
        d = end.distance(streets[h].line)
        if d <= streets[h].width / 2 + grid:
            found.append((d, h))
    return min(found)[1] if found else None


''' + s[j:]
open("citygen/export/streets.py", "w", encoding="utf-8").write(s)
edit("citygen/hydro.py", [
('''        lake_id[g[water]] = k
        salt[g[water]] = is_salt
        lakes.append(_lake(k, water, h, c[sx], c[sy], level, is_salt))
''', '''        lake_id[g[water]] = k
        salt[g[water]] = is_salt
        wy, wx = slice(max(sy.start - 1, 0), sy.stop + 1), slice(max(sx.start - 1, 0), sx.stop + 1)
        lakes.append(_lake(k, lake_id.reshape(n, n)[wy, wx] == k, H[wy, wx], c[wx], c[wy], level, is_salt))
'''),
('''    """The shore of one basin (its box of the grid): where the ground inside it meets `level`."""
''', '''    """The shore of one lake (`mask`, in a box of the grid one cell wider): where the ground meets `level`."""
'''),
])
