import sys, time, math
sys.path.insert(0, sys.argv[1])
import numpy as np
from scipy import ndimage
from citygen.config import load_config
from citygen.terrain import Terrain, classify, STEPPE, DESERT, BIOME_NAMES
from citygen import hydro
cfg = load_config(quick=False)
rc = cfg["rivers"]
ter = Terrain(42, cfg)
size=ter.size; n=max(8,int(math.ceil(size/float(rc["cell"])))); cell=size/n
c=(np.arange(n)+.5)*cell; X,Y=np.meshgrid(c,c); H=ter.height(X,Y); M=ter.moisture(X,Y,H); sea=H<=0
filled,recv=hydro._flood(H,sea); gy,gx=np.gradient(H,cell); biome=classify(H,np.hypot(gx,gy),M)
area=cell*cell/1e6; dry=float(rc["dry_weight"]); weight=np.where(sea,0.,dry+(1-dry)*M).ravel()*area
flow,_=hydro._accumulate(np.argsort(-filled.ravel(),kind="stable"),recv,weight,np.full(n*n,area))
depth=np.where(sea,0.,filled-H); labels,count=ndimage.label(depth>0.01,np.ones((3,3),bool))
min_cells=float(rc["lake_min_area"])*1e6/(cell*cell)
cells=np.bincount(labels.ravel(),minlength=count+1); ids=np.flatnonzero(cells>=min_cells); ids=ids[ids>0]
print("basins total",count,"size>=min",len(ids), "cells", n*n, "min_cells", min_cells)
deepest=ndimage.maximum(depth,labels,ids); spill=ndimage.maximum(filled,labels,ids); inflow=ndimage.maximum(flow.reshape(n,n),labels,ids); bottom=ndimage.minimum_position(H,labels,ids)
rows=[]
for k in range(len(ids)):
    size_=cells[ids[k]]; wet=math.ceil(float(rc["lake_area_per_flow"])*inflow[k]*1e6/(cell*cell)); b=int(biome[bottom[k]]); salt=b in (STEPPE,DESERT)
    if deepest[k]<float(rc["lake_min_depth"]): tag="shallow"
    elif wet<min_cells or (not salt and wet<size_): tag="dropped"
    else: tag="kept"
    rows.append((tag,salt,BIOME_NAMES[b] if isinstance(BIOME_NAMES,(list,tuple,dict)) else b,round(float(deepest[k]),1),int(size_),wet,round(float(inflow[k]),1),round(float(H[bottom[k]]),1),round(float(M[bottom[k]]),2)))
from collections import Counter
print(Counter((r[0],r[1]) for r in rows))
dr=[r for r in rows if r[0]=="dropped"]
dr.sort(key=lambda r:-r[3])
print("dropped wet:"); [print(r) for r in dr if not r[1]]
print("dropped dry:"); [print(r) for r in dr if r[1]]
print("kept:"); [print(r) for r in sorted([r for r in rows if r[0]=="kept"],key=lambda r:-r[3])[:60]]
