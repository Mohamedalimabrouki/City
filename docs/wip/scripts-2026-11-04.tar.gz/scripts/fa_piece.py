"""Front / side / 3-4 painter render of kit pieces with PIL (no browser). usage: fa_piece.py out.png piece piece ..."""
import sys; sys.path.insert(0,'.')
import numpy as np
from PIL import Image, ImageDraw
from citygen.config import load_config, load_style
from citygen.kit import make_kit
cfg=load_config(quick=True); style=load_style(cfg["world"]["style"])
kit=make_kit(42,cfg,style)
def color(mat, m):
    c=m.get('color') or m.get('base') or m.get('rgb') or (0.7,0.7,0.7)
    if isinstance(c,str):
        c=c.lstrip('#'); c=[int(c[i:i+2],16)/255 for i in (0,2,4)]
    return np.array(c[:3],float)
def render(name, yaw=0.0, S=170, W=420,H=520, wall=True):
    pc=kit.pieces[name]
    tris=[];cols=[]
    light=np.array([.4,.7,.6]);light/=np.linalg.norm(light)
    for mat,p in pc.parts.items():
        pos=np.asarray(p['pos']);idx=np.asarray(p['idx']).reshape(-1,3)
        col=p.get('col')
        base=color(mat,kit.materials.get(mat,{}))
        for t in idx:
            tr=pos[t]
            n=np.cross(tr[1]-tr[0],tr[2]-tr[0]);l=np.linalg.norm(n)
            if l<1e-12: continue
            n/=l
            c=base if col is None else np.asarray(col)[t][:,:3].mean(0)
            tris.append(tr);cols.append((c,n))
    tris=np.array(tris)
    # glTF axes: x right, y up, -z street. view from street: camera toward +z
    c,s=np.cos(yaw),np.sin(yaw)
    R=np.array([[c,0,s],[0,1,0],[-s,0,c]])
    P=tris@R.T
    img=Image.new('RGB',(W,H),(214,190,140)); d=ImageDraw.Draw(img)
    ox,oy=W/2,H-30-0.0
    lo=pc.bounds[0];hi=pc.bounds[1]
    oy=H-30+lo[1]*S
    order=np.argsort(P[:,:,2].mean(1))[::-1]  # far (large z) first
    for i in order:
        tr=P[i]
        (cc,n)=cols[i]
        nn=R@n
        if nn[2]>1e-6: continue # backface culling (viewer at -z)
        sh=0.55+0.45*max(0,float(n@ (light*[1,1,-1])))
        rgb=tuple(int(255*min(1,v*sh)**(1/2.2)) for v in cc)
        pts=[(ox+v[0]*S, oy-v[1]*S) for v in tr]
        d.polygon(pts,fill=rgb)
    d.text((6,6),f"{name} tris {pc.triangles if hasattr(pc,'triangles') else ''} y {lo[1]:.2f}..{hi[1]:.2f} x {lo[0]:.2f}..{hi[0]:.2f} z {lo[2]:.2f}..{hi[2]:.2f}",fill=(0,0,0))
    return img
if __name__=="__main__":
    out=sys.argv[1]; names=sys.argv[2:]
    yaws=[0.0,0.7]
    W=420;H=520
    sheet=Image.new('RGB',(W*len(names),H*2),(255,255,255))
    for i,nm in enumerate(names):
        for j,y in enumerate(yaws):
            sheet.paste(render(nm,y,W=W,H=H),(i*W,j*H))
    sheet.save(out)
