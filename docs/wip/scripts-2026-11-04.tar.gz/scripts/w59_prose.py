import re, sys, collections
sys.path.insert(0, ".")
from citygen.config import load_config
from citygen.world import generate_world
from citygen.city import plan_city
w = generate_world(load_config(quick=True))
bad = []; n = 0; counts = collections.Counter()
for s in w.settlements:
    p = plan_city(w, s)
    for d in p.districts:
        n += 1
        t = d.history
        counts[len(re.findall(r"[^.]+\.", t))] += 1
        checks = {"brace": "{" in t or "}" in t, "double comma": ",," in t or ", ," in t, "space before": " ," in t or " ." in t or " :" in t,
                  "double space": "  " in t, "double period": ".." in t, "no end": not t.endswith("."), "lower start": not t[:1].isupper(),
                  "One gates": re.search(r"\bOne \w+ gates\b|\bOne gates\b", t) is not None, "mid where": re.search(r" of the medina [a-z]", t) is not None}
        for k, v in checks.items():
            if v:
                bad.append((s.name, d.name, k, t))
print("histories", n, "sentences per history", sorted(counts.items()), "faults", len(bad))
for b in bad[:8]: print(b)
