"""The drawn step where a ribbon ends: python va_steps.py"""
import sys, numpy as np
from shapely.geometry import LineString, Point
sys.path.insert(0,'.')
from citygen.config import load_config
from citygen.hydro import along
from citygen.world import generate_world
for quick in (True, False):
    for seed in (42,7,3):
        w=generate_world(load_config(quick=quick,overrides={"world":{"seed":seed}})); c=w.carve
        worst={'sea':0.0,'lake':0.0,'river':0.0,'outlet':0.0,'other_lake':0}
        for r in w.rivers:
            rib=c.ribbons.get(r.id)
            if rib is None: continue
            z=float(np.interp(rib.end,rib.along,r.surface))
            if r.mouth=='sea': worst['sea']=max(worst['sea'],abs(z))
            elif r.mouth=='lake': worst['lake']=max(worst['lake'],abs(z-w.lakes[r.into].level))
            elif r.mouth=='river':
                m=w.rivers[r.into]; p=rib.line.interpolate(rib.end); at=LineString(m.coords).project(p)
                worst['river']=max(worst['river'],abs(z-float(np.interp(at,along(m.coords),m.surface))))
            if r.source is not None:
                worst['outlet']=max(worst['outlet'],abs(float(np.interp(rib.start,rib.along,r.surface))-w.lakes[r.source].level))
            # water lower than a lake it passes through the zone of, not its own
            for k,sh in enumerate(c.shores):
                if k in (r.source, r.into) : continue
                bx0,by0,bx1,by1=sh.box
                inb=(r.coords[:,0]>bx0)&(r.coords[:,0]<bx1)&(r.coords[:,1]>by0)&(r.coords[:,1]<by1)
                if inb.any():
                    import shapely
                    on=shapely.contains_xy(sh.zone,r.coords[inb,0],r.coords[inb,1])
                    if on.any() and (r.surface[inb][on]<sh.level-0.05).any(): worst['other_lake']+=1
        print('quick' if quick else 'full',seed,{k:round(v,3) for k,v in worst.items()})
