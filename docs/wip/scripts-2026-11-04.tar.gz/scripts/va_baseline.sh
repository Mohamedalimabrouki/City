#!/bin/zsh
# Baseline measures on main (a plain copy of the tree), for the before side of every gate.
PY=/Users/mohamedalimabrouki/Desktop/City/.venv/bin/python
OUT=/tmp/claude-501/va_base_out
mkdir -p $OUT
cd /tmp/claude-501/va_base_src
for b in mid:17.7,25.4,19.7,27.4 lake:25.0,18.6,27.0,20.6 salt:34.3,16.3,36.3,18.3 city:24.0,40.3,26.0,42.3 lakecity:7.4,2.8,9.4,4.8; do
  n=${b%%:*}; a=${b#*:}
  echo "=== box $n $a"; 
  /usr/bin/time -p $PY -m citygen build --area box:$a --out $OUT/$n 2>&1 | tail -6
done
echo "=== capital full"
/usr/bin/time -p $PY -m citygen build --area capital --out $OUT/full 2>&1 | tail -6
echo "=== quick"
/usr/bin/time -p $PY -m citygen build --quick --out $OUT/quick --force 2>&1 | tail -4
echo "=== interior survey quick"
$PY tools/interior_survey.py --folder $OUT/quick/bodjantouna-42 2>&1 | tail -40
echo "=== interior survey villas"
$PY tools/interior_survey.py --folder $OUT/quick/bodjantouna-42 --city villas 2>&1 | tail -40
echo "=== street survey quick"
$PY tools/street_survey.py --quick 2>&1 | tail -20
echo "=== done"
