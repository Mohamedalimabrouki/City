import sys,re,collections; sys.path.insert(0,'.')
import numpy as np, shapely
from citygen.interior import furnish as FU
from citygen.interior.context import HOUSING, city_plan, layout_of, load_build
from citygen.interior.layout import plan_interior
from citygen.interior.outside import Outside
ctx=load_build('output/bodjantouna-42',log=lambda m:None)
plan, style = city_plan(ctx), ctx.world.style
centers = shapely.get_coordinates(shapely.centroid([b.footprint for b in plan.buildings]))
d = np.hypot(centers[:, 0] - plan.settlement.x, centers[:, 1] - plan.settlement.y)
got=[]
for k in np.lexsort((np.arange(len(d)), d)).tolist():
    b=plan.buildings[k]
    if b.kind in HOUSING and layout_of(plan,b,style)=='slab' and len(got)<8: got.append(k)
print(got)
for k in got:
    o=Outside(ctx,plan,k); it=plan_interior(o,style); fu=FU.furnish(it,o,style,"sparse")
    ws=[w for w in fu.warnings if ' has no ' in w]
    print(k,'rooms',len(it.rooms),'stairs',collections.Counter(s.kind for s in it.stairs),'warn',len(ws))
    for w in ws[:30]:
        p=w.split()
        rid=int(p[2]) if p[2].isdigit() else None
        if rid is not None:
            r=it.rooms[rid]
            minx,miny,maxx,maxy=r.polygon.bounds
            ops=[(x.kind,round(x.width,2)) for x in it.openings if rid in x.rooms]
            sts=[s.kind for s in it.stairs if s.polygon.intersects(r.polygon) and s.polygon.intersection(r.polygon).area>.05]
            print('  ',w[9:],'f',r.floor,'area',round(r.polygon.area,2),'bbox',round(maxx-minx,2),round(maxy-miny,2),ops,sts)
