import sys,time; sys.path.insert(0,'.')
import collections
from citygen.interior.context import city_plan, load_build, layout_of
from citygen.interior.layout import plan_interior
from citygen.interior.outside import Outside
from citygen.interior import floors as F, stairs as S
ctx=load_build('output/bodjantouna-42',log=lambda m:None); plan=city_plan(ctx,None); style=ctx.world.style
c=collections.Counter(); ex=[]
n=collections.Counter()
for k,b in enumerate(plan.buildings):
    if b.kind not in("house","domed","apartments","villa"): continue
    lay=layout_of(plan,b,style)
    n[lay]+=1
    if n[lay]%6: continue
    try: it=plan_interior(Outside(ctx,plan,k),style)
    except Exception as e: continue
    fl,st,_=F.settings(style)
    th=float(fl.get("slab",.25))
    for f in range(1,it.floors+1):
        reg=F.base(it,f); z=S.level(it,f)
        hits=[o for o in it.openings if F.crosses(it,o,reg,z,th,fl,st)]
        for o in hits: c[(lay,'slab',o.kind)]+=1; ex.append((k,lay,f,o.kind,o.piece))
    for s in it.stairs:
        for p in S.parts(s,it,st,fl):
            if p.kind=='landing':
                hits=[o for o in it.openings if F.crosses(it,o,p.poly,p.z1,p.z1-p.z0,fl,st)]
                for o in hits: c[(lay,'landing',o.kind)]+=1; ex.append((k,lay,'L',o.kind,o.piece))
    c[(lay,'houses')]+=1
print(c); print(ex[:12])
