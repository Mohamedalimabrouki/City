import sys
sys.path.insert(0, sys.argv[1])
import numpy as np
from shapely.geometry import Point
from citygen.config import load_config
from citygen.world import generate_world
from citygen.city import plan_city, CityContext
from citygen.city import history as H
cfg = load_config(quick=True); w = generate_world(cfg)
for s in w.settlements[:6]:
    plan = plan_city(w, s)
    style = w.style.get("history", {})
    ctx = CityContext(w, s)
    f = H._Facts(ctx, plan, style)
    diffs = []
    for m in plan.landmarks:
        a = f.district_at(m.x, m.y)
        p = Point(m.x, m.y)
        exact = next((d.id for d in plan.districts if d.polygon.contains(p)), None)
        b = exact if exact is not None else a
        if a != b:
            diffs.append((m.kind, m.name, a, b, plan.districts[a].kind if a is not None else None, plan.districts[b].kind if b is not None else None))
    print(s.name, s.kind, "landmarks", len(plan.landmarks), "changed", len(diffs), diffs[:8])
    # souks by midpoint too
    dd = 0
    for k in plan.souks:
        mid = plan.streets[k.street].line.interpolate(0.5, normalized=True)
        a = f.district_at(mid.x, mid.y); p = Point(mid.x, mid.y)
        exact = next((d.id for d in plan.districts if d.polygon.contains(p)), None)
        dd += (exact is not None and exact != a)
    print("   souks changed", dd, "of", len(plan.souks))
