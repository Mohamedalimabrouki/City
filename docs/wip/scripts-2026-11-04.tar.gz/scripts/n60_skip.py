"""Force one place out (as a skip inside the loop, via _conflicts) and measure what else changes."""
import sys, math
sys.path.insert(0, ".")
import numpy as np
import citygen.world as W
from citygen.config import load_config
from citygen.world import generate_world

def snap(w):
    return {(s.kind, s.cell): s for s in w.settlements}

def forced(cfg, spots):
    real = W._conflicts
    def fake(x, y, radius, rank, taken, spacing):
        if any(math.hypot(x - a, y - b) < 1e-6 for a, b in spots):
            return True
        return real(x, y, radius, rank, taken, spacing)
    W._conflicts = fake
    try:
        return generate_world(cfg)
    finally:
        W._conflicts = real

for quick in (True, False):
    cfg = load_config(quick=quick)
    base = generate_world(cfg)
    A = snap(base)
    print("=== quick" if quick else "=== 64 km", len(base.settlements), "settlements")
    for victim in [s for s in base.settlements if s.kind in ("city", "town")][: (99 if quick else 14)]:
        w = forced(cfg, [(victim.x, victim.y)])
        B = snap(w)
        gone = [A[k] for k in A if k not in B and k != (victim.kind, victim.cell)]
        new = [B[k] for k in B if k not in A]
        same_all = sum(1 for k in A if k in B and (A[k].x, A[k].y, A[k].population, A[k].name, A[k].known_for, A[k].founded) == (B[k].x, B[k].y, B[k].population, B[k].name, B[k].known_for, B[k].founded))
        renamed = [(A[k].name, B[k].name) for k in A if k in B and A[k].name != B[k].name]
        centers = [(victim.x, victim.y)] + [(s.x, s.y) for s in new if s.kind == victim.kind]
        far = []
        for s in gone + new:
            far.append(min(math.hypot(s.x - x, s.y - y) for x, y in centers) / 1000)
        print(f"{victim.kind:5s} {victim.name:22s} kept {same_all:3d}/{len(A) - 1}  gone {[(s.kind, s.name) for s in gone][:6]} new {[(s.kind, s.name) for s in new][:6]} renamed {renamed} far km {np.round(sorted(far), 1).tolist()}")
