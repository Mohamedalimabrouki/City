def edit(p, pairs):
    s = open(p, encoding="utf-8").read()
    for a, b in pairs:
        assert s.count(a) == 1, (s.count(a), a)
        s = s.replace(a, b)
    open(p, "w", encoding="utf-8").write(s)
edit("tests/test_hydro.py", [
('''    `ridge` meters of ridge across the hollow at x = `at` split a dry basin's water into two pockets."""
    def __init__(self, wet, ridge=0.0, at=15000.0):
        self.size, self.wet, self.ridge, self.at = 20000.0, wet, ridge, at

    def height(self, x, y):
        x, y = np.asarray(x, float), np.asarray(y, float)
        bowl = np.clip(1 - ((x - 15000) ** 2 + (y - 10000) ** 2) / 1000.0 ** 2, 0, None)
        h = 200.0 - 0.008 * x + 0.01 * np.abs(y - 10000) - 40.0 * bowl
''', '''    `ridge` meters of ridge across the hollow at x = `at` split a dry basin's water into two pockets."""
    def __init__(self, wet, ridge=0.0, at=15000.0, radius=1000.0, deep=40.0):
        self.size, self.wet, self.ridge, self.at, self.radius, self.deep = 20000.0, wet, ridge, at, radius, deep

    def height(self, x, y):
        x, y = np.asarray(x, float), np.asarray(y, float)
        bowl = np.clip(1 - ((x - 15000) ** 2 + (y - 10000) ** 2) / self.radius ** 2, 0, None)
        h = 200.0 - 0.008 * x + 0.01 * np.abs(y - 10000) - self.deep * bowl
'''),
('''def test_a_wet_hollow_too_big_for_its_water_drains_and_its_river_cuts_through_the_rim():
    land = _Valley(0.9)
    rivers, lakes = drainage(land, _little_water())
    assert not lakes
    river = max(rivers, key=lambda r: r.flow)
    assert river.mouth == "border"
    ground = land.height(river.coords[:, 0], river.coords[:, 1])
    assert np.all(river.profile <= ground + 0.1) and np.all(np.diff(river.profile) <= 1e-9)
    assert (ground - river.profile).max() > 10.0                   # the cut through the rim
''', '''def test_a_wet_hollow_fills_to_its_spill_however_little_water_reaches_it():
    land, cfg = _Valley(0.9), _little_water()
    rivers, lakes = drainage(land, cfg)
    g = _routing(land, cfg["rivers"])
    X, Y = np.meshgrid(g.c, g.c)
    assert len(lakes) == 1 and not lakes[0].salt
    assert np.count_nonzero(g.lake_id == 0) > 100                  # the whole hollow, not its balanced 23 cells
    assert np.all((land.height(X, Y).ravel() >= lakes[0].level) | (g.lake_id == 0)
                  | ((X.ravel() - 15000.0) ** 2 + (Y.ravel() - 10000.0) ** 2 > 1000.0 ** 2))
    assert [r.mouth for r in rivers if r.coords[0, 0] > 15000.0 and r.flow > 10.0] == ["border"]   # it spills on


def test_a_river_cuts_through_the_rim_of_a_pit_too_small_for_a_lake():
    land = _Valley(0.9, radius=350.0, deep=15.0)
    rivers, lakes = drainage(land, load_config(quick=True))
    assert not lakes
    river = max(rivers, key=lambda r: r.flow)
    assert river.mouth == "border"
    ground = land.height(river.coords[:, 0], river.coords[:, 1])
    assert np.all(river.profile <= ground + 0.1) and np.all(np.diff(river.profile) <= 1e-9)
    assert (ground - river.profile).max() > 4.0                    # the cut through the rim
'''),
])
edit("docs/SPEC.md", [
('''  km2); its lake surface is `lake_area_per_flow` (0.04) km2 per km2 of rain-weighted inflow. A basin of wet
  country that this fills spills over (a fresh lake at the spill level, its river goes on from the outlet);
  one it does not fill just drains. A basin whose lowest cell is steppe or desert always stays closed
  (Ali, 4 November): a salt lake of that balanced size, never under `lake_min_area`, however little water
  reaches it; the rest of the basin is re-flooded from the lake so every cell of it drains in, and rivers
  end there (prompt 65 turns them into chotts). A lake is the 4-connected water around the basin's lowest
''', '''  km2). Water cannot drain out of a hollow, so a basin of wet country is a fresh lake up to its spill, and
  its river goes on from the outlet. A basin whose lowest cell is steppe or desert always stays closed
  (Ali, 4 November): a salt lake of `lake_area_per_flow` (0.04) km2 per km2 of rain-weighted inflow, never
  under `lake_min_area`, however little water reaches it; the rest of the basin is re-flooded from the lake
  so every cell of it drains in, and rivers end there (prompt 65 turns them into chotts). A lake is the 4-connected water around the basin's lowest
'''),
])
