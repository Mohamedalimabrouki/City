"""Why the deep cuts: for each stretch over 10 m, what lies under its low point, on the grid."""
import inspect, sys, collections
import numpy as np
sys.path.insert(0, ".")
from shapely.geometry import Point, Polygon
import citygen.hydro as hy
from citygen.config import load_config
src = inspect.getsource(hy._basins)
old = "            continue                    # too little water to fill it: a damp hollow that drains\n"
src = src.replace(old, "            wet = size\n")
exec(src, hy.__dict__)
from citygen.world import generate_world
from scipy import ndimage

cfg = load_config(quick=False)
w = generate_world(cfg)
t = w.terrain
g = hy._routing(t, cfg["rivers"])
n, c = g.n, g.c
step = c[1] - c[0]
X, Y = np.meshgrid(c, c)
H = t.height(X, Y)
sea = H <= 0
filled, _ = hy._flood(H, sea)
depth = np.where(sea, 0.0, filled - H)
labels, count = ndimage.label(depth > float(cfg["rivers"]["basin_depth"]), np.ones((3, 3), bool))
sizes = np.bincount(labels.ravel(), minlength=count + 1)
maxd = ndimage.maximum(depth, labels, np.arange(count + 1))
lakes = {k.id: k for k in w.lakes}
print("lake cells that have a lake:", (g.lake_id >= 0).sum())

def seglen(xy): return np.hypot(*np.diff(xy, axis=0).T)
rows = collections.Counter()
seen = set()
for r in sorted(w.rivers, key=lambda r: r.id):
    xy, z = r.coords, r.profile
    gr = t.height(xy[:, 0], xy[:, 1])
    d = gr - z
    L = seglen(xy)
    mid = (d[:-1] + d[1:]) / 2
    i, j = np.clip(np.floor(xy / step).astype(int), 0, n - 1).T
    lab = labels[j, i]
    # the vertex where the bed last equalled the ground (or lake) before each deep stretch
    k = 0
    while k < len(mid):
        if mid[k] > 10:
            e = k
            while e + 1 < len(mid) and mid[e + 1] > 10:
                e += 1
            # walk upstream to where the bed took this value
            b = k
            while b > 0 and z[b - 1] <= z[k] + 1e-6:
                b -= 1
            where = "?"
            ll = lab[b]
            info = f"basin size {sizes[ll]} cells {sizes[ll]*step*step/1e6:.2f} km2 depth {maxd[ll]:.1f}" if ll else "no filled basin at the low point (tributary or running bed)"
            in_rim = lab[k:e + 1]
            cross = sorted(set(in_rim.tolist()))
            key = (r.id, k)
            print(f"river {r.id:3d} {'oued ' if r.seasonal else 'river'} into {r.mouth:6s}{str(r.into):>5s} flow {r.flow:6.1f}: {L[k:e+1].sum()/1000:4.1f} km up to {mid[k:e+1].max():4.0f} m from vertex {k}/{len(z)}, at ({xy[k,0]/1000:.1f},{xy[k,1]/1000:.1f}) bed {z[k]:.0f} m. low point ({xy[b,0]/1000:.1f},{xy[b,1]/1000:.1f}): {info}; basins crossed {[(int(x), int(sizes[x]), round(float(maxd[x]),1)) for x in cross if x][:3]}")
            k = e + 1
        else:
            k += 1
