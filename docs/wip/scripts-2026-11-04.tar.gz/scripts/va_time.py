"""Tile build time on this tree: country tiles round river 0's mid course, with and without the file writing."""
import sys, time, tempfile, pathlib
sys.path.insert(0,'.')
import numpy as np
from citygen.config import load_config
from citygen.world import generate_world
from citygen.mesh.tile import TileContext, export_tile, build_tile
from citygen.city import plan_city
t0=time.perf_counter(); cfg=load_config(); w=generate_world(cfg); print('country s', round(time.perf_counter()-t0,2))
tc=TileContext(w,[])
keys=[(i,j) for i in range(34,40) for j in range(49,55)]
d=pathlib.Path(tempfile.mkdtemp(dir='/tmp/claude-501/va_tmp'))
for rep in range(3):
    t=time.perf_counter()
    n=0
    for i,j in keys: 
        e=export_tile(tc,i,j,d); n+=e['bytes']
    dt=time.perf_counter()-t
    print('rep',rep,'tiles',len(keys),'ms per tile',round(1000*dt/len(keys),1),'MB',round(n/1e6,2))
