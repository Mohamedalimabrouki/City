import sys
sys.path.insert(0, ".")
import numpy as np
from scipy import ndimage
from citygen.config import load_config
from citygen.terrain import Terrain
from citygen import hydro
def literal(h, m, wet, spill):
    """The brief's (b) read literally: the old level, then only the piece holding the bottom."""
    heights = np.sort(h[m])
    if wet >= len(heights):
        return hydro._water_real(h, m, wet, spill)
    level = float(heights[wet - 1])
    bottom = np.unravel_index(np.argmin(np.where(m, h, np.inf)), h.shape)
    parts, _ = ndimage.label(m & (h <= level))
    return parts == parts[bottom], level
hydro._water_real = hydro._water
for seed in (42, 1, 2, 3, 4, 5):
    cfg = load_config(overrides={"world": {"seed": seed}}); ter = Terrain(seed, cfg); rc = cfg["rivers"]
    hydro._water = hydro._water_real
    a = hydro._routing(ter, rc)
    hydro._water = literal
    b = hydro._routing(ter, rc)
    ca, cb = np.bincount(a.lake_id[a.lake_id >= 0]), np.bincount(b.lake_id[b.lake_id >= 0])
    salt = np.array([k.salt for k in b.lakes])
    print("seed", seed, "lakes", len(cb), "| literal: salt lakes under 23 cells", int((cb[salt] < 23).sum()), "smallest", int(cb.min()), "cells;", "lakes smaller than their balanced area", int((cb < ca).sum()), "| grown: smallest", int(ca.min()))
