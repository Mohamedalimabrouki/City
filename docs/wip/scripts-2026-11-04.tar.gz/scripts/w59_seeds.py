import sys, math, time
sys.path.insert(0, sys.argv[1])
import numpy as np, shapely
from scipy import ndimage
from shapely.geometry import LineString, Point, Polygon
from citygen.config import load_config
from citygen.terrain import Terrain, classify, STEPPE, DESERT
from citygen import hydro
tot = 0
for quick in (True, False):
  for seed in [1,2,3,4,5,6,7,8,9,10,11,42]:
    cfg = load_config(quick=quick, overrides={"world": {"seed": seed}}); ter = Terrain(seed, cfg); rc = cfg["rivers"]
    t=time.perf_counter(); rivers, lakes = hydro.drainage(ter, cfg); t=time.perf_counter()-t
    g = hydro._routing(ter, rc); cell = g.c[1]-g.c[0]; n=g.n
    i = np.flatnonzero(g.recv>=0); bad = int(np.count_nonzero(g.flat[i] <= g.flat[g.recv[i]]))
    # every land cell ends at the sea, a salt lake or the border: walk recv with memo
    water = shapely.unary_union([Polygon(k.polygon).buffer(1.5*cell) for k in lakes]) if lakes else None
    above = 0.0; rises = 0; joins = 0.0; ends = 0
    for r in rivers:
        gr = ter.height(r.coords[:,0], r.coords[:,1])
        off = np.ones(len(gr),bool) if water is None else ~shapely.contains_xy(water, r.coords[:,0], r.coords[:,1])
        if off.any(): above = max(above, float((r.profile-gr)[off].max()))
        rises += int(np.any(np.diff(r.profile) > 1e-9))
        if r.mouth == "river":
            m = rivers[r.into]; assert r.into < r.id
            s = LineString(m.coords).project(Point(r.coords[-1])); a = np.concatenate([[0.],np.cumsum(np.hypot(*np.diff(m.coords,axis=0).T))])
            joins = max(joins, abs(float(np.interp(s,a,m.profile))-float(r.profile[-1])))
        if r.mouth in ("lake","basin"):
            ends += not Polygon(lakes[r.into].polygon).buffer(cell).contains(Point(r.coords[-1]))
    # every lake cell inside (a cell of) its ring
    far = 0.0
    for k in lakes:
        ys, xs = np.nonzero((g.lake_id == k.id).reshape(n,n))
        far = max(far, float(shapely.distance(Polygon(k.polygon), shapely.points(g.c[xs], g.c[ys])).max()))
    print(("quick" if quick else "64km"), "seed", seed, round(t,2), "s rivers", len(rivers), "lakes", len(lakes), "salt", sum(k.salt for k in lakes), "| order bad", bad, "rises", rises, "bed above ground", round(above,3), "join gap", round(joins,6), "ends off shore", ends, "lake cell off ring", round(far,1), "mouths", {m: sum(r.mouth==m for r in rivers) for m in ("sea","lake","basin","border","river")})
    tot += bad + rises + ends
print("TOTAL faults", tot)
