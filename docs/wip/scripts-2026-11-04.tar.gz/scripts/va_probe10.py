import sys, numpy as np, shapely
from shapely.geometry import LineString, Point, Polygon
sys.path.insert(0,'.')
from citygen.config import load_config
from citygen.hydro import channel, along, low_ground
from citygen.world import generate_world
seed=int(sys.argv[1]); w=generate_world(load_config(overrides={"world":{"seed":seed}})); c=w.carve; rc=w.cfg["rivers"]
bad=[]
for r in w.rivers:
    if r.seasonal: continue
    ch=channel(r,rc); rib=c.ribbons[r.id]
    d=np.gradient(r.coords,axis=0); nrm=np.stack([-d[:,1],d[:,0]],1)/np.maximum(np.hypot(*d.T),1e-9)[:,None]
    on=np.flatnonzero((rib.along>=rib.start)&(rib.along<=rib.end)&(ch["half"]>0.5))
    for side in (-1.,1.):
        p=r.coords[on]+nrm[on]*(side*(ch["half"][on]+ch["lip"][on]))[:,None]
        h0=np.asarray(w.terrain.height(p[:,0],p[:,1]))
        f=c.fill(p[:,0],p[:,1],h0)
        h=c.ground(p[:,0],p[:,1],h0)
        o=h-r.surface[on]; past=c.past_bank(p[:,0],p[:,1])
        for i in np.flatnonzero((o<0.0)&(past>-0.3)):
            k=on[i]
            bad.append((round(float(o[i]),2),r.id,int(k),'mouth',r.mouth,'to end',round(float(rib.end-rib.along[k])),'h0',round(float(h0[i]-r.surface[k]),2),'fill',round(float(f[i]-r.surface[k]),2),'past',round(float(past[i]),2),'near',np.round(p[i]).tolist(), 'surface around',np.round(r.surface[max(0,k-2):k+3]-r.surface[k],2).tolist()))
print(sorted(bad)[:6])
