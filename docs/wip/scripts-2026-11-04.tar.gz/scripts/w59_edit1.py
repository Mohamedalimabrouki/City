def edit(p, pairs):
    s = open(p, encoding="utf-8").read()
    for a, b in pairs:
        assert s.count(a) == 1, (s.count(a), a)
        s = s.replace(a, b)
    open(p, "w", encoding="utf-8").write(s)
edit("citygen/export/streets.py", [
('''def streets_json(world, plan, ground) -> dict:
    """The street graph of one city; z of a node is the drawn street top there (`Ground.surface`)."""
    nodes, edges = street_graph(plan.streets, float(world.cfg["street_graph"]["grid"]))
    xy = np.asarray(nodes, dtype=np.float64).reshape(-1, 2)
    z = np.asarray(ground.surface(xy[:, 0], xy[:, 1]), dtype=np.float64) if len(xy) else np.zeros(0)
    widths, _promoted''', '''def node_tops(ground, xy, grid: float) -> np.ndarray:
    """z of each node: the drawn street top there (`Ground.surface`). The grid can leave the end of a street just
    past the flat end of its ribbon, on the bare ground: for such a node the ribbon `grid` meters away counts."""
    if not len(xy):
        return np.zeros(0)
    x, y = xy[:, 0], xy[:, 1]
    z = np.array(ground.surface(x, y), dtype=np.float64)
    off = np.asarray(ground.lift(x, y)) == 0.0
    z[off] = np.maximum(z[off], ground.height(x[off], y[off]) + ground.lift(x[off], y[off], reach=grid))
    return z


def streets_json(world, plan, ground) -> dict:
    """The street graph of one city; z of a node is the drawn street top there."""
    grid = float(world.cfg["street_graph"]["grid"])
    nodes, edges = street_graph(plan.streets, grid)
    xy = np.asarray(nodes, dtype=np.float64).reshape(-1, 2)
    z = node_tops(ground, xy, grid)
    widths, _promoted'''),
])
edit("tests/test_citygen.py", [
('''        told = [e for e in eras if words["era_in"][e] in d.history or words["era_since"][e] in d.history]
''', '''        told = [e for e in eras if {words["era_in"][e].lower(), words["era_since"][e].lower()} & _phrases(d.history)]
'''),
('''def test_district_histories(world, plan):
''', '''def _phrases(text: str) -> set:
    """Every run of words of a history, in lower case."""
    words = text.lower().replace(",", " ").replace(".", " ").replace(";", " ").split()
    return {" ".join(words[a:b]) for a in range(len(words)) for b in range(a + 1, min(a + 9, len(words)) + 1)}


def test_district_histories(world, plan):
'''),
('''    z = np.array([n["z"] for n in nodes])
    assert np.allclose(z, ground.surface(xy[:, 0], xy[:, 1]), atol=0.01)
    lift = collections.Counter()   # the highest ribbon meeting at each node, from the graph's own street kinds
''', '''    z = np.array([n["z"] for n in nodes])
    on = ground.lift(xy[:, 0], xy[:, 1]) > 0.0   # the others: a street's end snapped a few cm past its ribbon
    assert np.allclose(z[on], ground.surface(xy[on, 0], xy[on, 1]), atol=0.01)
    lift = collections.Counter()   # the highest ribbon meeting at each node, from the graph's own street kinds
'''),
])
