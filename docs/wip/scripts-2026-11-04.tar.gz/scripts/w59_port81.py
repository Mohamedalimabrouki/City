"""The prompt 81 review fixes, applied to the merged citygen/city/history.py and styles/maghreb.toml."""
import sys
root = sys.argv[1]
p = root + "/citygen/city/history.py"
s = open(p).read()
def sub(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a)
    s = s.replace(a, b)

sub('''the theatre, the station, a cemetery's shrines), its souks, its households' trades and its quays.
Every choice comes from its own stream ("history", district id), so nothing else moves. A text in the world file's
`[canon.histories."<city>"]` table, keyed by the district's name, replaces the generated one.
"""''', '''the theatre, the station, a cemetery's shrines), its souks, its households' trades and its quays.
Every choice has a stream of its own ("history", district id, what it chooses), so nothing else moves and
editing one list of the style changes no other sentence. A text in the world file's
`[canon.histories."<city>"]` table, keyed by the district's name, replaces the generated one.
"""''')
sub('''    def district_at(self, x, y):
        p = Point(x, y)
        for d in self.plan.districts:
            if d.polygon.buffer(self.inside).contains(p):
                return d.id
        return None
''', '''    def district_at(self, x, y):
        """The district a point lies in, else the first one within `inside_m` of it (a gate on the wall line)."""
        p = Point(x, y)
        for d in self.plan.districts:
            if d.polygon.contains(p):
                return d.id
        for d in self.plan.districts:
            if d.polygon.buffer(self.inside).contains(p):
                return d.id
        return None
''')
sub('''def _history(ctx, style, facts, d) -> str:
    rng = ctx.rng("history", d.id)
    kind = d.kind
''', '''def _history(ctx, style, facts, d) -> str:
    kind = d.kind
''')
sub('''    fields = {"name": d.name, "city": ctx.s.name, "era": _era_in(style, era), "since": _era_since(style, era),
              "where": _where(style, facts, d), "place": place, "folk": str(folk.get(kind, folk.get("default", "")))}
    origin = style.get("origin", {}).get(kind) or style.get("origin", {}).get("residential", ["{name}."])
    if kind == "medina" and not ctx.kc.get("walls", True):   # an old town without walls: no ramparts in its story
        origin = style.get("origin", {}).get("medina_open", origin)
    if kind == "port" and facts.medina is not None and era and facts.founded < facts.eras.index(era):
        origin = style.get("origin", {}).get("port_old", origin)
        fields["old_since"] = _era_since(style, facts.eras[facts.founded])
    sentences = [_pick(rng, origin).format(**fields)]
    known = _facts(rng, style, facts, d, fields, ctx.s)
    keep = int(style.get("facts", 2))
    if len(known) > keep:
        w = [float(style.get("fact_weights", {}).get(key, 1.0)) for key, _text in known]
        idx = rng.choice(len(known), size=keep, replace=False, p=[v / sum(w) for v in w])
        known = [known[i] for i in sorted(int(i) for i in idx)]
''', '''    fields = {"name": d.name, "city": ctx.s.name, "era": _era_phrase(style, "era_in", era),
              "since": _era_phrase(style, "era_since", era),
              "where": _where(style, facts, d), "place": place, "folk": str(folk.get(kind, folk.get("default", "")))}
    origins = style["origin"]
    origin = origins.get(kind) or origins["residential"]
    if kind == "medina" and not ctx.kc.get("walls", True):   # an old town without walls: no ramparts in its story
        origin = origins.get("medina_open", origin)
    if kind == "port" and facts.medina is not None and era and facts.founded < facts.eras.index(era):
        origin = origins.get("port_old", origin)
        fields["old_since"] = _era_phrase(style, "era_since", facts.eras[facts.founded])
    sentences = [_pick(ctx, d, "origin", origin).format(**fields)]
    known = _facts(ctx, style, facts, d, fields)
    keep = int(style.get("facts", 2))
    if len(known) > keep:
        w = [float(style.get("fact_weights", {}).get(key, 1.0)) for key, _text in known]
        rng = ctx.rng("history", d.id, "facts")
        idx = rng.choice(len(known), size=keep, replace=False, p=[v / sum(w) for v in w])
        known = [known[i] for i in sorted(int(i) for i in idx)]
''')
sub('''            sentences.append(_pick(rng, today).format(**fields))
''', '''            sentences.append(_pick(ctx, d, "today", today).format(**fields))
''')
sub('''def _facts(rng, style, facts, d, fields, s) -> list:
    """(key, sentence) for each fact the map gives about this district."""
    t = {k: (_pick(rng, v) if isinstance(v, list) else v) for k, v in style.get("fact", {}).items()}
''', '''def _facts(ctx, style, facts, d, fields) -> list:
    """(key, sentence) for each fact the map gives about this district."""
    t = {k: (_pick(ctx, d, f"fact.{k}", v) if isinstance(v, list) else v) for k, v in style.get("fact", {}).items()}
''')
sub('''some=_join(gates[:2]), **fields)))''', '''some=_join(style, gates[:2]), **fields)))''')
sub('''souks=_join(list(souks.values())[:3]), **fields)))''', '''souks=_join(style, list(souks.values())[:3]), **fields)))''')
sub('''        coast = [k for k in s.known_for if k in style.get("harbor_trades", [])]
''', '''        coast = [k for k in ctx.s.known_for if k in style.get("harbor_trades", [])]
''')
sub('''trades=_join([_plural(style, w) for w in trades]), **fields)))''', '''trades=_join(style, [_plural(style, w) for w in trades]), **fields)))''')
sub('''def _era_in(style, era: str) -> str:
    """The era as a time phrase ("in the Caravan Age"), from the style's `era_in`; "" for no era."""
    return str(style.get("era_in", {}).get(era, f"in the time of {era}")) if era else ""


def _era_since(style, era: str) -> str:
    """The era as a "since" phrase ("since the Caravan Age"), from the style's `era_since`; "" for no era."""
    return str(style.get("era_since", {}).get(era, f"since the time of {era}")) if era else ""


def _pick(rng, seq):
    return str(seq[int(rng.integers(len(seq)))])
''', '''def _era_phrase(style, table: str, era: str) -> str:
    """The era as the style's `table` words it ("in the Caravan Age"), or as its `<table>_default`; "" for no era."""
    if not era:
        return ""
    return str(style.get(table, {}).get(era, str(style.get(f"{table}_default", "{era}")).format(era=era)))


def _pick(ctx, d, what: str, seq) -> str:
    """One entry of a style list, on a stream of its own: editing that list changes no other choice."""
    return str(seq[int(ctx.rng("history", d.id, what).integers(len(seq)))])
''')
sub('''def _join(items: list) -> str:
    items = [str(i) for i in items]
    if len(items) < 2:
        return "".join(items)
    return ", ".join(items[:-1]) + " and " + items[-1]
''', '''def _join(style, items: list) -> str:
    items = [str(i) for i in items]
    if len(items) < 2:
        return "".join(items)
    return ", ".join(items[:-1]) + str(style.get("and_word", ", ")) + items[-1]
''')
open(p, "w").write(s)

p = root + "/styles/maghreb.toml"
s = open(p).read()
sub('''# {place} city, town or village, {folk} "the neighborhood" or "the village". A fact given as a list: one is drawn.
''', '''# {place} city, town or village, {folk} "the neighborhood" or "the village". A fact given as a list: one is
# drawn, on a stream of its own (as are the origin, the "today" sentence and the sample of facts).
''')
sub('''# counter-clockwise from east), counts in words, and trade plurals (first matching ending swapped).
''', '''# counter-clockwise from east), counts in words, the last link of a list, and trade plurals (first matching
# ending swapped).
''')
sub('''plural = { man = "men" }
plural_default = "s"
''', '''and_word = " and "
plural = { man = "men", ry = "ries", ty = "ties", ss = "sses", ch = "ches", sh = "shes" }
plural_default = "s"
''')
sub('''# How each era reads in a sentence: {era} "in the Caravan Age", {since} "since the Caravan Age"
# (an era missing here reads "in the time of ..." and "since the time of ...")
''', '''# How each era reads in a sentence: {era} "in the Caravan Age", {since} "since the Caravan Age"; an era missing
# from these tables reads as the `_default` line (a test keeps every era of [lore] in them)
era_in_default = "in the time of {era}"
era_since_default = "since the time of {era}"
''')
open(p, "w").write(s)
