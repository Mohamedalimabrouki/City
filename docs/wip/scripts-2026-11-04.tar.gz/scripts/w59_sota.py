import sys
sys.path.insert(0, sys.argv[1])
from shapely.geometry import Polygon, Point
from citygen.config import load_config
from citygen.world import generate_world
w = generate_world(load_config())
s = next(x for x in w.settlements if x.name == "Sota")
d = sorted((Polygon(k.polygon).distance(Point(s.x, s.y)) - s.radius, k.id, k.salt, round(Polygon(k.polygon).area / 1e6, 1)) for k in w.lakes)[:3]
print(sys.argv[1][-12:], "Sota radius", round(s.radius), "nearest lakes (gap from its edge, id, salt, km2):", [(round(a), b, c, e) for a, b, c, e in d])
