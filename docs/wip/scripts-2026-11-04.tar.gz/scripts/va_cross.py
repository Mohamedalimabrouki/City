"""How far a crossing's ends lie from the street graph, on the river towns of the 64 km world. Run from a tree."""
import sys

import numpy as np
import shapely

sys.path.insert(0, '.')
from citygen.city import plan_city
from citygen.config import load_config
from citygen.export.streets import street_graph
from citygen.world import generate_world

w = generate_world(load_config())
grid = float(w.cfg["street_graph"]["grid"])
names = sys.argv[1:] or ['Bordj Zasakel']
for s in w.settlements:
    if s.name not in names:
        continue
    p = plan_city(w, s)
    nodes, edges = street_graph(p.streets, grid)
    xy = np.array(nodes)
    lines = shapely.union_all([st.line for st in p.streets])
    rows = []
    for c in p.crossings:
        for q in (c.line.coords[0], c.line.coords[-1]):
            rows.append((round(float(np.hypot(*(xy - np.asarray(q)).T).min()), 1), round(float(shapely.distance(shapely.points(q), lines)), 1), c.kind, round(c.line.length, 1)))
    rows.sort(reverse=True)
    print(s.name, 'crossings', len(p.crossings), 'farthest ends: (to a node, to a street, kind, length)', rows[:6])
