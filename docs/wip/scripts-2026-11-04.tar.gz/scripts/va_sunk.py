import sys
sys.path.insert(0,'.')
from pathlib import Path
from citygen.interior.context import city_plan, layout_of, load_build
from citygen.city.dressing import building_highs
from citygen.interior.layout import plan_interior
from citygen.interior.outside import Outside
from citygen.interior import rooms
ctx=load_build(Path(sys.argv[1]),log=lambda m:None)
plan=city_plan(ctx); style=ctx.world.style
dresser,ground=ctx.dresser(plan),ctx.ground
houses=[k for k,b in enumerate(plan.buildings) if b.kind=='house' and layout_of(plan,b,style) in ('dar','compact','small')]
highs=dict(zip(houses,building_highs(ground,[plan.buildings[k] for k in houses])))
climb={k:max((float(highs[k])-s.z for s in dresser.entrances(k)),default=0.0) for k in houses}
print('top climbs',[(k,round(climb[k],2)) for k in sorted(houses,key=lambda k:(-climb[k],k))[:12]])
n=0
for k in sorted(houses,key=lambda k:(-climb[k],k))[:80]:
    it=plan_interior(Outside(ctx,plan,k),style)
    st=it.storeys[0]
    sunk=next((r for r in it.rooms if r.floor==0 and r.z<st.z-0.05),None)
    if sunk is None: continue
    fl=[s for s in it.stairs if s.kind=='steps']
    inner=[o for o in it.openings if sunk.id in o.rooms and o.kind=='inner']
    b=plan.buildings[k]
    print(k,layout_of(plan,b,style),'climb',round(climb[k],2),'floors',b.floors,'rooms f0',[(r.id,getattr(r,'use',getattr(r,'name','?')),round(r.polygon.area,1)) for r in it.rooms if r.floor==0],'flights',len(fl),'inner',len(inner),'problems',[p[:70] for p in rooms.check(it)][:3])
    n+=1
    if n>=6: break
k=344
it=plan_interior(Outside(ctx,plan,k),style)
print([(r.id,r.type,round(r.z,2),round(r.polygon.area,1)) for r in it.rooms if r.floor==0])
print('storey z',it.storeys[0].z)
for o in it.openings:
    if o.rooms and (0 in o.rooms or it.rooms[0].id in o.rooms): print('opening',o.kind,o.rooms,round(o.z0,2),getattr(o,'width',None))
print([ (s.kind,s.sunk,s.turn,round(s.width,2),s.risers,s.door) for s in it.stairs])
sunk=next((r for r in it.rooms if r.floor==0 and r.z<it.storeys[0].z-0.05),None)
print('sunk',sunk.id,sunk.type)
for o in it.openings:
    if sunk.id in o.rooms: print('opening of sunk',o.kind,o.rooms,round(o.z0,2))
