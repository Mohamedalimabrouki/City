import sys, numpy as np, shapely
from shapely.geometry import LineString, Point, Polygon
sys.path.insert(0, '.')
from citygen.config import load_config
from citygen.world import generate_world
w = generate_world(load_config())
for rid in (0, 1, 3, 10):
    r = w.rivers[rid]; n = len(r.coords)
    print('river', rid, [tuple(np.round(r.coords[int(n*f)]).tolist()) for f in (0.25, .5, .75)], 'z', [round(float(r.profile[int(n*f)]),1) for f in (.25,.5,.75)], 'w', round(float(r.widths[n//2]),1))
cap = w.capital()
print('capital', cap.x, cap.y, cap.radius)
for s in w.settlements:
    if s.kind in ('capital','city','town'):
        near = [(r.id, round(LineString(r.coords).distance(Point(s.x,s.y)))) for r in w.rivers if LineString(r.coords).distance(Point(s.x,s.y)) < s.radius*1.15]
        if near: print(s.kind, s.id, s.name, round(s.x), round(s.y), 'r', round(s.radius), near[:6])
