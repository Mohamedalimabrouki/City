import sys,collections; sys.path.insert(0,'.')
from citygen.interior.context import city_plan, load_build, layout_of
from citygen.interior.layout import plan_interior
from citygen.interior.outside import Outside
ctx=load_build('output/bodjantouna-42',log=lambda m:None); plan=city_plan(ctx,None); style=ctx.world.style
c=collections.Counter(); n=0; kinds=collections.Counter()
for k,b in enumerate(plan.buildings):
    if b.kind not in("house","apartments"): continue
    lay=layout_of(plan,b,style)
    if lay not in('colonial','slab','maison'): continue
    n+=1
    if n%4: continue
    it=plan_interior(Outside(ctx,plan,k),style)
    for o in it.openings:
        if o.kind=='balcony':
            r=it.rooms[o.rooms[0]] if o.rooms[0]>=0 else None
            c[(lay,'door-window' if o.piece.startswith('window_door') else 'slab door' if o.piece.startswith('balcony_slab') else o.piece, r.type if r else 'none')]+=1
for x,y in sorted(c.items(),key=lambda t:(t[0][0],t[0][1],-t[1])): print(y,x)
