#!/bin/zsh
# usage: va_shots.sh NAME X Y Z(look height) [dist] [up] : box round X,Y (meters), camera off to the south-west
PY=/Users/mohamedalimabrouki/Desktop/City/.venv/bin/python
name=$1; x=$2; y=$3; z=$4; dist=${5:-420}; up=${6:-190}
x0=$(( (x-800)/1000.0 )); y0=$(( (y-800)/1000.0 )); x1=$(( (x+800)/1000.0 )); y1=$(( (y+800)/1000.0 ))
cd /tmp/claude-501/valleys
$PY -m citygen build --area box:$x0,$y0,$x1,$y1 --out /tmp/claude-501/va_out/$name 2>&1 | tail -1
cx=$(( x-dist*0.7 )); cy=$(( y-dist*0.7 )); cz=$(( z+up ))
$PY tools/snapshot.py /tmp/claude-501/va_out/$name/bodjantouna-42 --png /tmp/claude-501/va_shots/$name.png --view aerial --width 1200 --height 760 --gpu --query "cam=$cx,$cy,$cz&look=$x,$y,$z&ui=0" 2>&1 | tail -1
