import sys, collections, time
sys.path.insert(0, ".")
from citygen.config import load_config
from citygen.world import generate_world
from citygen.city import plan_city
from citygen.interior import rooms
from citygen.interior.context import BuildContext, layout_of
from citygen.interior.layout import plan_interior
from citygen.interior.outside import Outside
world = generate_world(load_config(quick=True))
towns = sorted((s for s in world.settlements if s.kind == "town"), key=lambda s: -s.population)
town = plan_city(world, towns[0])
print(towns[0].name, collections.Counter(b.floors for b in town.buildings if b.kind == "villa"), collections.Counter(layout_of(town, b, world.style) for b in town.buildings if b.kind == "villa"))
ctx = BuildContext(world, [town], town.settlement)
vs = sorted((b.footprint.area, k) for k, b in enumerate(town.buildings) if layout_of(town, b, world.style) == "villa" and b.floors == 1)
print("one floor villas", len(vs), "areas", round(vs[0][0], 1), round(vs[len(vs)//2][0], 1), round(vs[-1][0], 1))
t = time.time(); rows = []
for a, k in vs[:int(sys.argv[1])]:
    i = plan_interior(Outside(ctx, town, k), world.style)
    rows.append((k, round(a, 1), i.layout, not rooms.check(i), any(r.type == "couloir" for r in i.rooms), sorted(r.type for r in i.rooms if r.type not in ("couloir",))[:7]))
print(round(time.time() - t, 1), "s")
for r in rows[:14]: print(r)
print("no couloir", [r[0] for r in rows if not r[4]], "pass and no couloir", [r[0] for r in rows if r[3] and not r[4]])
print("smallest", len(rows), "pass", sum(r[3] for r in rows), "with hall salon cuisine", sum({"hall", "salon", "cuisine"} <= set(r[5]) for r in rows))
