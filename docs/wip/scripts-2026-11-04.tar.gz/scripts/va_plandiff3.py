import json, sys
from shapely.geometry import shape
a=json.load(open(sys.argv[1])); b=json.load(open(sys.argv[2]))
print(type(a['districts'][0]['geometry']), str(a['districts'][0]['geometry'])[:100])
for da in a['districts']:
    db=next(d for d in b['districts'] if d['id']==da['id'])
    pa,pb=shape(da['geometry']),shape(db['geometry'])
    print(da['id'],da['kind'],'area',round(pa.area),round(pb.area),'xor',round(pa.symmetric_difference(pb).area,2),'centroid moved',round(pa.centroid.distance(pb.centroid),3))
sa={json.dumps(s.get('coords') or s.get('geometry')):s.get('kind') for s in a['streets']}
sb={json.dumps(s.get('coords') or s.get('geometry')):s.get('kind') for s in b['streets']}
import collections
print('streets by kind base',collections.Counter(sa.values()))
print('kept by kind',collections.Counter(v for k,v in sa.items() if k in sb))
print(list(a['buildings'][0]))
