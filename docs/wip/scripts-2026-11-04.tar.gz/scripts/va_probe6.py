import sys, numpy as np, shapely
from shapely.geometry import LineString, Point, Polygon
sys.path.insert(0,'.')
import citygen.world as W
from citygen.config import load_config
cfg=load_config()
orig=W._smooth
log=[]
def spy(xy,tol):
    out=orig(xy,tol); log.append((xy.copy(),out)); return out
W._smooth=spy
w=W.generate_world(cfg)
lake=Polygon(w.lakes[37].polygon).buffer(0)
print('lake area',lake.area/1e6, lake.is_valid, w.lakes[37].level, lake.bounds)
for xy,out in log:
    l=LineString(xy)
    if l.intersects(lake) or LineString(out).intersects(lake):
        print('raw crosses',l.intersects(lake),'smoothed crosses',LineString(out).intersects(lake),'len',round(l.length),len(xy),len(out))
        print(np.round(xy[:: max(1,len(xy)//30)],0).tolist())
        print('dist raw to lake',round(l.distance(lake),1))
