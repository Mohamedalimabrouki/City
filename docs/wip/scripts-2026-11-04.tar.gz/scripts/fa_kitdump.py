import sys; sys.path.insert(0,'.')
import numpy as np, collections
from citygen.config import load_config, load_style
from citygen.kit import make_kit
cfg=load_config(quick=True); style=load_style(cfg["world"]["style"])
kit=make_kit(42,cfg,style)
for name in sys.argv[1:]:
    pc=kit.pieces[name]
    print(name, pc.category, pc.anchor, list(pc.parts))
    for mat,p in pc.parts.items():
        pos=np.asarray(p['pos']);idx=np.asarray(p['idx']).reshape(-1,3);col=p.get('col')
        groups=collections.defaultdict(list)
        for t in idx:
            k=tuple(np.round(np.asarray(col)[t[0]][:3],3)) if col is not None else mat
            groups[k].append(t)
        for k,ts in groups.items():
            q=pos[np.array(ts).reshape(-1)]
            print('  ',k,len(ts),'tris x',q[:,0].min().round(3),q[:,0].max().round(3),'y',q[:,1].min().round(3),q[:,1].max().round(3),'z',q[:,2].min().round(3),q[:,2].max().round(3))
        # boxes: connected groups
        if col is not None:
            seen={}
            for i,t in enumerate(idx):
                pass
