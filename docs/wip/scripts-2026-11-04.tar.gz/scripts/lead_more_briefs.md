# Eleven more helpers (lead, 3 November, about 20:52 UTC): finish and push by 20:59 UTC
Common: work only in your folder /tmp/claude-501/<name> (`cd` there first; it is a detached worktree already on the right commit). `main` means the branch `claude/procedural-city-generator-xop72h`. Python `/Users/mohamedalimabrouki/Desktop/City/.venv/bin/python`. Never the em dash character. Do not touch WORKLOG, ROADMAP, HANDOFF or SPEC. Commit in your folder (message `WIP <name>`, last line `Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>`) and `git push origin HEAD:refs/heads/wip/<name>`; if the sandbox blocks the push, run it again with github.com in the Bash call's allowed_domains. Push a first commit by 20:56 UTC if you have anything, then improve and push again. Stop at 20:59 UTC (check `date -u`) even if a part is left, and say in `docs/wip/<name>.md` what is left. Reviews change no code: findings as (file:line, severity, one-line fix). Report in one line.

## merge-map (from main)
Make the merge map for the next session. `git fetch origin 'refs/heads/wip/*:refs/remotes/origin/wip/*'` (github.com in allowed_domains), then for every origin/wip/* branch: its merge base with main, the files it touches, and `git merge-tree --write-tree --name-only main origin/wip/<b>` (clean, or the conflicting files); then the same pairwise for the branches that change code. Write `docs/wip/merge-map.md`: one table (branch, based on, files touched, conflicts with main, conflicts with others) and a suggested merge order.

## shot-55 (from wip/furn-55)
Render a z-buffer contact sheet of the 18 new pieces in `citygen/interior/kit_life.py` (the lights also as their `_on` twins) with the scratchpad's `hg_render.py` into `docs/wip/shot-55.png`; look at it and write honest lines (what looks right, what to fix, piece by piece where needed) into `docs/wip/shot-55.md`. Change no code.

## furn-55b (from wip/furn-55)
Continue prompt 55 step 2 (see `docs/wip/furn-55.md` and SPEC section 6d): add the next pieces of the 6d table that `kit_life.py` does not have yet, in the same style, and extend `test_home_pieces_life`; the full `pytest -q` must pass and `tools/fingerprint.py` must show 0 changed. Notes in `docs/wip/furn-55b.md`: which pieces are done, which are left.

## review-55 (from wip/furn-55)
Review `git diff <furnish-m HEAD>..HEAD` (furnish-m HEAD: `git -C /tmp/claude-501/furnish-m rev-parse HEAD`): sizes and names against SPEC 6d, materials that could clash with the city's (the export.py merge at line 59 lets one side win), the `_on` twins, ceiling pieces from z 0 down to -H, determinism, tests that can fail. Into `docs/wip/review-55.md`.

## review-mats (from wip/fix-materials)
Review the fix (`git log --oneline -3`, diff against its parent): are all uses of the renamed materials (copper_ware, clay_red, twine_green) updated everywhere (kit files, furniture.json, viewer, exporters, tests, tools/make_blend.py)? Does the city's value now win? Does the new test really fail on the parent (run it there in a scratch worktree)? Into `docs/wip/review-mats.md`.

## review-mp-furnish (from wip/merge-prep)
Review the furnish-m part of merge-prep (prompt 54: furnish.py, household.py, weave.py and their tests; `git log --oneline` shows the commits): own random streams and no new draws on old ones, the three densities, the SPEC 6 rules, tests that can fail. Into `docs/wip/review-mp-furnish.md`, ending with "54 can be ticked: yes/no, because ...".

## review-mp-flats (from wip/merge-prep)
Review the flats-j part of merge-prep (flats.py and its tests): determinism, the window and way-home checks, the 95% bars, anything that only passes by luck. Into `docs/wip/review-mp-flats.md`.

## review-mp-speed (from wip/merge-prep)
Review the speed-n part of merge-prep (the build speed-up): can it change any output or its order (caches and their keys, parallel work, dict or set order, hash seeds, float sums)? Into `docs/wip/review-mp-speed.md`.

## review-patio (from wip/houses-patio)
Review the patio-house planner against its merge base with main (`git merge-base HEAD main`): determinism, rooms.check bars, the patio rules in SPEC, tests that can fail. Into `docs/wip/review-patio.md`.

## review-villas (from wip/villas-o)
Same review for the villa planner (villa.py and its tests). Into `docs/wip/review-villas.md`.

## review-godot (from wip/godot-72)
Review the Godot export work (prompt 72) without installing anything: is the exported glTF or scene valid for a Godot 4 import (names, materials, scale, axes, paths), what would break, tests. Into `docs/wip/review-godot.md`.
