"""For palms off every walk inside two ribbons: the angle between the two streets there; a sheet of the ring cases."""
import math
import os
import pickle
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import shapely
from shapely import STRtree
from shapely.geometry import box

sys.path.insert(0, "/Users/mohamedalimabrouki/Desktop/City")
from citygen.interior.context import load_build  # noqa: E402

ctx = load_build(Path(sys.argv[1]), log=lambda *a: None)
extra = pickle.loads((Path(os.environ["TMPDIR"]) / "det" / "plans45.pkl").read_bytes())
plans = [ctx.plans[0], *extra]


def direction(line, p):
    d = line.project(p)
    a, b = line.interpolate(max(d - 1.0, 0.0)), line.interpolate(min(d + 1.0, line.length))
    return math.atan2(b.y - a.y, b.x - a.x)


hist = defaultdict(Counter)
examples = {}
for plan in plans:
    if not plan.trees or not plan.walks:
        continue
    ribbons = np.array([st.line.buffer(st.width / 2 - 0.5, cap_style="flat") for st in plan.streets], dtype=object)
    tp = shapely.points([(t.x, t.y) for t in plan.trees])
    on_walk = np.zeros(len(tp), bool)
    on_walk[STRtree(np.array([w.polygon for w in plan.walks], dtype=object)).query(tp, predicate="dwithin", distance=0.4)[0]] = True
    ti, ri = STRtree(ribbons).query(tp, predicate="within")
    hits = defaultdict(list)
    for t_i, r_i in zip(ti.tolist(), ri.tolist()):
        hits[t_i].append(r_i)
    for t_i, rs in hits.items():
        if on_walk[t_i] or len(rs) < 2:
            continue
        rows = [r for r in rs if plan.streets[r].kind in ("boulevard", "corniche")]
        own = min(rows, key=lambda r: abs(plan.streets[r].line.distance(tp[t_i]) - (plan.streets[r].width / 2 - 2.5)))
        for r in rs:
            if r == own:
                continue
            a = abs(direction(plan.streets[own].line, tp[t_i]) - direction(plan.streets[r].line, tp[t_i])) % math.pi
            a = math.degrees(min(a, math.pi - a))
            key = f"{plan.streets[own].kind} row, {plan.streets[r].kind}"
            hist[key][int(a // 10) * 10] += 1
            if a < 10 and key not in examples:
                examples[key] = (plan, tp[t_i].x, tp[t_i].y, f"{plan.settlement.name}: {key} at {a:.0f} deg")
for key, h in sorted(hist.items()):
    print(f"  {key}: " + ", ".join(f"{k}-{k + 10} deg: {v}" for k, v in sorted(h.items())))

from PIL import Image, ImageDraw  # noqa: E402
W, R = 380, 60.0
cases = list(examples.values())[:3]
sheet = Image.new("RGB", (W * max(1, len(cases)), W), "white")
for n, (plan, cx, cy, label) in enumerate(cases):
    img = Image.new("RGB", (W, W), (214, 205, 180))
    dr = ImageDraw.Draw(img)
    view = box(cx - R, cy - R, cx + R, cy + R)

    def px(pts):
        return [((x - cx + R) / (2 * R) * W, (cy + R - y) / (2 * R) * W) for x, y in pts]

    colors = {"corniche": (120, 120, 120), "ring": (150, 110, 110), "boulevard": (110, 110, 150)}
    for st in sorted(plan.streets, key=lambda s: -s.width):
        if st.line.intersects(view.buffer(40)):
            poly = st.line.buffer(st.width / 2, cap_style="flat")
            for g in getattr(poly, "geoms", [poly]):
                dr.polygon(px(g.exterior.coords), fill=colors.get(st.kind, (135, 135, 135)), outline=(60, 60, 60))
    for w in plan.walks:
        if w.polygon.intersects(view):
            for g in getattr(w.polygon, "geoms", [w.polygon]):
                dr.polygon(px(g.exterior.coords), fill=(200, 200, 200))
    for b in plan.buildings:
        if b.footprint.intersects(view):
            dr.polygon(px(b.footprint.exterior.coords), fill=(236, 226, 205), outline=(70, 60, 50))
    for t in plan.trees:
        if abs(t.x - cx) < R and abs(t.y - cy) < R:
            (u, v), = px([(t.x, t.y)])
            hot = math.hypot(t.x - cx, t.y - cy) < 1.5
            r = 4 if hot else 3
            dr.ellipse([u - r, v - r, u + r, v + r], fill=(220, 30, 30) if hot else (40, 130, 50))
    dr.rectangle([0, 0, W - 1, 15], fill="white")
    dr.text((4, 2), f"{label} ({2 * R:.0f} m wide)", fill="black")
    sheet.paste(img, (n * W, 0))
out = "/Users/mohamedalimabrouki/Desktop/City/output/checks/codecheck-along.png"
sheet.save(out)
print("sheet:", out, [c[3] for c in cases])
