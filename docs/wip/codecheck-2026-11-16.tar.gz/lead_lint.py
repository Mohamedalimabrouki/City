"""Cheap static checks over citygen/ and tools/ (stdlib only). Usage: lead_lint.py [kind ...] [--max N]"""
import ast
import builtins
import symtable
import sys
import warnings
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path("/Users/mohamedalimabrouki/Desktop/City")
FILES = sorted([*ROOT.glob("citygen/**/*.py"), *ROOT.glob("tools/*.py")])
OUT = []
CHECKED = Counter()
SAFE_DECOS = {"lru_cache", "cache", "staticmethod", "classmethod", "dataclass"}


def say(mod, node, kind, text):
    line = node if isinstance(node, int) else getattr(node, "lineno", 0)
    OUT.append((kind, str(mod.path.relative_to(ROOT)), line, text))


def names_in(target):
    return [x.id for x in ast.walk(target) if isinstance(x, ast.Name)]


class Mod:
    def __init__(self, path):
        self.path = path
        self.src = path.read_text(encoding="utf-8")
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            self.tree = ast.parse(self.src, str(path))
            compile(self.src, str(path), "exec")
        self.warns = caught
        parts = list(path.relative_to(ROOT).with_suffix("").parts)
        self.is_pkg = parts[-1] == "__init__"
        if self.is_pkg:
            parts.pop()
        self.name = ".".join(parts)
        self.pkg = self.name if self.is_pkg else ".".join(parts[:-1])
        self.top, self.star, self.dyn = {}, False, False
        self._collect(self.tree.body)

    def resolve_from(self, n):
        if n.level == 0:
            return n.module
        base = self.pkg.split(".") if self.pkg else []
        if n.level > 1:
            base = base[: len(base) - (n.level - 1)]
        return ".".join(base + ([n.module] if n.module else []))

    def import_entries(self, n):
        if isinstance(n, ast.Import):
            for a in n.names:
                yield (a.asname or a.name.split(".")[0]), ("import", a.name if a.asname else a.name.split(".")[0], None)
        else:
            base = self.resolve_from(n)
            for a in n.names:
                if a.name == "*":
                    self.star = True
                    continue
                yield (a.asname or a.name), ("import", base, a.name)

    def _collect(self, body):
        for n in body:
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self.top[n.name] = ("def", n)
                self.dyn |= n.name == "__getattr__"
            elif isinstance(n, ast.ClassDef):
                self.top[n.name] = ("class", n)
            elif isinstance(n, (ast.Import, ast.ImportFrom)):
                self.top.update(self.import_entries(n))
            elif isinstance(n, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
                for t in (n.targets if isinstance(n, ast.Assign) else [n.target]):
                    for name in names_in(t):
                        self.top[name] = ("var", n)
            elif isinstance(n, (ast.If, ast.Try, ast.With, ast.For, ast.While)):
                if isinstance(n, ast.For):
                    for name in names_in(n.target):
                        self.top[name] = ("var", n)
                if isinstance(n, ast.With):
                    for it in n.items:
                        for name in (names_in(it.optional_vars) if it.optional_vars is not None else []):
                            self.top[name] = ("var", n)
                for field in ("body", "orelse", "finalbody"):
                    self._collect(getattr(n, field, None) or [])
                for h in getattr(n, "handlers", None) or []:
                    self._collect(h.body)


MODS = {}
for _p in FILES:
    _m = Mod(_p)
    MODS[_m.name] = _m


def lookup(modname, name, depth=0):
    """("def"|"class", node, Mod) | ("module", Mod) | ("var",) | None (cannot tell) | "missing"."""
    m = MODS.get(modname)
    if m is None or depth > 6:
        return None
    hit = m.top.get(name)
    if hit is None:
        sub = MODS.get(f"{modname}.{name}")
        if sub is not None:
            return ("module", sub)
        return None if (m.star or m.dyn) else "missing"
    return resolve_entry(hit, m, depth)


def resolve_entry(hit, m, depth=0):
    if hit[0] == "import":
        _, base, orig = hit
        if orig is None:
            return ("module", MODS[base]) if base in MODS else None
        if base in MODS:
            return lookup(base, orig, depth + 1)
        if f"{base}.{orig}" in MODS:
            return ("module", MODS[f"{base}.{orig}"])
        return None
    if hit[0] in ("def", "class"):
        return (hit[0], hit[1], m)
    return ("var",)


def deco_name(d):
    if isinstance(d, ast.Call):
        return deco_name(d.func)
    return d.attr if isinstance(d, ast.Attribute) else getattr(d, "id", "?")


def sig(fn, drop=0):
    decos = {deco_name(d) for d in fn.decorator_list}
    if decos - SAFE_DECOS:
        return None
    a = fn.args
    pos = [x.arg for x in a.posonlyargs + a.args]
    required = pos[: len(pos) - len(a.defaults)]
    posonly = len(a.posonlyargs)
    if "staticmethod" in decos:
        drop = 0
    pos, required, posonly = pos[drop:], required[drop:], max(0, posonly - drop)
    return {"pos": pos, "posonly": posonly, "required": required, "kwonly": [x.arg for x in a.kwonlyargs],
            "kwreq": [x.arg for x, d in zip(a.kwonlyargs, a.kw_defaults) if d is None],
            "var": a.vararg is not None, "kw": a.kwarg is not None}


def dc_fields(node, mod, depth=0):
    """[(name, has_default)] of a dataclass, bases first; None when it cannot be told."""
    if depth > 4 or "dataclass" not in {deco_name(d) for d in node.decorator_list}:
        return None
    fields = []
    for b in node.bases:
        r = lookup(mod.name, b.id) if isinstance(b, ast.Name) else None
        if not r or r == "missing" or r[0] != "class":
            return None
        got = dc_fields(r[1], r[2], depth + 1)
        if got is None:
            return None
        fields += got
    for n in node.body:
        if isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name):
            if "ClassVar" in ast.unparse(n.annotation):
                continue
            has = n.value is not None
            if isinstance(n.value, ast.Call) and deco_name(n.value.func) == "field":
                kws = {k.arg: k.value for k in n.value.keywords}
                if isinstance(kws.get("init"), ast.Constant) and kws["init"].value is False:
                    continue
                has = "default" in kws or "default_factory" in kws
            fields = [f for f in fields if f[0] != n.target.id] + [(n.target.id, has)]
    return fields


def class_sig(node, mod):
    init = next((b for b in node.body if isinstance(b, ast.FunctionDef) and b.name == "__init__"), None)
    if init is not None:
        return sig(init, 1)
    decos = {deco_name(d) for d in node.decorator_list}
    if "dataclass" in decos:
        fields = dc_fields(node, mod)
        if fields is None:
            return None
        kwonly = any(isinstance(d, ast.Call) and any(k.arg == "kw_only" for k in d.keywords) for d in node.decorator_list)
        names = [f[0] for f in fields]
        req = [f[0] for f in fields if not f[1]]
        if kwonly:
            return {"pos": [], "posonly": 0, "required": [], "kwonly": names, "kwreq": req, "var": False, "kw": False}
        return {"pos": names, "posonly": 0, "required": req, "kwonly": [], "kwreq": [], "var": False, "kw": False}
    if not node.bases and not decos and not any(isinstance(b, ast.FunctionDef) and b.name == "__new__" for b in node.body):
        return {"pos": [], "posonly": 0, "required": [], "kwonly": [], "kwreq": [], "var": False, "kw": False}
    return None


def call_problems(call, s):
    star = any(isinstance(a, ast.Starred) for a in call.args)
    dstar = any(k.arg is None for k in call.keywords)
    npos = sum(not isinstance(a, ast.Starred) for a in call.args)
    kws = [k.arg for k in call.keywords if k.arg]
    out = []
    if not s["var"] and npos > len(s["pos"]):
        out.append(f"{npos} positional arguments, at most {len(s['pos'])}")
    for k in kws:
        if k not in s["pos"][s["posonly"]:] and k not in s["kwonly"] and not s["kw"]:
            out.append(f"unknown keyword {k!r}")
        elif not star and k in s["pos"][:npos]:
            out.append(f"{k!r} given twice")
    if not star and not dstar:
        out += [f"missing {r!r}" for i, r in enumerate(s["required"]) if s["pos"].index(r) >= npos and r not in kws]
    if not dstar:
        out += [f"missing keyword {r!r}" for r in s["kwreq"] if r not in kws]
    return out


def local_bindings(fn):
    bound, imports, defs = set(), {}, {}
    a = fn.args
    for x in a.posonlyargs + a.args + a.kwonlyargs + [v for v in (a.vararg, a.kwarg) if v]:
        bound.add(x.arg)
    body = fn.body if isinstance(fn.body, list) else [fn.body]
    stack = list(body)
    while stack:
        n = stack.pop()
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
            defs[n.name] = None if n.name in defs or n.name in bound else n
            continue
        if isinstance(n, ast.ClassDef):
            bound.add(n.name)
            continue
        if isinstance(n, ast.Lambda):
            continue
        if isinstance(n, ast.Name) and isinstance(n.ctx, (ast.Store, ast.Del)):
            bound.add(n.id)
        elif isinstance(n, ast.ExceptHandler) and n.name:
            bound.add(n.name)
        stack.extend(ast.iter_child_nodes(n))
    return bound, imports, defs


class Calls:
    """Walk a module: check calls to package functions, classes and methods; attributes of package modules."""

    def __init__(self, mod):
        self.mod = mod
        self.scopes, self.classes = [], []
        self.visit(mod.tree)

    def resolve(self, name):
        for bound, imports, defs in reversed(self.scopes):
            if name in bound:
                return None
            if name in defs:
                return ("def", defs[name], self.mod) if defs[name] is not None else None
            if name in imports:
                return resolve_entry(imports[name], self.mod)
        r = lookup(self.mod.name, name)
        return None if r == "missing" else r

    def visit(self, node):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)):
            bound, imports, defs = local_bindings(node)
            for n in ast.walk(node) if not isinstance(node, ast.Lambda) else []:
                if isinstance(n, (ast.Import, ast.ImportFrom)):
                    for local, entry in self.mod.import_entries(n):
                        if local not in bound:
                            imports.setdefault(local, entry)
            self.scopes.append((bound, imports, defs))
            for c in ast.iter_child_nodes(node):
                self.visit(c)
            self.scopes.pop()
            return
        if isinstance(node, ast.ClassDef):
            self.classes.append(node)
            for c in ast.iter_child_nodes(node):
                self.visit(c)
            self.classes.pop()
            return
        if isinstance(node, ast.Call):
            self.call(node)
        elif isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name) and isinstance(node.ctx, ast.Load):
            r = self.resolve(node.value.id)
            if r and r[0] == "module" and lookup(r[1].name, node.attr) == "missing":
                say(self.mod, node, "attr", f"{node.value.id}.{node.attr}: module {r[1].name} has no such name")
        for c in ast.iter_child_nodes(node):
            self.visit(c)

    def call(self, node):
        f, target, drop, label = node.func, None, 0, ""
        if isinstance(f, ast.Name):
            target, label = self.resolve(f.id), f.id
        elif isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name):
            label = f"{f.value.id}.{f.attr}"
            if f.value.id in ("self", "cls") and self.classes and self.scopes and f.value.id in self.scopes[-1][0]:
                meth = [b for b in self.classes[-1].body if isinstance(b, ast.FunctionDef) and b.name == f.attr]
                if len(meth) == 1 and not ({deco_name(d) for d in meth[0].decorator_list} - {"staticmethod", "classmethod"}):
                    target, drop = ("def", meth[0], self.mod), 1
            else:
                r = self.resolve(f.value.id)
                if r and r[0] == "module":
                    target = lookup(r[1].name, f.attr)
                    target = None if target == "missing" else target
                elif r and r[0] == "class":
                    meth = [b for b in r[1].body if isinstance(b, ast.FunctionDef) and b.name == f.attr]
                    decos = {deco_name(d) for d in meth[0].decorator_list} if len(meth) == 1 else {"?"}
                    if decos and not (decos - {"staticmethod", "classmethod"}):
                        target, drop = ("def", meth[0], r[2]), 1
        if not target or target[0] not in ("def", "class"):
            return
        s = sig(target[1], drop) if target[0] == "def" else class_sig(target[1], target[2])
        if s is None:
            return
        CHECKED[target[0]] += 1
        for p in call_problems(node, s):
            say(self.mod, node, "call", f"{label}(...): {p}  [defined {target[2].path.name}:{target[1].lineno}]")


def check_imports(mod):
    for n in ast.walk(mod.tree):
        if isinstance(n, ast.ImportFrom):
            base = mod.resolve_from(n)
            if base in MODS:
                for a in n.names:
                    if a.name != "*" and lookup(base, a.name) == "missing":
                        say(mod, n, "import", f"from {base} import {a.name}: no such name")
            elif n.level > 0 and not any(f"{base}.{a.name}" in MODS for a in n.names):
                say(mod, n, "import", f"module {base} not found")


def check_unused_imports(mod):
    if mod.is_pkg:
        return
    used = {n.id for n in ast.walk(mod.tree) if isinstance(n, ast.Name)}
    used |= {n.value for n in ast.walk(mod.tree) if isinstance(n, ast.Constant) and isinstance(n.value, str) and n.value.isidentifier()}
    for n in ast.walk(mod.tree):
        if isinstance(n, (ast.Import, ast.ImportFrom)) and not (isinstance(n, ast.ImportFrom) and n.module == "__future__"):
            for a in n.names:
                local = a.asname or a.name.split(".")[0]
                if local != "*" and local not in used:
                    say(mod, n, "unused-import", local)


def check_symbols(mod):
    table = symtable.symtable(mod.src, str(mod.path), "exec")
    top = set(mod.top) | {"__file__", "__name__", "__doc__", "__package__", "__spec__", "__builtins__"}
    globals_assigned = set()

    def gather(t):
        for s in t.get_symbols():
            if t.get_type() != "module" and s.is_declared_global() and s.is_assigned():
                globals_assigned.add(s.get_name())
        for c in t.get_children():
            gather(c)

    gather(table)
    top |= globals_assigned
    first = {}
    for n in ast.walk(mod.tree):
        if isinstance(n, ast.Name):
            first.setdefault((n.id, type(n.ctx).__name__), n.lineno)
    simple = defaultdict(set)   # function line -> names bound by a plain `x = ...`
    for fn in ast.walk(mod.tree):
        if isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
            stack = list(fn.body)
            while stack:
                n = stack.pop()
                if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)):
                    continue
                if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name):
                    simple[fn.lineno].add((n.targets[0].id, n.lineno))
                elif isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name) and n.value is not None:
                    simple[fn.lineno].add((n.target.id, n.lineno))
                stack.extend(ast.iter_child_nodes(n))

    def walk(t):
        kind = t.get_type()
        kind = getattr(kind, "value", kind)
        for s in t.get_symbols():
            name = s.get_name()
            if kind == "module":
                missing = s.is_referenced() and not (s.is_assigned() or s.is_imported() or s.is_namespace())
            else:
                missing = s.is_referenced() and s.is_global()
            if missing and name not in top and not hasattr(builtins, name) and not mod.star:
                say(mod, first.get((name, "Load"), t.get_lineno()), "undefined", f"{name} (in {t.get_name()})")
            if kind == "function" and s.is_local() and s.is_assigned() and not s.is_referenced() \
                    and not s.is_parameter() and not name.startswith("_"):
                if any(c.lookup(name).is_free() for c in t.get_children() if name in c.get_identifiers()):
                    continue
                lines = sorted(ln for nm, ln in simple.get(t.get_lineno(), ()) if nm == name)
                if lines:
                    say(mod, lines[0], "unused-var", f"{name} (in {t.get_name()})")
        for c in t.get_children():
            walk(c)

    walk(table)


def falls(mod, stmts, report=True):
    for i, s in enumerate(stmts):
        if not stmt_falls(mod, s):
            if report and i + 1 < len(stmts):
                say(mod, stmts[i + 1], "unreachable", "code after return/raise/continue/break")
            return False
    return True


def has_break(loop):
    stack = list(loop.body)
    while stack:
        n = stack.pop()
        if isinstance(n, ast.Break):
            return True
        if isinstance(n, (ast.For, ast.While, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)):
            continue
        stack.extend(ast.iter_child_nodes(n))
    return False


def stmt_falls(mod, s):
    if isinstance(s, (ast.Return, ast.Raise, ast.Continue, ast.Break)):
        return False
    if isinstance(s, ast.If):
        a, b = falls(mod, s.body), falls(mod, s.orelse)
        return a or b
    if isinstance(s, ast.While):
        falls(mod, s.body)
        forever = isinstance(s.test, ast.Constant) and bool(s.test.value)
        return not forever or has_break(s)
    if isinstance(s, ast.For):
        falls(mod, s.body)
        return True
    if isinstance(s, ast.With):
        return falls(mod, s.body)
    if isinstance(s, ast.Try):
        ok = falls(mod, s.body) and falls(mod, s.orelse)
        ok = any([falls(mod, h.body) for h in s.handlers]) or ok
        return falls(mod, s.finalbody) and ok
    if isinstance(s, ast.Expr) and isinstance(s.value, ast.Call) and ast.unparse(s.value.func) in ("sys.exit", "exit"):
        return False
    return True


def own_nodes(fn):
    stack = list(fn.body)
    while stack:
        n = stack.pop()
        yield n
        if not isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)):
            stack.extend(ast.iter_child_nodes(n))


def check_flow(mod):
    for fn in ast.walk(mod.tree):
        if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        end = falls(mod, fn.body)
        nodes = list(own_nodes(fn))
        if any(isinstance(n, (ast.Yield, ast.YieldFrom)) for n in nodes):
            continue
        valued = [n for n in nodes if isinstance(n, ast.Return) and n.value is not None
                  and not (isinstance(n.value, ast.Constant) and n.value.value is None)]
        bare = [n for n in nodes if isinstance(n, ast.Return) and n.value is None]
        note = ast.unparse(fn.returns) if fn.returns is not None else ""
        if valued and (end or bare) and note and "None" not in note and "Optional" not in note:
            say(mod, bare[0] if bare else fn, "no-return", f"{fn.name} -> {note} can end without a value")


def check_misc(mod):
    for w in mod.warns:
        say(mod, w.lineno or 0, "warning", str(w.message))
    for n in ast.walk(mod.tree):
        if isinstance(n, (ast.Module, ast.ClassDef)):
            seen = {}
            for b in n.body:
                if isinstance(b, (ast.FunctionDef, ast.ClassDef)):
                    decos = {deco_name(d) for d in b.decorator_list}
                    if b.name in seen and not decos & {"overload", "setter", "getter", "deleter"}:
                        say(mod, b, "redefined", f"{b.name} (first at line {seen[b.name]})")
                    seen[b.name] = b.lineno
        if isinstance(n, ast.Dict):
            keys = [ast.dump(k) for k in n.keys if isinstance(k, ast.Constant)]
            for k, c in Counter(keys).items():
                if c > 1:
                    say(mod, n, "dup-key", k)
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)):
            for d in [*n.args.defaults, *[k for k in n.args.kw_defaults if k is not None]]:
                if isinstance(d, (ast.List, ast.Dict, ast.Set)) or (
                        isinstance(d, ast.Call) and getattr(d.func, "id", "") in ("list", "dict", "set")):
                    say(mod, d, "mutable-default", getattr(n, "name", "lambda"))
        if isinstance(n, ast.For):
            mine = set(names_in(n.target))
            stack = list(n.body)
            while stack:
                x = stack.pop()
                if isinstance(x, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)):
                    continue
                if isinstance(x, ast.For) and mine & set(names_in(x.target)):
                    say(mod, x, "loop-shadow", ", ".join(sorted(mine & set(names_in(x.target)))))
                stack.extend(ast.iter_child_nodes(x))
        if isinstance(n, ast.Assert) and isinstance(n.test, ast.Tuple) and n.test.elts:
            say(mod, n, "assert-tuple", "always true")
        if isinstance(n, ast.BoolOp):
            for v in n.values:
                if isinstance(v, ast.Constant) and not isinstance(v.value, bool) and v.value is not None:
                    say(mod, n, "const-in-boolop", ast.unparse(n)[:80])
        if isinstance(n, ast.Compare) and len(n.ops) == 1 and ast.dump(n.left) == ast.dump(n.comparators[0]) \
                and not isinstance(n.left, ast.Constant):
            say(mod, n, "self-compare", ast.unparse(n)[:80])
        if isinstance(n, ast.Assign) and len(n.targets) == 1 and ast.dump(n.targets[0]).replace("Store", "Load") == ast.dump(n.value):
            say(mod, n, "self-assign", ast.unparse(n)[:80])
        if isinstance(n, ast.If) and n.orelse and [ast.dump(x) for x in n.body] == [ast.dump(x) for x in n.orelse]:
            say(mod, n, "same-branches", "if and else are identical")
        if isinstance(n, ast.If):
            tests, cur = [ast.dump(n.test)], n
            while len(cur.orelse) == 1 and isinstance(cur.orelse[0], ast.If):
                cur = cur.orelse[0]
                if ast.dump(cur.test) in tests:
                    say(mod, cur, "dup-condition", ast.unparse(cur.test)[:80])
                tests.append(ast.dump(cur.test))
        if isinstance(n, ast.ExceptHandler):
            only = n.body[0] if len(n.body) == 1 else None
            broad = n.type is None or ast.unparse(n.type) in ("Exception", "BaseException")
            if broad and isinstance(only, (ast.Pass, ast.Continue)):
                say(mod, n, "swallow", "broad except that only passes")
        if isinstance(n, ast.IfExp) and ast.dump(n.body) == ast.dump(n.orelse):
            say(mod, n, "same-branches", ast.unparse(n)[:80])


SET_METHODS = {"union", "intersection", "difference", "symmetric_difference", "copy"}
SAFE_CALLS = {"sorted", "set", "frozenset", "any", "all", "len", "bool", "isinstance", "print", "repr", "str"}
ORDERED_CALLS = {"list", "tuple", "enumerate", "zip", "iter", "next", "sum", "map", "filter", "join", "array", "asarray",
                 "fromiter", "unary_union", "MultiPolygon", "MultiPoint", "MultiLineString", "GeometryCollection",
                 "STRtree", "fromkeys", "concatenate", "vstack", "hstack", "stack", "choice", "extend", "chain", "dict"}
SET_ATTRS = set()


def is_set(n, names):
    if isinstance(n, (ast.Set, ast.SetComp)):
        return True
    if isinstance(n, ast.Call):
        if isinstance(n.func, ast.Name) and n.func.id in ("set", "frozenset"):
            return True
        return isinstance(n.func, ast.Attribute) and n.func.attr in SET_METHODS and is_set(n.func.value, names)
    if isinstance(n, ast.Name):
        return n.id in names
    if isinstance(n, ast.Attribute):
        return n.attr in SET_ATTRS
    if isinstance(n, ast.BinOp) and isinstance(n.op, (ast.BitOr, ast.BitAnd, ast.Sub, ast.BitXor)):
        return is_set(n.left, names) or is_set(n.right, names)
    if isinstance(n, ast.IfExp):
        return is_set(n.body, names) or is_set(n.orelse, names)
    return False


def set_names(scope_nodes, args=None):
    assigned = defaultdict(list)
    names = set()
    for a in ([*args.posonlyargs, *args.args, *args.kwonlyargs] if args else []):
        if a.annotation is not None and ast.unparse(a.annotation).split("[")[0] in ("set", "frozenset", "Set"):
            names.add(a.arg)
    for n in scope_nodes:
        if isinstance(n, ast.Assign):
            for t in n.targets:
                if isinstance(t, ast.Name):
                    assigned[t.id].append(n.value)
                else:
                    for name in names_in(t):
                        assigned[name].append(None)
        elif isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name):
            if ast.unparse(n.annotation).split("[")[0] in ("set", "frozenset", "Set"):
                names.add(n.target.id)
            assigned[n.target.id].append(n.value)
        elif isinstance(n, (ast.For, ast.comprehension)):
            for name in names_in(n.target):
                assigned[name].append(None)
    for _ in range(3):
        for name, values in assigned.items():
            if values and all(v is not None and is_set(v, names) for v in values):
                names.add(name)
    return names


def check_sets(mod):
    for n in ast.walk(mod.tree):
        if isinstance(n, ast.Assign) and is_set(n.value, set()):
            for t in n.targets:
                if isinstance(t, ast.Attribute):
                    SET_ATTRS.add(t.attr)
        if isinstance(n, ast.AnnAssign) and isinstance(n.target, (ast.Name, ast.Attribute)):
            note = ast.unparse(n.annotation)
            if note.split("[")[0] in ("set", "frozenset") or (n.value is not None and "default_factory=set" in ast.unparse(n.value)):
                SET_ATTRS.add(n.target.id if isinstance(n.target, ast.Name) else n.target.attr)


def scan_sets(mod):
    scopes = [(mod.tree, None)] + [(f, f.args) for f in ast.walk(mod.tree) if isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef))]
    module_sets = set()
    for scope, args in scopes:
        nodes = list(own_nodes(scope))
        names = set_names(nodes, args) | (module_sets if args is not None else set())
        if args is None:
            module_sets = names
        parents = {}
        for n in nodes:
            for c in ast.iter_child_nodes(n):
                parents[c] = n
        for n in nodes:
            if isinstance(n, ast.For) and is_set(n.iter, names):
                say(mod, n, "set-order", f"for over a set: {ast.unparse(n.iter)[:60]}")
            elif isinstance(n, (ast.ListComp, ast.GeneratorExp, ast.DictComp)):
                for g in n.generators:
                    if is_set(g.iter, names):
                        p = parents.get(n)
                        fname = deco_name(p.func) if isinstance(p, ast.Call) and n in p.args else ""
                        keyed = isinstance(p, ast.Call) and any(k.arg == "key" for k in p.keywords)
                        if fname in SAFE_CALLS or (fname in ("min", "max") and not keyed):
                            continue
                        say(mod, n, "set-order", f"{type(n).__name__} over a set: {ast.unparse(g.iter)[:50]} -> {fname or '?'}")
            elif isinstance(n, ast.Call):
                fname = deco_name(n.func)
                keyed = any(k.arg == "key" for k in n.keywords)
                if (fname in ORDERED_CALLS or (fname in ("min", "max") and keyed)) and any(is_set(a, names) for a in n.args):
                    say(mod, n, "set-order", f"{fname}(set): {ast.unparse(n)[:70]}")
                if fname == "pop" and not n.args and isinstance(n.func, ast.Attribute) and is_set(n.func.value, names):
                    say(mod, n, "set-order", f"set.pop(): {ast.unparse(n)[:60]}")
            elif isinstance(n, ast.Starred) and is_set(n.value, names):
                say(mod, n, "set-order", f"*set: {ast.unparse(n)[:60]}")


for m in MODS.values():
    check_sets(m)
for m in MODS.values():
    Calls(m)
    check_imports(m)
    check_unused_imports(m)
    check_symbols(m)
    check_flow(m)
    check_misc(m)
    scan_sets(m)

args = [a for a in sys.argv[1:] if not a.startswith("--")]
cap = int(sys.argv[sys.argv.index("--max") + 1]) if "--max" in sys.argv else 30
OUT = sorted(set(OUT))
counts = Counter(k for k, *_ in OUT)
print("calls checked:", dict(CHECKED))
print(f"{len(MODS)} files; " + ", ".join(f"{k}: {v}" for k, v in sorted(counts.items())))
for kind in sorted(counts):
    if args and kind not in args:
        continue
    rows = [r for r in OUT if r[0] == kind]
    print(f"\n== {kind} ({len(rows)}) ==")
    for _, path, line, text in rows[:cap]:
        print(f"{path}:{line}: {text}")


def check_unused(mod):
    """A plain `x = ...` inside a function whose name is never read anywhere in that function."""
    found = []
    for fn in ast.walk(mod.tree):
        if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        loads = {n.id for n in ast.walk(fn) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)}
        outer = {name for n in ast.walk(fn) if isinstance(n, (ast.Global, ast.Nonlocal)) for name in n.names}
        for n in own_nodes(fn):
            target = None
            if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name):
                target = n.targets[0].id
            elif isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name) and n.value is not None:
                target = n.target.id
            if target and target not in loads and target not in outer and not target.startswith("_"):
                found.append((str(mod.path.relative_to(ROOT)).replace("citygen/", ""), n.lineno, target, ast.unparse(n.value)[:70]))
    return found


if "--unused" in sys.argv:
    rows = sorted({r for m in MODS.values() for r in check_unused(m)})
    print(f"\n== unused (true) {len(rows)} ==")
    for path, line, name, value in rows:
        print(f"{path}:{line}: {name} = {value}")
