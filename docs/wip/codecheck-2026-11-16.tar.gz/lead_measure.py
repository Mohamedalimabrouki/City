"""How common: street trees in junction mouths, needle-thin buildings, huge village and medina houses."""
import os
import pickle
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import shapely
from shapely import STRtree

sys.path.insert(0, "/Users/mohamedalimabrouki/Desktop/City")
from citygen.interior.context import load_build  # noqa: E402

ctx = load_build(Path(sys.argv[1]), log=lambda *a: None)
extra = pickle.loads((Path(os.environ["TMPDIR"]) / "det" / "plans45.pkl").read_bytes())
plans = [ctx.plans[0], *extra]
mouth = Counter()
mouth_kind = Counter()
per_city = Counter()
edge = Counter()
thin = Counter()
thin_ex = defaultdict(list)
big = Counter()
big_ex = defaultdict(list)
n_house = Counter()
for plan in plans:
    s = plan.settlement
    ribbons = np.array([st.line.buffer(st.width / 2 - 0.5, cap_style="flat") for st in plan.streets], dtype=object)
    rtree = STRtree(ribbons)
    if plan.trees:
        tp = shapely.points([(t.x, t.y) for t in plan.trees])
        on_walk = np.zeros(len(tp), bool)
        if plan.walks:
            on_walk[STRtree(np.array([w.polygon for w in plan.walks], dtype=object)).query(tp, predicate="dwithin", distance=0.4)[0]] = True
        ti, ri = rtree.query(tp, predicate="within")
        hits = defaultdict(list)
        for t_i, r_i in zip(ti.tolist(), ri.tolist()):
            hits[t_i].append(r_i)
        for t_i, rs in hits.items():
            if on_walk[t_i]:
                continue
            kinds = sorted({plan.streets[r].kind for r in rs})
            if len(rs) >= 2:
                mouth[plan.trees[t_i].kind] += 1
                mouth_kind[" + ".join(kinds)] += 1
                per_city[f"{s.name} ({s.kind})"] += 1
            else:
                edge[f"{plan.trees[t_i].kind} on a {kinds[0]}"] += 1
    for k, b in enumerate(plan.buildings):
        dk = plan.districts[b.district].kind if 0 <= b.district < len(plan.districts) else "?"
        f = b.footprint
        if b.kind == "house":
            n_house[dk] += 1
            if f.buffer(-1.25).is_empty:
                thin[dk] += 1
                if len(thin_ex[dk]) < 2:
                    c = f.representative_point()
                    thin_ex[dk].append(f"{s.name} No. {k} area {f.area:.0f} at {c.x:.0f},{c.y:.0f}")
            if dk in ("village", "medina") and f.area > 450.0:
                big[dk] += 1
                if len(big_ex[dk]) < 2:
                    c = f.representative_point()
                    big_ex[dk].append(f"{s.name} No. {k} area {f.area:.0f} floors {b.floors} at {c.x:.0f},{c.y:.0f}")
print("trees off every walk and inside two or more street ribbons (junction mouths):", sum(mouth.values()), dict(mouth))
print("  by the kinds of the streets:", dict(mouth_kind.most_common(12)))
print("  by settlement:", dict(per_city.most_common(12)))
print("trees off every walk inside one street ribbon (an edge without a sidewalk):", dict(edge.most_common(12)))
print("houses thinner than 2.5 m everywhere, by district:", {k: f"{v} of {n_house[k]}" for k, v in thin.most_common()})
for k, v in thin_ex.items():
    print("   ", k, v)
print("village and medina houses over 450 m2:", {k: f"{v} of {n_house[k]}" for k, v in big.items()})
for k, v in big_ex.items():
    print("   ", k, v)
