"""Sanity checks of city plans: overlaps, buildings in streets or in the sea, trees in walls.

  lead_plans.py FOLDER [--all N]   (--all N: also plan the N largest other settlements of that world)
"""
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import shapely
from shapely import STRtree

sys.path.insert(0, "/Users/mohamedalimabrouki/Desktop/City")
from citygen.city import plan_city  # noqa: E402
from citygen.city.ground import Ground  # noqa: E402
from citygen.interior.context import load_build  # noqa: E402

folder = Path(sys.argv[1])
more = int(sys.argv[sys.argv.index("--all") + 1]) if "--all" in sys.argv else 0
ctx = load_build(folder, log=lambda *a: None)
world = ctx.world
plans = list(ctx.plans)
have = {id(p.settlement) for p in plans}
rest = sorted((s for s in world.settlements if id(s) not in have), key=lambda s: -s.radius)[:more]
t0 = time.perf_counter()
for s in rest:
    try:
        plans.append(plan_city(world, s))
    except Exception as e:   # a crash while planning is itself a finding
        print(f"PLAN FAILED {s.name} ({s.kind}): {type(e).__name__}: {e}")
if rest:
    print(f"planned {len(rest)} more settlements [{time.perf_counter() - t0:.0f}s]")
ground = Ground(world, plans)
total = Counter()
worst = defaultdict(lambda: (0.0, ""))


def note(key, value, where):
    total[key] += 1
    if value > worst[key][0]:
        worst[key] = (float(value), where)


for plan in plans:
    s = plan.settlement
    tag = f"{s.name} ({s.kind})"
    foots = np.array([b.footprint for b in plan.buildings], dtype=object)
    total["buildings"] += len(foots)
    total["plans"] += 1
    if not len(foots):
        note("plan without buildings", 1.0, tag)
        continue
    for k, b in enumerate(plan.buildings):
        f = b.footprint
        c = f.representative_point() if not f.is_empty else None
        at = f"{tag} No. {k} {b.kind} at {c.x:.0f},{c.y:.0f}" if c is not None else f"{tag} No. {k}"
        if f.is_empty or not f.is_valid:
            note("footprint empty or invalid", 1.0, at)
        elif f.area < 4.0:
            note("footprint under 4 m2", 4.0 - f.area, at)
        if not (0.5 < b.height < 90.0) or b.floors < 1:
            note("odd height or floors", abs(b.height), at + f" height {b.height:.1f} floors {b.floors}")
    tree = STRtree(foots)
    a, b = tree.query(foots, predicate="intersects")
    keep = a < b
    for i, j in zip(a[keep], b[keep]):
        area = foots[i].intersection(foots[j]).area
        if area > 0.5:
            c = foots[i].intersection(foots[j]).representative_point()
            note("two buildings overlap (m2)", area, f"{tag} No. {i} {plan.buildings[i].kind} and No. {j} {plan.buildings[j].kind} at {c.x:.0f},{c.y:.0f}")
    for st in plan.streets:
        if st.line.is_empty or st.line.length < 0.5 or not np.isfinite(shapely.get_coordinates(st.line)).all():
            note("street empty, tiny or non-finite", 1.0, f"{tag} {st.kind}")
            continue
        half = st.width / 2 - 0.4
        if half <= 0.3:
            continue
        ribbon = st.line.buffer(half, cap_style="flat")
        for i in tree.query(ribbon, predicate="intersects"):
            area = foots[i].intersection(ribbon).area
            if area > 1.5:
                c = foots[i].intersection(ribbon).representative_point()
                covered = " (covered impasse)" if st.kind == "impasse" and st.covered > 0 else ""
                note(f"building in a {st.kind}{covered} (m2)", area, f"{tag} No. {i} {plan.buildings[i].kind} at {c.x:.0f},{c.y:.0f}")
    pts = shapely.points([f.representative_point().coords[0] for f in foots])
    z = np.asarray(ground.surface(shapely.get_x(pts), shapely.get_y(pts)), dtype=float)
    for i in np.flatnonzero(z < 0.05):
        note("building standing at sea level or under", 0.05 - z[i], f"{tag} No. {i} {plan.buildings[i].kind} at {pts[i].x:.0f},{pts[i].y:.0f} z {z[i]:.2f}")
    if plan.trees:
        tp = shapely.points([(t.x, t.y) for t in plan.trees])
        total["trees"] += len(tp)
        hit = tree.query(tp, predicate="within")
        for ti, bi in zip(*hit):
            depth = foots[bi].exterior.distance(tp[ti])
            if depth > 0.5 and not any(h.contains(tp[ti]) for h in map(shapely.Polygon, foots[bi].interiors)):
                note("tree inside a building (m from the wall)", depth, f"{tag} {plan.trees[ti].kind} at {tp[ti].x:.0f},{tp[ti].y:.0f} in No. {bi} {plan.buildings[bi].kind}")
        lines = np.array([st.line for st in plan.streets], dtype=object)
        ltree = STRtree(lines)
        ti, li = ltree.query(tp, predicate="dwithin", distance=30.0)
        for t_i, l_i in zip(ti, li):
            st = plan.streets[l_i]
            d = lines[l_i].distance(tp[t_i])
            if st.kind in ("arterial", "street", "ring", "connector", "corniche", "bridge") and d < st.width / 2 - 1.2:
                note(f"tree on the roadway of a {st.kind} (m inside)", st.width / 2 - d, f"{tag} {plan.trees[t_i].kind} at {tp[t_i].x:.0f},{tp[t_i].y:.0f}")

print(f"{total['plans']} plans, {total['buildings']:,} buildings, {total['trees']:,} trees [{time.perf_counter() - t0:.0f}s]")
for key in sorted(k for k in total if k not in ("plans", "buildings", "trees")):
    print(f"  {key}: {total[key]}  worst {worst[key][0]:.1f}: {worst[key][1]}")
