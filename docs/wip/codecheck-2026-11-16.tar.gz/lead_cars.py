"""Which streets park the cars that stand in each other? lead_cars.py FOLDER i j [i j ...]"""
import math
import sys
from pathlib import Path

import numpy as np
import shapely
from shapely import STRtree
from shapely.geometry import box

sys.path.insert(0, "/Users/mohamedalimabrouki/Desktop/City")
from citygen.city.openings import piece_boxes  # noqa: E402
from citygen.city.parking import Parking  # noqa: E402
from citygen.interior.context import load_build  # noqa: E402

ctx = load_build(Path(sys.argv[1]), log=lambda *a: None)
plan = ctx.plans[0]
d = ctx.dresser(plan)
park = Parking(d)
lines = np.array([st.line for st in plan.streets], dtype=object)
stree = STRtree(lines)


def heading(line, p):
    s = line.project(p)
    a, b = line.interpolate(max(s - 1.0, 0.0)), line.interpolate(min(s + 1.0, line.length))
    return math.atan2(b.y - a.y, b.x - a.x)


args = [int(v) for v in sys.argv[2:]]
total = 0
for i, j in zip(args[::2], args[1::2]):
    tile = box(i * 512, j * 512, (i + 1) * 512, (j + 1) * 512)
    cars, src = [], []
    for k in stree.query(tile, predicate="intersects").tolist():
        for p in park.cars(int(k), tile):
            cars.append(p)
            src.append(int(k))
    boxes, z0, z1 = piece_boxes(ctx.kit, cars, 0.0)
    a, b = STRtree(boxes).query(boxes, predicate="intersects")
    for u, v in zip(a.tolist(), b.tolist()):
        if u >= v:
            continue
        share = boxes[u].intersection(boxes[v]).area / min(boxes[u].area, boxes[v].area)
        if share < 0.25:
            continue
        total += 1
        ku, kv = src[u], src[v]
        su, sv = plan.streets[ku], plan.streets[kv]
        p = shapely.Point(cars[u].x, cars[u].y)
        turn = abs(heading(su.line, p) - heading(sv.line, p)) % math.pi
        print(f"tile {i}_{j}: {cars[u].piece} + {cars[v].piece} at {cars[u].x:.1f},{cars[u].y:.1f} share {share:.0%} | street {ku} {su.kind} w {su.width} "
              f"(car {su.line.distance(p):.1f} m off its line) and street {kv} {sv.kind} w {sv.width} (car {sv.line.distance(shapely.Point(cars[v].x, cars[v].y)):.1f} m off) | "
              f"lines {su.line.distance(sv.line):.1f} m apart, turn {math.degrees(min(turn, math.pi - turn)):.0f} deg, overlap of the two lines within 3 m: "
              f"{su.line.intersection(sv.line.buffer(3.0)).length:.0f} m")
print("pairs:", total)
