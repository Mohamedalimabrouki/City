"""Before and after: three junctions of the capital, plan view. lead_picture.py OLD_FOLDER NEW_FOLDER"""
import math
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from shapely.geometry import box

sys.path.insert(0, "/Users/mohamedalimabrouki/Desktop/City")
from citygen.interior.context import load_build  # noqa: E402

import pickle  # noqa: E402
old = pickle.loads(Path(sys.argv[1]).read_bytes())
new = pickle.loads(Path(sys.argv[2]).read_bytes())
cases = [(31863, 54702, "a side street by the port"), (33439, 54931, "the boulevard meets the corniche"),
         (34367, 54203, "an avenue crosses the palms")]
W, R = 520, 40.0
try:
    font = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 17)
except OSError:
    font = ImageFont.load_default()
sheet = Image.new("RGB", (W * 3, W * 2 + 60), "white")
head = ImageDraw.Draw(sheet)
head.text((10, 6), "BEFORE: palms planted in the middle of junctions (red)", fill=(170, 20, 20), font=font)
head.text((10, W + 36), "AFTER: the junctions are clear, every other tree is where it was", fill=(20, 110, 40), font=font)
gone = {(round(t.x, 2), round(t.y, 2)) for t in old.trees} - {(round(t.x, 2), round(t.y, 2)) for t in new.trees}
for row, plan in enumerate((old, new)):
    for n, (cx, cy, label) in enumerate(cases):
        img = Image.new("RGB", (W, W), (222, 211, 184))
        dr = ImageDraw.Draw(img)
        view = box(cx - R, cy - R, cx + R, cy + R)

        def px(pts):
            return [((x - cx + R) / (2 * R) * W, (cy + R - y) / (2 * R) * W) for x, y in pts]

        for st in plan.streets:
            if st.line.intersects(view.buffer(40)):
                poly = st.line.buffer(st.width / 2, cap_style="flat")
                for g in getattr(poly, "geoms", [poly]):
                    dr.polygon(px(g.exterior.coords), fill=(112, 112, 116))
        for w in plan.walks:
            if w.polygon.intersects(view):
                for g in getattr(w.polygon, "geoms", [w.polygon]):
                    dr.polygon(px(g.exterior.coords), fill=(196, 194, 188))
        for b in plan.buildings:
            if b.footprint.intersects(view):
                dr.polygon(px(b.footprint.exterior.coords), fill=(240, 232, 214), outline=(90, 80, 66))
        for t in plan.trees:
            if abs(t.x - cx) < R and abs(t.y - cy) < R:
                (u, v), = px([(t.x, t.y)])
                hot = (round(t.x, 2), round(t.y, 2)) in gone
                r = 9 if hot else 7
                dr.ellipse([u - r, v - r, u + r, v + r], fill=(215, 30, 30) if hot else (46, 132, 60), outline=(20, 60, 25))
        dr.rectangle([0, 0, W - 1, 24], fill=(255, 255, 255))
        dr.text((6, 3), f"{n + 1}. {label}", fill="black", font=font)
        dr.rectangle([0, 0, W - 1, W - 1], outline=(255, 255, 255))
        sheet.paste(img, (n * W, 30 + row * (W + 30)))
out = "/Users/mohamedalimabrouki/Desktop/City/output/checks/codecheck-junctions.png"
sheet.save(out)
print("picture:", out, "| trees gone in the whole capital:", len(gone), "| trees:", len(old.trees), "->", len(new.trees))
