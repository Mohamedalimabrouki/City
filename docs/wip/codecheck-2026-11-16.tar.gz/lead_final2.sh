#!/bin/zsh
cd /Users/mohamedalimabrouki/Desktop/City
D="/tmp/claude-501/det"
.venv/bin/python /private/tmp/claude-501/-Users-mohamedalimabrouki-Desktop-City/f9c24427-d7fd-4a54-8295-01c22a3c51b0/scratchpad/lead_plan_pickle.py "/tmp/claude-501/head" "$D/cap-old.pkl" 2>&1 | grep -v "RuntimeWarning\|oriented_envelope"
.venv/bin/python /private/tmp/claude-501/-Users-mohamedalimabrouki-Desktop-City/f9c24427-d7fd-4a54-8295-01c22a3c51b0/scratchpad/lead_plan_pickle.py /Users/mohamedalimabrouki/Desktop/City "$D/cap-new.pkl" 2>&1 | grep -v "RuntimeWarning\|oriented_envelope"
.venv/bin/python /private/tmp/claude-501/-Users-mohamedalimabrouki-Desktop-City/f9c24427-d7fd-4a54-8295-01c22a3c51b0/scratchpad/lead_picture.py "$D/cap-old.pkl" "$D/cap-new.pkl" 2>&1 | grep -v "RuntimeWarning\|oriented_envelope"
echo "##### RECHECK"; .venv/bin/python /private/tmp/claude-501/-Users-mohamedalimabrouki-Desktop-City/f9c24427-d7fd-4a54-8295-01c22a3c51b0/scratchpad/lead_recheck.py "$D/full-4/bodjantouna-42" 2>&1 | grep -v "RuntimeWarning\|oriented_envelope" | cut -c1-330
echo "##### TESTS"; .venv/bin/python -m pytest -q 2>&1 | tail -2
