"""Compare two build folders byte for byte (skip cache and summary.json)."""
import hashlib
import sys
from pathlib import Path

a, b = Path(sys.argv[1]), Path(sys.argv[2])


def files(root):
    return {p.relative_to(root).as_posix(): p for p in sorted(root.rglob("*"))
            if p.is_file() and "cache" not in p.relative_to(root).parts and p.name != "summary.json"}


fa, fb = files(a), files(b)
only = sorted(set(fa) ^ set(fb))
diff = [k for k in sorted(set(fa) & set(fb))
        if hashlib.sha256(fa[k].read_bytes()).digest() != hashlib.sha256(fb[k].read_bytes()).digest()]
print(f"{a.name} vs {b.name}: {len(fa)} and {len(fb)} files, only in one: {len(only)}, different: {len(diff)}")
for k in (only + diff)[:25]:
    print("  ", k)
