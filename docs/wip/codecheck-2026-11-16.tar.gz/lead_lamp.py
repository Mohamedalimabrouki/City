"""Trace one lamp through build_tile: which step lifts it 2.15 m?"""
import math
import sys
from pathlib import Path

sys.path.insert(0, "/Users/mohamedalimabrouki/Desktop/City")
import citygen.mesh.tile as tile_mod  # noqa: E402
from citygen.interior.context import load_build  # noqa: E402
from citygen.mesh.tile import TileContext, build_tile  # noqa: E402

folder = Path(sys.argv[1])
X, Y = float(sys.argv[2]), float(sys.argv[3])
ctx = load_build(folder, log=lambda *a: None)
tc = TileContext(ctx.world, ctx.plans)


def lamp(placements):
    return [p for p in placements if p.piece == "street_lamp" and math.hypot(p.x - X, p.y - Y) < 1.5]


def wrap(owner, name, label, arg=0):
    real = getattr(owner, name)

    def inner(*a, **k):
        src = a[arg] if len(a) > arg and isinstance(a[arg], list) else None
        before = [(round(p.z, 2), p.on_ground) for p in lamp(src)] if src is not None else None
        out = real(*a, **k)
        after_src = out if isinstance(out, list) else src
        after = [(round(p.z, 2), p.on_ground) for p in lamp(after_src)] if after_src is not None else None
        if before or after:
            print(f"  {label}: before {before} after {after}")
        return out

    setattr(owner, name, inner)


wrap(tile_mod, "ground_heights", "ground_heights", 1)
wrap(tile_mod, "keep_off", "keep_off", 0)
wrap(tile_mod, "span_mesh", "span_mesh", 2)
for c in tc.cities:
    d = c[4]
    if d is not None:
        wrap(d, "under_roofs", "under_roofs", 0)
        crowd = d.crowd()
        wrap(crowd, "people", "crowd.people", 1)
        wrap(d, "street_props", "street_props (returns)", 99)
i, j = int(X // 512), int(Y // 512)
print(f"tile {i}_{j}; surface at the spot {float(tc.ground.surface(X, Y)):.2f}")
mb, placements = build_tile(tc, i, j)
for p in lamp(placements):
    print(f"  final: {p.x:.2f},{p.y:.2f} z {p.z:.2f} on_ground {p.on_ground}; surface there {float(tc.ground.surface(p.x, p.y)):.2f}")
