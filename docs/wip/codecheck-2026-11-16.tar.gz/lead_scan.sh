#!/bin/zsh
cd /Users/mohamedalimabrouki/Desktop/City
F="/tmp/claude-501/det/full-1/bodjantouna-42"
echo "##### TILES"; .venv/bin/python /private/tmp/claude-501/-Users-mohamedalimabrouki-Desktop-City/f9c24427-d7fd-4a54-8295-01c22a3c51b0/scratchpad/lead_tiles.py "$F" 2>&1 | cut -c1-180
echo "##### PLANS"; .venv/bin/python /private/tmp/claude-501/-Users-mohamedalimabrouki-Desktop-City/f9c24427-d7fd-4a54-8295-01c22a3c51b0/scratchpad/lead_plans.py "$F" --all 45 2>&1 | cut -c1-230
