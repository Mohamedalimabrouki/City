"""Plan the 64 km world's capital with the code in CODEDIR and pickle the plan. lead_plan_pickle.py CODEDIR OUT"""
import pickle
import sys

sys.path.insert(0, sys.argv[1])
import citygen  # noqa: E402
from citygen.city import plan_city  # noqa: E402
from citygen.config import load_config  # noqa: E402
from citygen.world import generate_world  # noqa: E402

world = generate_world(load_config())
plan = plan_city(world, world.capital())
with open(sys.argv[2], "wb") as f:
    pickle.dump(plan, f, protocol=pickle.HIGHEST_PROTOCOL)
print("planned with", citygen.__file__, "trees", len(plan.trees), "buildings", len(plan.buildings))
