#!/bin/zsh
cd /Users/mohamedalimabrouki/Desktop/City
echo "##### THINGS (full capital, new code)"; .venv/bin/python /private/tmp/claude-501/-Users-mohamedalimabrouki-Desktop-City/f9c24427-d7fd-4a54-8295-01c22a3c51b0/scratchpad/lead_things.py "/tmp/claude-501/det/full-4/bodjantouna-42" 2>&1 | grep -v "RuntimeWarning\|oriented_envelope" | cut -c1-250
echo "##### TESTS"; .venv/bin/python -m pytest -q 2>&1 | tail -2
