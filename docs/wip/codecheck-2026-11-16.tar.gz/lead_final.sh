#!/bin/zsh
cd /Users/mohamedalimabrouki/Desktop/City
D="/tmp/claude-501/det"
.venv/bin/python -m citygen build --area capital --out "$D/full-4" > "$D/full-4.log" 2>&1 || echo "full-4 FAILED"
tail -1 "$D/full-4.log"
.venv/bin/python /private/tmp/claude-501/-Users-mohamedalimabrouki-Desktop-City/f9c24427-d7fd-4a54-8295-01c22a3c51b0/scratchpad/lead_picture.py "$D/full-1/bodjantouna-42" "$D/full-4/bodjantouna-42" 2>&1 | grep -v "RuntimeWarning\|oriented_envelope"
echo "##### TILES of the new capital"; .venv/bin/python /private/tmp/claude-501/-Users-mohamedalimabrouki-Desktop-City/f9c24427-d7fd-4a54-8295-01c22a3c51b0/scratchpad/lead_tiles.py "$D/full-4/bodjantouna-42" 2>&1 | grep -v "RuntimeWarning\|oriented_envelope" | sed -n 1,12p | cut -c1-160
echo "##### TESTS"; .venv/bin/python -m pytest -q 2>&1 | tail -2
