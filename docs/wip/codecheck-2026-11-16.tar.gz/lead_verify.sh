#!/bin/zsh
cd /Users/mohamedalimabrouki/Desktop/City
D="/tmp/claude-501/det"
echo "##### TESTS"; .venv/bin/python -m pytest -q 2>&1 | tail -3
rm -f "$D/plans45.pkl"
.venv/bin/python -m citygen build --area capital --out "$D/full-3" > "$D/full-3.log" 2>&1 || echo "full-3 FAILED"
tail -1 "$D/full-3.log"
echo "##### DETAIL"; .venv/bin/python /private/tmp/claude-501/-Users-mohamedalimabrouki-Desktop-City/f9c24427-d7fd-4a54-8295-01c22a3c51b0/scratchpad/lead_detail.py "$D/full-3/bodjantouna-42" 2>&1 | grep -v "RuntimeWarning\|oriented_envelope\|street lamps\|walk sidewalk\|open, by\|walk seafront" | cut -c1-260
echo "##### MOUTHS"; .venv/bin/python /private/tmp/claude-501/-Users-mohamedalimabrouki-Desktop-City/f9c24427-d7fd-4a54-8295-01c22a3c51b0/scratchpad/lead_angles.py "$D/full-3/bodjantouna-42" 2>&1 | grep -v "RuntimeWarning\|oriented_envelope" | cut -c1-260
