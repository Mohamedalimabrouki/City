#!/bin/zsh
cd /Users/mohamedalimabrouki/Desktop/City
D="/tmp/claude-501/det"
for hs in 1 2; do
  PYTHONHASHSEED=$hs .venv/bin/python -m citygen build --quick --seed 7 --area capital --out "$D/q7-$hs" > "$D/q7-$hs.log" 2>&1 || echo "q7-$hs FAILED"
done
.venv/bin/python "/private/tmp/claude-501/-Users-mohamedalimabrouki-Desktop-City/f9c24427-d7fd-4a54-8295-01c22a3c51b0/scratchpad/lead_cmp.py" "$D"/q7-1/*-7 "$D"/q7-2/*-7
for hs in 1 2; do
  PYTHONHASHSEED=$hs .venv/bin/python -m citygen build --area capital --out "$D/full-$hs" > "$D/full-$hs.log" 2>&1 || echo "full-$hs FAILED"
done
.venv/bin/python "/private/tmp/claude-501/-Users-mohamedalimabrouki-Desktop-City/f9c24427-d7fd-4a54-8295-01c22a3c51b0/scratchpad/lead_cmp.py" "$D"/full-1/*-42 "$D"/full-2/*-42
tail -2 "$D"/q7-1.log "$D"/full-1.log
