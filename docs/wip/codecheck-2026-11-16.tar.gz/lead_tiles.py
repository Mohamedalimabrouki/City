"""Sanity scan of every tile of a build: bad numbers, flung geometry, pieces buried or floating.

  lead_tiles.py FOLDER [--tiles N]     (FOLDER = a built world folder)
"""
import json
import struct
import sys
import time
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, "/Users/mohamedalimabrouki/Desktop/City")
from citygen.interior.context import load_build  # noqa: E402

folder = Path(sys.argv[1])
limit = int(sys.argv[sys.argv.index("--tiles") + 1]) if "--tiles" in sys.argv else None
t0 = time.perf_counter()
ctx = load_build(folder, log=lambda *a: None)
ground = ctx.ground
index = json.loads((folder / "tiles" / "index.json").read_text())
size = float(index["tile_size"])
DT = {5120: "i1", 5121: "u1", 5122: "<i2", 5123: "<u2", 5125: "<u4", 5126: "<f4"}
NC = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}
NORM = {5120: 127.0, 5121: 255.0, 5122: 32767.0, 5123: 65535.0}


def load_glb(path):
    data = path.read_bytes()
    n = struct.unpack_from("<I", data, 12)[0]
    js = json.loads(data[20:20 + n])
    off = 20 + n
    m = struct.unpack_from("<I", data, off)[0]
    return js, memoryview(data)[off + 8: off + 8 + m]


def accessor(js, binary, k):
    a = js["accessors"][k]
    bv = js["bufferViews"][a["bufferView"]]
    dt = np.dtype(DT[a["componentType"]])
    nc = NC[a["type"]]
    start = bv.get("byteOffset", 0) + a.get("byteOffset", 0)
    stride = bv.get("byteStride", 0)
    if stride and stride != dt.itemsize * nc:
        raw = np.frombuffer(binary, dtype=np.uint8, count=stride * (a["count"] - 1) + dt.itemsize * nc, offset=start)
        pick = np.arange(a["count"])[:, None] * stride + np.arange(dt.itemsize * nc)[None, :]
        arr = raw[pick].copy().view(dt).reshape(a["count"], nc)
    else:
        arr = np.frombuffer(binary, dtype=dt, count=a["count"] * nc, offset=start).reshape(a["count"], nc)
    arr = arr.astype(np.float64)
    if a.get("normalized"):
        arr = np.maximum(arr / NORM[a["componentType"]], -1.0)
    return arr


import shapely
from shapely import STRtree
foot_tree = STRtree([b.footprint for p in ctx.plans for b in p.buildings])
afloat = defaultdict(lambda: [0, 0.0, ""])   # piece -> [count, highest, where] away from every building
bad = []                                   # (tile, what)
static = defaultdict(lambda: [0, 1e9, -1e9, "", ""])   # material -> [verts, min dz, max dz, tile of min, tile of max]
over = defaultdict(lambda: [0.0, ""])      # material -> worst overshoot outside the tile, tile
inst = defaultdict(lambda: {"n": 0, "min": 1e9, "max": -1e9, "bur": 0, "tmin": "", "tmax": "", "smin": 1e9, "smax": 0.0})
tiles = index["tiles"][:limit]
total_inst = 0
for t in tiles:
    name = t["file"][:-4]
    js, binary = load_glb(folder / "tiles" / t["file"])
    mats = [m.get("name", "?") for m in js.get("materials", [])]
    x0, y0 = float(t["x0"]), float(t["y0"])
    for node in js["nodes"]:
        if "mesh" not in node:
            continue
        ext = node.get("extensions", {}).get("EXT_mesh_gpu_instancing")
        tr = np.array(node.get("translation", [0.0, 0.0, 0.0])) if node is not js["nodes"][0] else np.zeros(3)
        sc = np.array(node.get("scale", [1.0, 1.0, 1.0]))
        if ext is None:                    # the tile's own geometry (plain or quantized)
            for prim in js["meshes"][node["mesh"]]["primitives"]:
                p = accessor(js, binary, prim["attributes"]["POSITION"]) * sc + tr
                mat = mats[prim["material"]] if "material" in prim else "?"
                if not np.isfinite(p).all():
                    bad.append((name, f"non-finite positions in {mat}"))
                    continue
                out = max(-p[:, 0].min(), p[:, 0].max() - size, p[:, 2].max(), -p[:, 2].min() - size)
                if out > over[mat][0]:
                    over[mat] = [float(out), name]
                step = max(1, len(p) // 4000)          # a sample of the vertices against the ground
                q = p[::step]
                lo, hi = int(q[:, 1].argmin()), int(q[:, 1].argmax())
                q = np.vstack([q, p[[int(p[:, 1].argmin()), int(p[:, 1].argmax())]]])
                dz = q[:, 1] - np.asarray(ground.surface(x0 + q[:, 0], y0 - q[:, 2]), dtype=float)
                s = static[mat]
                s[0] += len(p)
                if dz.min() < s[1]:
                    s[1], s[3] = float(dz.min()), name
                if dz.max() > s[2]:
                    s[2], s[4] = float(dz.max()), name
                if "NORMAL" in prim["attributes"]:
                    nrm = accessor(js, binary, prim["attributes"]["NORMAL"])
                    ln = np.linalg.norm(nrm, axis=1)
                    if not np.isfinite(nrm).all() or (ln < 0.5).mean() > 0.01:
                        bad.append((name, f"bad normals in {mat}: {(ln < 0.5).sum()} of {len(ln)} near zero"))
            continue
        a = ext["attributes"]
        T = accessor(js, binary, a["TRANSLATION"])
        R = accessor(js, binary, a["ROTATION"]) if "ROTATION" in a else None
        S = accessor(js, binary, a["SCALE"]) if "SCALE" in a else None
        piece = node.get("name", "?")
        total_inst += len(T)
        if not np.isfinite(T).all() or (R is not None and not np.isfinite(R).all()) or (S is not None and not np.isfinite(S).all()):
            bad.append((name, f"non-finite instance data in {piece}"))
            continue
        if R is not None and (np.abs(np.linalg.norm(R, axis=1) - 1.0) > 0.02).any():
            bad.append((name, f"rotation not unit in {piece}"))
        out = float(max(-T[:, 0].min(), T[:, 0].max() - size, T[:, 2].max(), -T[:, 2].min() - size))
        if out > 80.0:
            bad.append((name, f"{piece}: an instance {out:.1f} m outside its tile"))
        dz = T[:, 1] - np.asarray(ground.surface(x0 + T[:, 0], y0 - T[:, 2]), dtype=float)
        near = np.zeros(len(T), bool)
        near[foot_tree.query(shapely.points(x0 + T[:, 0], y0 - T[:, 2]), predicate="dwithin", distance=2.5)[0]] = True
        up = (~near) & (dz > 1.2)
        if up.any():
            k = int(np.where(up, dz, -1e9).argmax())
            f = afloat[piece]
            f[0] += int(up.sum())
            if dz[k] > f[1]:
                f[1], f[2] = float(dz[k]), f"{name} at {x0 + T[k, 0]:.0f},{y0 - T[k, 2]:.0f}"
        d = inst[piece]
        d["n"] += len(T)
        d["bur"] += int((dz < -0.7).sum())
        if dz.min() < d["min"]:
            k = int(dz.argmin())
            d["min"], d["tmin"] = float(dz.min()), f"{name} at {x0 + T[k, 0]:.0f},{y0 - T[k, 2]:.0f}"
        if dz.max() > d["max"]:
            k = int(dz.argmax())
            d["max"], d["tmax"] = float(dz.max()), f"{name} at {x0 + T[k, 0]:.0f},{y0 - T[k, 2]:.0f}"
        if S is not None:
            d["smin"], d["smax"] = min(d["smin"], float(S.min())), max(d["smax"], float(S.max()))

print(f"{len(tiles)} tiles, {total_inst:,} instances, {sum(s[0] for s in static.values()):,} vertices [{time.perf_counter() - t0:.0f}s]")
print(f"\n== bad numbers ({len(bad)}) ==")
for row in bad[:30]:
    print("  ", *row)
print("\n== tile geometry reaching outside its tile by more than 40 m ==")
for mat, (o, where) in sorted(over.items(), key=lambda kv: -kv[1][0]):
    if o > 40.0:
        print(f"  {mat}: {o:.0f} m ({where})")
print("\n== tile geometry by material: lowest and highest against the ground (sampled) ==")
for mat, s in sorted(static.items(), key=lambda kv: kv[1][1]):
    if s[1] < -4.0 or s[2] > 60.0:
        print(f"  {mat}: {s[0]:,} verts, low {s[1]:.1f} ({s[3]}), high {s[2]:.1f} ({s[4]})")
print("\n== instanced pieces with an origin more than 0.7 m under the ground ==")
for piece, d in sorted(inst.items(), key=lambda kv: -kv[1]["bur"]):
    if d["bur"]:
        print(f"  {piece}: {d['bur']} of {d['n']}, lowest {d['min']:.1f} ({d['tmin']})")
print("\n== instanced pieces over 1.2 m above the ground, more than 2.5 m from every building ==")
for piece, f in sorted(afloat.items(), key=lambda kv: -kv[1][0]):
    print(f"  {piece}: {f[0]} of {inst[piece]['n']}, highest {f[1]:.1f} ({f[2]})")
print("\n== odd instance scales (under 0.2 or over 12) ==")
for piece, d in sorted(inst.items()):
    if d["smin"] < 0.2 or d["smax"] > 12.0:
        print(f"  {piece}: scale {d['smin']:.2f} to {d['smax']:.2f}")
