"""After the fixes: re-plan the settlements that showed the faults and count them again."""
import math
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np
import shapely
from shapely import STRtree

sys.path.insert(0, "/Users/mohamedalimabrouki/Desktop/City")
from citygen.city import plan_city  # noqa: E402
from citygen.interior.context import load_build  # noqa: E402

ctx = load_build(Path(sys.argv[1]), log=lambda *a: None)
world = ctx.world
names = ["Goumosbane", "Ghouma", "Zaha", "Ras Dasrel", "Roulia el Djedida", "Kalaat Mighane", "Bizra"]


def heading(line, p):
    d = line.project(p)
    a, b = line.interpolate(max(d - 1.0, 0.0)), line.interpolate(min(d + 1.0, line.length))
    return math.atan2(b.y - a.y, b.x - a.x)


for name in names:
    s = next(s for s in world.settlements if s.name == name)
    t0 = time.perf_counter()
    plan = plan_city(world, s)
    B = plan.buildings
    ribbons = STRtree(np.array([st.line.buffer(st.width / 2 - 0.5, cap_style="flat") for st in plan.streets], dtype=object))
    walks = STRtree(np.array([w.polygon for w in plan.walks], dtype=object))
    tp = shapely.points([(t.x, t.y) for t in plan.trees])
    cross, along = Counter(), 0
    for k, p in enumerate(tp):
        if len(walks.query(p, predicate="dwithin", distance=0.4)):
            continue
        hit = ribbons.query(p, predicate="within").tolist()
        rows = [j for j in hit if plan.streets[j].kind in ("boulevard", "corniche")]
        worst = 0.0
        for a in rows:
            for b in hit:
                if a != b:
                    v = abs(heading(plan.streets[a].line, p) - heading(plan.streets[b].line, p)) % math.pi
                    worst = max(worst, math.degrees(min(v, math.pi - v)))
                    if plan.streets[b].width / 2 - plan.streets[b].line.distance(p) >= 3.0:
                        worst = 90.0
        if len(hit) >= 2 and rows:
            if worst > 20.0:
                cross[plan.trees[k].kind] += 1
            else:
                along += 1
    shrines = [b for b in B if b.kind == "marabout"]
    pairs = sum(1 for n, a in enumerate(shrines) for b in shrines[:n] if a.footprint.intersection(b.footprint).area > 0.5)
    close = sum(1 for n, a in enumerate(shrines) for b in shrines[:n] if a.footprint.distance(b.footprint) < 1.49)
    inside = 0
    if shrines:
        st = STRtree(np.array([b.footprint.buffer(1.49) for b in shrines], dtype=object))
        inside = len(st.query(tp, predicate="within")[0])
    print(f"{name} ({s.kind}): {len(B):,} buildings, {len(plan.trees):,} trees [{time.perf_counter() - t0:.0f}s] | row trees in a crossing mouth: {dict(cross) or 0}, "
          f"along a street: {along} | marabouts {len(shrines)}: overlapping pairs {pairs}, closer than 1.5 m {close}, trees within 1.5 m of a marabout {inside}")
