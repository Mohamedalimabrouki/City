"""Probe: where the 2.15 m lamps come from; a plan sheet of the worst tree cases."""
import math
import os
import pickle
import sys
from pathlib import Path

import numpy as np
import shapely
from shapely import STRtree
from shapely.geometry import Point, box

sys.path.insert(0, "/Users/mohamedalimabrouki/Desktop/City")
from citygen.city.dressing import Dresser, ground_heights  # noqa: E402
from citygen.city.ground import Ground  # noqa: E402
from citygen.interior.context import load_build  # noqa: E402

folder = Path(sys.argv[1])
ctx = load_build(folder, log=lambda *a: None)
world, cap = ctx.world, ctx.plans[0]
d = ctx.dresser(cap)
lines = np.array([st.line for st in cap.streets], dtype=object)
stree = STRtree(lines)
print("== lamps near the flagged spots ==")
for x, y in [(33791, 54109), (32200, 54791), (33758, 54248), (32785, 52248), (33824, 54816), (30701, 52869), (33545, 53860)]:
    tile = box(x - 40, y - 40, x + 40, y + 40)
    found = []
    for k in stree.query(tile, predicate="intersects"):
        for p in d.street_props(int(k), tile):
            if p.piece == "street_lamp" and math.hypot(p.x - x, p.y - y) < 1.5:
                found.append(("street_props", int(k), p))
    for name, src in (("squares", d.squares().placements(tile)), ("seafront", d.seafront().placements(tile))):
        for p in src:
            if p.piece == "street_lamp" and math.hypot(p.x - x, p.y - y) < 1.5:
                found.append((name, -1, p))
    for src, k, p in found:
        st = cap.streets[k] if k >= 0 else None
        surf = float(ctx.ground.surface(p.x, p.y))
        print(f"  at {x},{y}: from {src}, street {k} {st.kind if st else ''} width {st.width if st else 0}, z {p.z:.2f} on_ground {p.on_ground} "
              f"scale {p.scale} tilt {getattr(p, 'tilt', 0):.2f}; surface {surf:.2f} height {float(ctx.ground.height(p.x, p.y)):.2f} lift {float(ctx.ground.lift(p.x, p.y)):.2f}")
    if not found:
        print(f"  at {x},{y}: no lamp placement found by the dresser")

# plan sheet
from PIL import Image, ImageDraw  # noqa: E402
extra = pickle.loads((Path(os.environ["TMPDIR"]) / "det" / "plans45.pkl").read_bytes())
plans = {p.settlement.name: p for p in [cap, *extra]}
cases = [("Goumosbane", 31863, 54702, "palm in a 14 m street"), ("Goumosbane", 33439, 54931, "palm on the boulevard"),
         ("Goumosbane", 34367, 54203, "palm on an arterial"), ("Goumosbane", 35837, 54663, "palm on the corniche"),
         ("Ain en Nikhouna", 29594, 31183, "tree in a village house"), ("Hammam et Takhara", 57211, 40851, "tree in a medina house"),
         ("Ras Dasrel", 11118, 17117, "two marabouts, a cypress"), ("Ksar Saba", 41395, 47095, "souk into the mosque"),
         ("Rahousir", 16595, 25024, "house in a bridge")]
W, R = 380, 38.0   # pixels per panel, meters shown from the center
sheet = Image.new("RGB", (W * 3, W * 3), "white")
for n, (name, cx, cy, label) in enumerate(cases):
    plan = plans[name]
    img = Image.new("RGB", (W, W), (214, 205, 180))
    dr = ImageDraw.Draw(img)
    view = box(cx - R, cy - R, cx + R, cy + R)

    def px(pts):
        return [((x - cx + R) / (2 * R) * W, (cy + R - y) / (2 * R) * W) for x, y in pts]

    def fill(poly, color, outline=None):
        for g in getattr(poly, "geoms", [poly]):
            if g.geom_type == "Polygon" and not g.is_empty:
                dr.polygon(px(g.exterior.coords), fill=color, outline=outline)
                for hole in g.interiors:
                    dr.polygon(px(hole.coords), fill=(214, 205, 180), outline=outline)

    for st in plan.streets:
        if st.line.intersects(view.buffer(40)):
            fill(st.line.buffer(st.width / 2, cap_style="flat"), (120, 120, 120) if st.kind != "bridge" else (90, 90, 140))
    for w in plan.walks:
        if w.polygon.intersects(view):
            fill(w.polygon, (190, 190, 190))
    for b in plan.buildings:
        if b.footprint.intersects(view):
            fill(b.footprint, (236, 226, 205), (70, 60, 50))
    for t in plan.trees:
        if abs(t.x - cx) < R and abs(t.y - cy) < R:
            (u, v), = px([(t.x, t.y)])
            hot = math.hypot(t.x - cx, t.y - cy) < 1.5
            r = 1.2 / (2 * R) * W * (1.6 if hot else 1.0)
            dr.ellipse([u - r, v - r, u + r, v + r], fill=(220, 30, 30) if hot else (40, 130, 50))
    dr.rectangle([0, 0, W - 1, 15], fill="white")
    dr.text((4, 2), f"{n + 1}. {name}: {label} ({2 * R:.0f} m wide)", fill="black")
    sheet.paste(img, ((n % 3) * W, (n // 3) * W))
out = "/Users/mohamedalimabrouki/Desktop/City/output/checks/codecheck-cases.png"
sheet.save(out)
print("sheet:", out)
