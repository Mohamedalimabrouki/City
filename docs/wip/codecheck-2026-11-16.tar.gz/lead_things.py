"""Scan what stands on the ground of every tile (from build_tile's placements, not the files): things inside
buildings, under the sea, inside each other, cars off the road. lead_things.py FOLDER [--tiles N]"""
import json
import sys
import time
from collections import defaultdict
from pathlib import Path

import numpy as np
import shapely
from shapely import STRtree

sys.path.insert(0, "/Users/mohamedalimabrouki/Desktop/City")
from citygen.city.openings import piece_boxes  # noqa: E402
from citygen.interior.context import load_build  # noqa: E402
from citygen.mesh.tile import TileContext, build_tile  # noqa: E402

folder = Path(sys.argv[1])
limit = int(sys.argv[sys.argv.index("--tiles") + 1]) if "--tiles" in sys.argv else None
t0 = time.perf_counter()
ctx = load_build(folder, log=lambda *a: None)
world, plan = ctx.world, ctx.plans[0]
index = json.loads((folder / "tiles" / "index.json").read_text())
world.built_tiles = {(t["i"], t["j"]) for t in index["tiles"]}
tc = TileContext(world, ctx.plans)
kit, ground = tc.kit, tc.ground
B = plan.buildings
foots = np.array([b.footprint for b in B], dtype=object)
foot_tree = STRtree(foots)
walk_tree = STRtree(np.array([w.polygon for w in plan.walks], dtype=object))
ribbon_tree = STRtree(np.array([st.line.buffer(st.width / 2, cap_style="flat") for st in plan.streets], dtype=object))
SOLID = {"vehicle", "person", "bench", "kiosk", "fountain", "furniture", "goods", "ground_prop", "cargo", "bollard", "cat", "parasol"}
TREES = {"tree"}
SEATS = {"bench", "furniture", "kiosk", "ground_prop", "goods", "fountain"}


def cat(name):
    if name == "street_lamp":
        return "street_lamp"
    if name == "tounes/palm_date":
        return "tree"
    return kit.pieces[name].category


inside = defaultdict(lambda: [0, 0.0, ""])
sea = defaultdict(lambda: [0, 0.0, ""])
pairs = defaultdict(lambda: [0, 0.0, ""])
trunks = defaultdict(lambda: [0, ""])
cars = defaultdict(lambda: [0, ""])
counts = defaultdict(int)
tiles = index["tiles"][:limit]
for t in tiles:
    name = t["file"][:-4]
    mb, placements = build_tile(tc, t["i"], t["j"])
    ps = [p for p in placements if p.piece in kit.pieces and (cat(p.piece) in SOLID or cat(p.piece) in ("street_lamp", "tree"))]
    if not ps:
        continue
    xy = np.array([(p.x, p.y) for p in ps])
    z = np.array([p.z for p in ps])
    surf = np.asarray(ground.surface(xy[:, 0], xy[:, 1]), dtype=float)
    cats = [cat(p.piece) for p in ps]
    low = np.abs(z - surf) < 1.2
    pts = shapely.points(xy)
    for k, c in enumerate(cats):
        counts[c] += 1
    # 1. inside a building, at ground level
    pi, bi = foot_tree.query(pts, predicate="within")
    for k, b in zip(pi.tolist(), bi.tolist()):
        if not low[k] or cats[k] == "tree":
            continue
        depth = foots[b].exterior.distance(pts[k])
        if depth > 0.35 and not any(shapely.Polygon(h).contains(pts[k]) for h in foots[b].interiors):
            f = inside[(cats[k], B[b].kind)]
            f[0] += 1
            if depth > f[1]:
                f[1], f[2] = depth, f"{name} {ps[k].piece} at {xy[k, 0]:.1f},{xy[k, 1]:.1f} z {z[k]:.1f} in No. {b} (height {B[b].height:.1f})"
    # 2. under the sea
    for k in np.flatnonzero(z < -0.05):
        if cats[k] != "tree":
            f = sea[cats[k]]
            f[0] += 1
            if -z[k] > f[1]:
                f[1], f[2] = float(-z[k]), f"{name} {ps[k].piece} at {xy[k, 0]:.1f},{xy[k, 1]:.1f} z {z[k]:.2f}"
    # 3. solid things inside each other
    sel = [k for k in range(len(ps)) if low[k] and cats[k] != "tree"]
    if len(sel) > 1:
        boxes, z0, z1 = piece_boxes(kit, [ps[k] for k in sel], 0.0)
        a, b = STRtree(boxes).query(boxes, predicate="intersects")
        for i, j in zip(a.tolist(), b.tolist()):
            if i >= j or min(z1[i], z1[j]) - max(z0[i], z0[j]) < 0.2:
                continue
            ci, cj = sorted((cats[sel[i]], cats[sel[j]]))
            if (ci in SEATS or cj in SEATS) and "person" in (ci, cj):
                continue                       # people sit on benches and at tables, stand at stalls
            if {ci, cj} == {"parasol", "furniture"}:
                continue                       # a parasol stands in its table
            share = boxes[i].intersection(boxes[j]).area / max(min(boxes[i].area, boxes[j].area), 1e-6)
            if share < 0.25:
                continue
            f = pairs[(ci, cj)]
            f[0] += 1
            if share > f[1]:
                p, q = ps[sel[i]], ps[sel[j]]
                f[1], f[2] = share, f"{name} {p.piece} at {p.x:.1f},{p.y:.1f} and {q.piece} at {q.x:.1f},{q.y:.1f}"
        # 4. a tree's trunk inside a solid thing
        tk = [k for k in range(len(ps)) if cats[k] == "tree"]
        if tk:
            hit_t, hit_b = STRtree(boxes).query(pts[tk], predicate="within")
            for ti, bj in zip(hit_t.tolist(), hit_b.tolist()):
                c = cats[sel[bj]]
                if c in ("vehicle", "kiosk", "bench", "fountain", "furniture", "cargo", "person", "street_lamp"):
                    f = trunks[c]
                    f[0] += 1
                    f[1] = f"{name} {ps[tk[ti]].piece} at {xy[tk[ti], 0]:.1f},{xy[tk[ti], 1]:.1f} in {ps[sel[bj]].piece}"
    # 5. cars: on a walk, or off every street
    for k in [k for k in range(len(ps)) if cats[k] == "vehicle"]:
        on_walk = len(walk_tree.query(pts[k], predicate="within")) > 0
        on_street = len(ribbon_tree.query(pts[k], predicate="within")) > 0
        key = "on a walk" if on_walk else ("on a street" if on_street else "off every street")
        f = cars[key]
        f[0] += 1
        f[1] = f"{name} {ps[k].piece} at {xy[k, 0]:.1f},{xy[k, 1]:.1f}"

print(f"{len(tiles)} tiles [{time.perf_counter() - t0:.0f}s]; standing things:", dict(sorted(counts.items(), key=lambda kv: -kv[1])))
print("\n== at ground level inside a building (more than 0.35 m from its wall): thing, building kind ==")
for key, f in sorted(inside.items(), key=lambda kv: -kv[1][0]):
    print(f"  {key[0]} in a {key[1]}: {f[0]}, deepest {f[1]:.1f} m ({f[2]})")
print("\n== under the sea ==")
for key, f in sorted(sea.items(), key=lambda kv: -kv[1][0]):
    print(f"  {key}: {f[0]}, lowest {-f[1]:.2f} ({f[2]})")
print("\n== two solid things in each other (a quarter of the smaller footprint or more) ==")
for key, f in sorted(pairs.items(), key=lambda kv: -kv[1][0]):
    print(f"  {key[0]} + {key[1]}: {f[0]}, worst {f[1]:.0%} ({f[2]})")
print("\n== a tree's trunk inside a solid thing ==")
for key, f in sorted(trunks.items(), key=lambda kv: -kv[1][0]):
    print(f"  tree in a {key}: {f[0]} (e.g. {f[1]})")
print("\n== cars ==")
for key, f in sorted(cars.items(), key=lambda kv: -kv[1][0]):
    print(f"  {key}: {f[0]} (e.g. {f[1]})")
