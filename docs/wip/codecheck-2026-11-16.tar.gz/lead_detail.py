"""Details behind the scan's findings. lead_detail.py FOLDER (keeps the extra plans in $TMPDIR/det/plans45.pkl)."""
import json
import os
import pickle
import struct
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import shapely
from shapely import STRtree

sys.path.insert(0, "/Users/mohamedalimabrouki/Desktop/City")
from citygen.city import plan_city  # noqa: E402
from citygen.city.ground import Ground  # noqa: E402
from citygen.interior.context import load_build  # noqa: E402

folder = Path(sys.argv[1])
ctx = load_build(folder, log=lambda *a: None)
world = ctx.world
cache = Path(os.environ["TMPDIR"]) / "det" / "plans45.pkl"
plans = list(ctx.plans)
have = {p.settlement.name for p in plans}
rest = sorted((s for s in world.settlements if s.name not in have), key=lambda s: -s.radius)[:45]
t0 = time.perf_counter()
if cache.is_file():
    extra = pickle.loads(cache.read_bytes())
    by_name = {s.name: s for s in world.settlements}
    for p in extra:
        p.settlement = by_name[p.settlement.name]
else:
    extra = [plan_city(world, s) for s in rest]
    cache.write_bytes(pickle.dumps(extra, protocol=pickle.HIGHEST_PROTOCOL))
plans += extra
print(f"{len(plans)} plans ready [{time.perf_counter() - t0:.0f}s]")
ground = Ground(world, plans)

pairs = defaultdict(lambda: [0, 0.0, 0.0, ""])
inside = []
asphalt = defaultdict(lambda: [0, 0.0, ""])
for plan in plans:
    s = plan.settlement
    tag = f"{s.name} ({s.kind})"
    B = plan.buildings
    foots = np.array([b.footprint for b in B], dtype=object)
    tree = STRtree(foots)
    a, b = tree.query(foots, predicate="intersects")
    keep = a < b
    for i, j in zip(a[keep], b[keep]):
        hit = foots[i].intersection(foots[j])
        if hit.area > 0.5:
            key = " + ".join(sorted((B[i].kind, B[j].kind)))
            p = pairs[key]
            p[0] += 1
            p[1] += hit.area
            if hit.area > p[2]:
                c = hit.representative_point()
                p[2], p[3] = hit.area, f"{tag} No. {i} and No. {j} at {c.x:.0f},{c.y:.0f}"
    if plan.trees:
        tp = shapely.points([(t.x, t.y) for t in plan.trees])
        for ti, bi in zip(*tree.query(tp, predicate="within")):
            depth = foots[bi].exterior.distance(tp[ti])
            if depth > 0.5 and not any(h.contains(tp[ti]) for h in map(shapely.Polygon, foots[bi].interiors)):
                inside.append(f"{tag}: tree {ti} of {len(tp)} ({plan.trees[ti].kind}) {depth:.1f} m inside No. {bi} of {len(B)} "
                              f"{B[bi].kind} (district {plan.districts[B[bi].district].kind}, floors {B[bi].floors}, "
                              f"area {foots[bi].area:.0f}) at {tp[ti].x:.0f},{tp[ti].y:.0f}")
        walks = STRtree(np.array([w.polygon for w in plan.walks], dtype=object)) if plan.walks else None
        on_walk = np.zeros(len(tp), bool)
        if walks is not None:
            on_walk[walks.query(tp, predicate="dwithin", distance=0.4)[0]] = True
        lines = np.array([st.line for st in plan.streets], dtype=object)
        ti, li = STRtree(lines).query(tp, predicate="dwithin", distance=25.0)
        seen = set()
        for t_i, l_i in zip(ti, li):
            st = plan.streets[l_i]
            d = lines[l_i].distance(tp[t_i])
            if d < st.width / 2 - 0.5 and not on_walk[t_i] and t_i not in seen and st.kind not in ("alley", "impasse", "souk"):
                seen.add(t_i)
                f = asphalt[st.kind]
                f[0] += 1
                if st.width / 2 - d > f[1]:
                    f[1], f[2] = st.width / 2 - d, f"{tag} tree {t_i} of {len(tp)} ({plan.trees[t_i].kind}) at {tp[t_i].x:.0f},{tp[t_i].y:.0f}, street {l_i} width {st.width:.1f}"
    for k, st in enumerate(plan.streets):   # the two single cases of the first scan
        if (s.name, st.kind) in (("Ksar Saba", "souk"), ("Rahousir", "bridge")):
            ribbon = st.line.buffer(st.width / 2 - 0.4, cap_style="flat")
            for i in tree.query(ribbon, predicate="intersects"):
                area = foots[i].intersection(ribbon).area
                if area > 1.5:
                    ends = [shapely.Point(st.line.coords[0]).distance(foots[i]), shapely.Point(st.line.coords[-1]).distance(foots[i])]
                    inside_len = st.line.intersection(foots[i]).length
                    print(f"  CASE {tag}: street {k} of {len(plan.streets)} {st.kind} width {st.width:.1f} length {st.line.length:.0f} overlaps No. {i} of {len(B)} "
                          f"{B[i].kind} by {area:.1f} m2; line inside the footprint {inside_len:.1f} m; its ends are {ends[0]:.1f} and {ends[1]:.1f} m from the building")
print("\n== overlapping pairs by kinds: count, total m2, worst ==")
for key, p in sorted(pairs.items(), key=lambda kv: -kv[1][1]):
    print(f"  {key}: {p[0]}, {p[1]:.0f} m2, worst {p[2]:.1f} ({p[3]})")
print(f"\n== trees inside buildings ({len(inside)}) ==")
for row in inside:
    print("  " + row)
print("\n== trees on a street ribbon and on no walk ==")
for kind, f in sorted(asphalt.items(), key=lambda kv: -kv[1][0]):
    print(f"  {kind}: {f[0]}, worst {f[1]:.1f} m inside ({f[2]})")

# street lamps high over the drawn top, far from buildings
DT = {5120: "i1", 5121: "u1", 5122: "<i2", 5123: "<u2", 5125: "<u4", 5126: "<f4"}
index = json.loads((folder / "tiles" / "index.json").read_text())
cap = ctx.plans[0]
foot_tree = STRtree(np.array([b.footprint for b in cap.buildings], dtype=object))
walk_polys = np.array([w.polygon for w in cap.walks], dtype=object)
walk_tree = STRtree(walk_polys)
decks = [(br, br.axis.buffer(br.width / 2 + 1.0, cap_style="flat")) for br in cap.bridges]
street_lines = np.array([st.line for st in cap.streets], dtype=object)
street_tree = STRtree(street_lines)
klass = Counter()
examples = defaultdict(list)
for t in index["tiles"]:
    data = (folder / "tiles" / t["file"]).read_bytes()
    n = struct.unpack_from("<I", data, 12)[0]
    js = json.loads(data[20:20 + n])
    binary = memoryview(data)[20 + n + 8:]
    for node in js["nodes"]:
        if node.get("name") != "street_lamp" or "extensions" not in node:
            continue
        a = js["accessors"][node["extensions"]["EXT_mesh_gpu_instancing"]["attributes"]["TRANSLATION"]]
        bv = js["bufferViews"][a["bufferView"]]
        T = np.frombuffer(binary, dtype=DT[a["componentType"]], count=a["count"] * 3,
                          offset=bv.get("byteOffset", 0) + a.get("byteOffset", 0)).reshape(-1, 3).astype(float)
        x, y = t["x0"] + T[:, 0], t["y0"] - T[:, 2]
        dz = T[:, 1] - np.asarray(ground.surface(x, y), dtype=float)
        pts = shapely.points(x, y)
        near = np.zeros(len(T), bool)
        near[foot_tree.query(pts, predicate="dwithin", distance=2.5)[0]] = True
        for k in np.flatnonzero((~near) & (dz > 1.2)):
            on = [cap.walks[w].kind for w in walk_tree.query(pts[k], predicate="dwithin", distance=0.5)]
            deck = [br.kind for br, poly in decks if poly.contains(pts[k])]
            li = street_tree.nearest(pts[k])
            st = cap.streets[li]
            what = f"deck {deck[0]}" if deck else ("walk " + "/".join(sorted(set(on))) if on else "open") + f", by a {st.kind}"
            klass[what] += 1
            if len(examples[what]) < 3:
                examples[what].append(f"{x[k]:.0f},{y[k]:.0f} dz {dz[k]:.2f} height {ground.height(x[k], y[k]):.2f} lamp z {T[k, 1]:.2f}")
print("\n== street lamps over 1.2 m above the drawn top, far from buildings ==")
for what, n in klass.most_common():
    print(f"  {what}: {n}  e.g. {'; '.join(examples[what])}")
